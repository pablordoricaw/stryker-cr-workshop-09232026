"""
Embeddings module for generating vector embeddings via AI_QUERY.

Uses Databricks Foundation Model (BGE) to generate embeddings for
graph nodes based on their comments/descriptions. Embeddings enable
similarity search and clustering.
"""

import logging
from dataclasses import dataclass
from typing import Dict, Any, List, Optional
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, FloatType

logger = logging.getLogger(__name__)


@dataclass
class EmbeddingConfig:
    """Configuration for embedding generation."""
    catalog_name: str
    schema_name: str
    nodes_table: str = "graph_nodes"
    ontology_entities_table: str = "ontology_entities"
    model: str = "databricks-bge-large-en"
    batch_size: int = 50
    similarity_threshold: float = 0.8

    @property
    def fully_qualified_nodes(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.nodes_table}"

    @property
    def fully_qualified_ontology_entities(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.ontology_entities_table}"


class EmbeddingGenerator:
    """
    Generator for creating embeddings using Databricks AI_QUERY.
    
    Generates embeddings from node comments and stores them in the graph_nodes table.
    Can also compute similarity edges between nodes.
    """
    
    def __init__(self, spark: SparkSession, config: EmbeddingConfig):
        self.spark = spark
        self.config = config
        self._last_error: Optional[str] = None
    
    def get_nodes_needing_embeddings(self, table_names=None) -> DataFrame:
        """Get nodes that have comments but no embeddings. Enriches with domain and ontology entity when available."""
        from dbxmetagen.table_filter import table_filter_sql
        nodes = self.config.fully_qualified_nodes
        ont = self.config.fully_qualified_ontology_entities
        tn_filter_id = table_filter_sql(table_names or [], column="n.id")
        tn_filter_parent = table_filter_sql(table_names or [], column="n.parent_id")
        if table_names:
            scope_clause = f"AND ({tn_filter_id[4:]} OR {tn_filter_parent[4:]})"
        else:
            scope_clause = ""
        try:
            return self.spark.sql(f"""
                WITH table_entity AS (
                    SELECT EXPLODE(source_tables) AS table_name,
                           entity_type, description, attributes
                    FROM {ont}
                    WHERE confidence >= 0.4
                ),
                enriched AS (
                    SELECT n.id, n.comment, n.node_type, n.domain,
                        COALESCE(CONCAT_WS(', ', COLLECT_SET(te.entity_type)), '') AS entity_type,
                        COALESCE(FIRST(te.description), '') AS entity_desc,
                        COALESCE(FIRST(CONCAT_WS(', ', MAP_VALUES(te.attributes))), '') AS entity_attrs
                    FROM {nodes} n
                    LEFT JOIN table_entity te
                      ON te.table_name = CASE WHEN n.node_type = 'table' THEN n.id ELSE n.parent_id END
                    WHERE n.comment IS NOT NULL AND LENGTH(n.comment) > 10 AND n.embedding IS NULL
                    {scope_clause}
                    GROUP BY n.id, n.comment, n.node_type, n.domain
                )
                SELECT id, node_type,
                    SUBSTRING(CONCAT(
                        COALESCE(comment, ''),
                        ' Domain: ', COALESCE(domain, ''),
                        ' Entity: ', COALESCE(entity_type, ''),
                        ' Description: ', COALESCE(entity_desc, ''),
                        ' Attributes: ', COALESCE(entity_attrs, '')
                    ), 1, 2000) AS text_to_embed
                FROM enriched
            """)
        except Exception as e:
            if "TABLE_OR_VIEW_NOT_FOUND" in str(e) or "cannot find" in str(e).lower():
                logger.info("ontology_entities not found, using comment and domain only: %s", e)
                tn_fallback = table_filter_sql(table_names or [], column="id")
                tn_parent_fb = table_filter_sql(table_names or [], column="parent_id")
                if table_names:
                    fb_scope = f"AND ({tn_fallback[4:]} OR {tn_parent_fb[4:]})"
                else:
                    fb_scope = ""
                return self.spark.sql(f"""
                    SELECT id, node_type,
                        SUBSTRING(CONCAT(COALESCE(comment, ''), ' Domain: ', COALESCE(domain, '')), 1, 2000) AS text_to_embed
                    FROM {nodes}
                    WHERE comment IS NOT NULL AND LENGTH(comment) > 10 AND embedding IS NULL
                    {fb_scope}
                    """)
            raise
    
    def generate_embedding_for_text(self, text: str) -> Optional[List[float]]:
        """Generate embedding for a single text using AI_QUERY."""
        try:
            escaped_text = text.replace("'", "''")[:2000]
            
            result = self.spark.sql(f"""
                SELECT AI_QUERY(
                    '{self.config.model}',
                    '{escaped_text}'
                ) as embedding
            """).collect()[0]['embedding']
            
            if isinstance(result, list):
                return result
            elif isinstance(result, str):
                import json
                try:
                    return json.loads(result)
                except (json.JSONDecodeError, ValueError, TypeError):
                    return None
            return None
        except Exception as e:
            logger.warning(f"Could not generate embedding: {e}")
            self._last_error = str(e)
            return None
    
    def generate_embeddings_batch(self, nodes_df: DataFrame) -> DataFrame:
        """Generate embeddings for a batch of nodes using SQL."""
        nodes_df.createOrReplaceTempView("nodes_to_embed")
        
        try:
            result = self.spark.sql(f"""
                SELECT 
                    id,
                    AI_QUERY(
                        '{self.config.model}',
                        text_to_embed
                    ) as embedding
                FROM nodes_to_embed
            """)
            # Materialize once to avoid re-executing AI_QUERY on downstream actions.
            # collect+recreate works on both classic and serverless (cache/persist don't).
            _schema = result.schema
            result = self.spark.createDataFrame(result.collect(), schema=_schema)
            return result
        except Exception as e:
            logger.warning(f"Batch embedding failed, falling back to row-by-row: {e}")
            self._last_error = str(e)
            return self._generate_embeddings_row_by_row(nodes_df)

    def _generate_embeddings_row_by_row(self, nodes_df: DataFrame) -> DataFrame:
        """Fallback: Generate embeddings one row at a time."""
        results = []
        text_col = "text_to_embed" if "text_to_embed" in nodes_df.columns else "comment"
        for row in nodes_df.collect():
            text = getattr(row, text_col, None) or row.comment
            embedding = self.generate_embedding_for_text(text)
            if embedding:
                results.append((row.id, embedding))
        
        if results:
            return self.spark.createDataFrame(results, ["id", "embedding"])
        else:
            return self.spark.createDataFrame([], "id STRING, embedding ARRAY<FLOAT>")
    
    def update_node_embeddings(self, embeddings_df: DataFrame) -> int:
        """Update graph_nodes with generated embeddings."""
        embeddings_df.createOrReplaceTempView("new_embeddings")
        
        update_sql = f"""
        MERGE INTO {self.config.fully_qualified_nodes} AS target
        USING new_embeddings AS source
        ON target.id = source.id
        WHEN MATCHED THEN UPDATE SET
            target.embedding = source.embedding,
            target.updated_at = current_timestamp()
        """

        # MERGE: Writes freshly computed embedding vectors into `graph_nodes`
        # (`fully_qualified_nodes`), joining `new_embeddings` on node `id`. Only matched
        # rows are updated (`embedding` plus `updated_at`); there is no INSERT path for
        # unseen ids in this statement.
        # WHY: Downstream graph analytics, similarity joins, and optional vector workflows
        # consume `graph_nodes.embedding`; batching via SQL keeps Spark as the execution
        # engine after `AI_QUERY`/`collect`-based generation.
        # TRADEOFFS: Targeted UPDATE-via-MERGE avoids overwriting unrelated node columns and
        # skips accidental row creation; nodes without embeddings stay untouched (possibly
        # stale NULLs). Returning `embeddings_df.count()` reflects input batch size, not
        # rows actually matched in the target table.

        self.spark.sql(update_sql)
        
        # Return count of updated nodes
        return embeddings_df.count()

    def compute_cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Compute cosine similarity between two vectors."""
        if not vec1 or not vec2 or len(vec1) != len(vec2):
            return 0.0
        
        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = sum(a * a for a in vec1) ** 0.5
        norm2 = sum(b * b for b in vec2) ** 0.5
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    def find_similar_nodes(self) -> DataFrame:
        """
        Find pairs of nodes with similar embeddings.
        
        Returns DataFrame with src, dst, similarity for pairs above threshold.
        """
        # Get nodes with embeddings
        nodes_with_embeddings = self.spark.sql(f"""
            SELECT id, node_type, embedding
            FROM {self.config.fully_qualified_nodes}
            WHERE embedding IS NOT NULL
        """)
        
        if nodes_with_embeddings.count() < 2:
            return self.spark.createDataFrame([], 
                "src STRING, dst STRING, similarity DOUBLE")
        
        # Self-join to compare all pairs (expensive for large datasets)
        # For production, consider using approximate nearest neighbor
        nodes_with_embeddings.createOrReplaceTempView("nodes_emb")
        
        try:
            # Use built-in vector functions if available
            similar_pairs = self.spark.sql(f"""
                WITH node_pairs AS (
                    SELECT 
                        a.id as src,
                        b.id as dst,
                        a.embedding as emb_a,
                        b.embedding as emb_b
                    FROM nodes_emb a
                    CROSS JOIN nodes_emb b
                    WHERE a.id < b.id
                )
                SELECT 
                    src, 
                    dst,
                    AGGREGATE(
                        TRANSFORM(
                            SEQUENCE(0, SIZE(emb_a) - 1),
                            i -> emb_a[i] * emb_b[i]
                        ),
                        CAST(0 AS DOUBLE),
                        (acc, x) -> acc + x
                    ) / (
                        SQRT(AGGREGATE(TRANSFORM(emb_a, x -> x * x), CAST(0 AS DOUBLE), (acc, x) -> acc + x)) *
                        SQRT(AGGREGATE(TRANSFORM(emb_b, x -> x * x), CAST(0 AS DOUBLE), (acc, x) -> acc + x))
                    ) as similarity
                FROM node_pairs
                HAVING similarity >= {self.config.similarity_threshold}
            """)
            return similar_pairs
        except Exception as e:
            logger.warning(f"SQL-based similarity failed: {e}")
            return self._compute_similarity_python(nodes_with_embeddings)
    
    def _compute_similarity_python(self, nodes_df: DataFrame) -> DataFrame:
        """Fallback: Compute similarities using Python."""
        nodes = nodes_df.collect()
        pairs = []
        
        for i, node_a in enumerate(nodes):
            for node_b in nodes[i+1:]:
                if node_a.embedding and node_b.embedding:
                    sim = self.compute_cosine_similarity(
                        list(node_a.embedding), 
                        list(node_b.embedding)
                    )
                    if sim >= self.config.similarity_threshold:
                        pairs.append((node_a.id, node_b.id, sim))
        
        if pairs:
            return self.spark.createDataFrame(pairs, ["src", "dst", "similarity"])
        return self.spark.createDataFrame([], "src STRING, dst STRING, similarity DOUBLE")
    
    def run(self, max_nodes: int = None, table_names=None) -> Dict[str, Any]:
        """
        Execute the embedding generation pipeline.
        
        Args:
            max_nodes: Maximum nodes to process (None = all)
            table_names: Optional list of table names to scope embedding to
        """
        logger.info("Starting embedding generation")
        
        # Get nodes needing embeddings
        nodes_to_embed = self.get_nodes_needing_embeddings(table_names=table_names)
        
        if max_nodes:
            nodes_to_embed = nodes_to_embed.limit(max_nodes)
        
        total_to_embed = nodes_to_embed.count()
        logger.info(f"Generating embeddings for {total_to_embed} nodes")
        
        if total_to_embed == 0:
            return {"nodes_embedded": 0, "total_candidates": 0}
        
        # Generate embeddings in batches
        embeddings_df = self.generate_embeddings_batch(nodes_to_embed)
        
        # Update nodes
        updated = self.update_node_embeddings(embeddings_df)
        logger.info(f"Updated {updated} nodes with embeddings")

        if total_to_embed > 0 and updated == 0:
            detail = f" Last error: {self._last_error}" if self._last_error else ""
            raise RuntimeError(
                f"Embedding generation failed: {total_to_embed} nodes needed embeddings "
                f"but 0 were generated.{detail}"
            )

        return {
            "nodes_embedded": updated,
            "total_candidates": total_to_embed
        }


def generate_embeddings(
    spark: SparkSession,
    catalog_name: str,
    schema_name: str,
    max_nodes: int = None,
    table_names=None,
) -> Dict[str, Any]:
    """
    Convenience function to generate embeddings.
    
    Args:
        spark: SparkSession instance
        catalog_name: Catalog name for tables
        schema_name: Schema name for tables
        max_nodes: Maximum nodes to process
        table_names: Optional list of table names to scope embedding to
        
    Returns:
        Dict with execution statistics
    """
    config = EmbeddingConfig(
        catalog_name=catalog_name,
        schema_name=schema_name
    )
    generator = EmbeddingGenerator(spark, config)
    return generator.run(max_nodes, table_names=table_names)


def find_similar_nodes(
    spark: SparkSession,
    catalog_name: str,
    schema_name: str,
    similarity_threshold: float = 0.8
) -> DataFrame:
    """
    Find similar nodes based on embeddings.
    
    Args:
        spark: SparkSession instance
        catalog_name: Catalog name for tables
        schema_name: Schema name for tables
        similarity_threshold: Minimum similarity score
        
    Returns:
        DataFrame with src, dst, similarity columns
    """
    config = EmbeddingConfig(
        catalog_name=catalog_name,
        schema_name=schema_name,
        similarity_threshold=similarity_threshold
    )
    generator = EmbeddingGenerator(spark, config)
    return generator.find_similar_nodes()

