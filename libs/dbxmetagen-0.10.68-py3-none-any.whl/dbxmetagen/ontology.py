"""
Ontology module for entity and metric management.

Discovers and manages business entities from the knowledge base,
creating an ontology layer on top of the data catalog.

Includes flexible keyword matching, AI-powered structured classification,
value enforcement, domain-aware scoring, and deduplication.
"""

import difflib
import hashlib
import logging
import yaml
import os
import re
import json
from pathlib import Path
from dataclasses import dataclass, field, replace as dc_replace
from typing import Dict, Any, List, Optional, Set, Tuple
from datetime import datetime
import uuid
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    ArrayType,
    MapType,
    DoubleType,
    BooleanType,
    TimestampType,
)
from pydantic import BaseModel, Field, field_validator
from dbxmetagen.config import DEFAULT_CLASSIFICATION_MODEL
from dbxmetagen.ontology_roles import (
    AUDIT_COLUMN_NAMES as _AUDIT_PATTERNS_CANONICAL,
    BUSINESS_KEY_COLUMN_NAMES as _BUSINESS_KEY_PATTERNS_CANONICAL,
    GEO_COLUMN_NAMES as _GEO_PATTERNS_CANONICAL,
    LABEL_COLUMN_NAMES as _LABEL_PATTERNS_CANONICAL,
)
from dbxmetagen.table_filter import table_filter_sql, infrastructure_exclude_sql

logger = logging.getLogger(__name__)


# ==============================================================================
# Pydantic structured output models for AI classification
# ==============================================================================


class EntityClassificationResult(BaseModel):
    """Structured output from LLM entity classification."""

    entity_type: str = Field(description="Entity type from the provided list")
    secondary_entity_type: Optional[str] = Field(
        default=None,
        description="Second entity type if the table clearly represents a relationship between two entities (e.g. patient_encounters -> Patient, Encounter). Omit if only one entity type applies.",
    )
    confidence: float = Field(
        ge=0.0, le=1.0, description="Confidence score between 0.0 and 1.0"
    )
    recommended_entity: Optional[str] = Field(
        default=None,
        description="If confidence is below 0.5, suggest what entity type name this should be, even if it is not in the provided list",
    )
    reasoning: str = Field(description="Brief reasoning for the classification")


class ColumnClassificationItem(BaseModel):
    """Single column classification within a batch response."""
    column_name: str = Field(description="Exact column name as provided in input")
    entity_type: str = Field(description="Entity type from the provided list")
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence 0.0-1.0")


# ON-19: cap columns per batch-classify LLM call by expected OUTPUT size, not just
# count. Each column emits one {"column_name","entity_type","confidence"} object
# (~75-80 tokens with names/whitespace). At max_tokens=8192 (_get_batch_column_llm),
# ~100 objects is a safe ceiling with headroom; 60 keeps a comfortable margin and
# bounds the sub-chunk depth. This REPLACES the old `metadata_cols_per_chunk` (120)
# + `*1.25` merge (which admitted up to 150 columns -> truncation at 4096).
_COLS_PER_CLASSIFY_CHUNK = 60


class BatchColumnClassificationResult(BaseModel):
    """Batch response for classifying all columns of a single table."""
    classifications: List[ColumnClassificationItem] = Field(
        description="One classification per input column"
    )

    @field_validator("classifications", mode="before")
    @classmethod
    def _coerce_string_to_list(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON in classifications: {v!r}") from exc
        return v


class TableClassificationItem(BaseModel):
    """Single table classification within a batch response."""
    table_name: str = Field(description="Short table name as provided in input")
    entity_type: str = Field(description="Entity type from the provided list")
    secondary_entity_type: Optional[str] = Field(
        default=None,
        description="Second entity type if the table represents a relationship between two entities",
    )
    confidence: float = Field(ge=0.0, le=1.0, description="Confidence 0.0-1.0")
    recommended_entity: Optional[str] = Field(
        default=None,
        description="If confidence is below 0.5, suggest a better entity name",
    )
    reasoning: str = Field(description="Brief reasoning for the classification")


class BatchTableClassificationResult(BaseModel):
    """Batch response for classifying multiple tables at once."""
    classifications: List[TableClassificationItem] = Field(
        description="One classification per input table"
    )

    @field_validator("classifications", mode="before")
    @classmethod
    def _coerce_string_to_list(cls, v):
        if isinstance(v, str):
            try:
                return json.loads(v)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON in classifications: {v!r}") from exc
        return v


class _StructuredInvoker:
    """Thin wrapper that preserves the ``llm.invoke(messages)`` call contract
    while delegating to :func:`chat_client.invoke_structured` for fallback."""

    def __init__(self, invoke_fn, endpoint, response_model, temperature, max_tokens, max_retries):
        self._invoke_fn = invoke_fn
        self._endpoint = endpoint
        self._response_model = response_model
        self._temperature = temperature
        self._max_tokens = max_tokens
        self._max_retries = max_retries

    def invoke(self, messages):
        return self._invoke_fn(
            self._endpoint, messages, self._response_model,
            temperature=self._temperature, max_tokens=self._max_tokens,
            max_retries=self._max_retries,
        )


# ==============================================================================
# Domain-to-entity affinity map (loaded from config, with embedded fallback)
# ==============================================================================

_DEFAULT_DOMAIN_ENTITY_AFFINITY: Dict[str, List[str]] = {
    "healthcare": [
        "Patient",
        "Provider",
        "Encounter",
        "Condition",
        "Procedure",
        "Medication",
        "Observation",
        "Claim",
        "Coverage",
        "Person",
        "Organization",
        "Location",
    ],
    "clinical": [
        "Patient",
        "Provider",
        "Encounter",
        "Condition",
        "Procedure",
        "Medication",
        "Observation",
        "Claim",
        "Coverage",
        "Person",
        "Organization",
        "Location",
    ],
    "diagnostics": [
        "Patient",
        "Observation",
        "Condition",
        "Procedure",
        "Person",
        "Reference",
    ],
    "payer": [
        "Claim",
        "Coverage",
        "Person",
        "Organization",
        "Transaction",
        "Reference",
    ],
    "pharmaceutical": [
        "Patient",
        "Observation",
        "Medication",
        "Condition",
        "Procedure",
        "Person",
        "Document",
        "Reference",
        "Organization",
    ],
    "quality_safety": [
        "Patient",
        "Observation",
        "Encounter",
        "Condition",
        "Metric",
        "Event",
    ],
    "research": [
        "Patient",
        "Observation",
        "Medication",
        "Condition",
        "Procedure",
        "Person",
        "Document",
        "Reference",
    ],
    "finance": [
        "Transaction",
        "Person",
        "Organization",
        "Product",
        "Reference",
        "Event",
        "Metric",
    ],
    "operations": [
        "Product",
        "Organization",
        "Location",
        "Event",
        "Metric",
        "Reference",
    ],
    "workforce": ["Person", "Organization", "Location", "Event", "Reference"],
    "customer": [
        "Person",
        "Organization",
        "Product",
        "Transaction",
        "Event",
        "Metric",
        "Location",
    ],
    "technology": ["Event", "Metric", "Reference", "Organization"],
    "governance": ["Document", "Reference", "Organization", "Person"],
}


def load_domain_entity_affinity(ontology_config: Dict[str, Any]) -> Dict[str, set]:
    """Load domain_entity_affinity from ontology config, falling back to defaults."""
    raw = ontology_config.get("domain_entity_affinity")
    if raw and isinstance(raw, dict):
        return {k: set(v) for k, v in raw.items()}
    return {k: set(v) for k, v in _DEFAULT_DOMAIN_ENTITY_AFFINITY.items()}


# Backward-compat: module-level reference used by tests / external callers
DOMAIN_ENTITY_AFFINITY: Dict[str, set] = {
    k: set(v) for k, v in _DEFAULT_DOMAIN_ENTITY_AFFINITY.items()
}


# ==============================================================================
# Value enforcement (ported from domain_classifier)
# ==============================================================================


def _leading_overlap(pred: str, entity: str) -> int:
    """Count matching leading characters. Lowercases entity before comparing."""
    e = entity.lower()
    n = 0
    for i in range(min(len(pred), len(e))):
        if pred[i] == e[i]:
            n += 1
        else:
            break
    return n


def _enforce_entity_value(
    predicted: str,
    allowed: List[str],
    fallback: str = "DataTable",
) -> Tuple[str, bool]:
    """Snap a predicted entity type to the nearest allowed value.

    Returns (value, was_exact_match). Confidence should be penalized
    by the caller when was_exact_match is False.

    Strategy: (1) case-insensitive exact match; (2) empty/whitespace → first
    allowed entry (stable list order); (3) forward containment — ``entity``
    appears in ``predicted`` (longest entity wins ties); (4) best **leading
    character overlap** between predicted and entity (disambiguates ``Prod``
    vs ``Proc``); (5) predicted substring of entity name with length ≥2; (6)
    difflib fuzzy.
    """
    low = predicted.lower().strip()
    allowed_map = {a.lower(): a for a in allowed}
    if low in allowed_map:
        return allowed_map[low], True
    if not allowed:
        return fallback, False
    if not low:
        return allowed[0], False

    # Forward: predicted string contains full entity name (LLM compound labels)
    forward = [a for a in allowed if a.lower() in low]
    if forward:
        forward.sort(key=lambda x: len(x), reverse=True)
        return forward[0], False

    # Leading overlap: Prod→Product, Proc→Procedure (not the other way around)
    scored = [( _leading_overlap(low, a), a) for a in allowed]
    best_n = max(s[0] for s in scored)
    if best_n >= max(3, min(len(low), 4)):
        winners = [a for n, a in scored if n == best_n]
        winners.sort(key=lambda x: (len(x), x.lower()))
        return winners[0], False

    # Infix: predicted appears inside entity name (Enc -> Reference|Encounter)
    infix = [a for a in allowed if len(low) >= 2 and low in a.lower()]
    if infix:
        infix.sort(key=lambda x: (len(x), x.lower()))
        return infix[0], False

    close = difflib.get_close_matches(low, list(allowed_map.keys()), n=1, cutoff=0.75)
    if close:
        return allowed_map[close[0]], False
    return fallback, False


# ==============================================================================
# EMBEDDED DEFAULT ENTITY DEFINITIONS
# These are used when the config file cannot be loaded
# ==============================================================================
DEFAULT_ENTITY_DEFINITIONS = {
    # General entities
    "Person": {
        "description": "People, customers, contacts, users, or employees",
        "keywords": ["customer", "employee", "user", "contact", "person"],
        "typical_attributes": [
            "id",
            "name",
            "email",
            "phone",
            "address",
            "created_date",
        ],
    },
    "Organization": {
        "description": "Companies, departments, facilities, or business units",
        "keywords": ["company", "organization", "department", "facility", "tenant"],
        "typical_attributes": ["id", "name", "type", "address", "parent_id"],
    },
    "Product": {
        "description": "Goods, services, SKUs, or catalog items",
        "keywords": ["product", "item", "sku", "catalog", "offering"],
        "typical_attributes": [
            "id",
            "name",
            "description",
            "price",
            "category",
            "status",
        ],
    },
    "Transaction": {
        "description": "Orders, purchases, payments, invoices, or financial events",
        "keywords": ["transaction", "order", "payment", "invoice", "purchase"],
        "typical_attributes": [
            "id",
            "customer_id",
            "amount",
            "date",
            "status",
            "currency",
        ],
    },
    "Location": {
        "description": "Addresses, sites, regions, facilities, or geographies",
        "keywords": ["location", "address", "site", "region", "facility"],
        "typical_attributes": [
            "id",
            "name",
            "address",
            "city",
            "state",
            "country",
            "zip_code",
        ],
    },
    "Event": {
        "description": "Activities, logs, sessions, audits, or system events",
        "keywords": ["event", "activity", "log", "audit", "session"],
        "typical_attributes": ["id", "type", "timestamp", "user_id", "details"],
    },
    "Reference": {
        "description": "Lookup tables, codes, categories, dimensions, or configuration",
        "keywords": ["reference", "lookup", "code", "category", "dim_"],
        "typical_attributes": ["id", "code", "name", "description", "active"],
    },
    "Metric": {
        "description": "KPIs, aggregates, facts, summaries, or analytic measures",
        "keywords": ["metric", "kpi", "aggregate", "fact_", "summary"],
        "typical_attributes": ["id", "name", "value", "period", "dimension"],
    },
    "Document": {
        "description": "Unstructured content, notes, files, or text records",
        "keywords": ["document", "note", "file", "content", "text"],
        "typical_attributes": ["id", "title", "body", "author", "created_date", "type"],
    },
    # Healthcare / Life Sciences entities
    "Patient": {
        "description": "Individuals receiving healthcare services (FHIR Patient)",
        "keywords": ["patient", "mrn", "subject", "participant", "beneficiary"],
        "typical_attributes": ["id", "mrn", "name", "dob", "gender", "address"],
    },
    "Provider": {
        "description": "Practitioners, clinicians, or care team members (FHIR Practitioner)",
        "keywords": ["provider", "physician", "practitioner", "clinician", "npi"],
        "typical_attributes": ["id", "npi", "name", "specialty", "organization"],
    },
    "Encounter": {
        "description": "Visits, admissions, or episodes of care (FHIR Encounter)",
        "keywords": ["encounter", "visit", "admission", "episode", "appointment"],
        "typical_attributes": [
            "id",
            "patient_id",
            "date",
            "type",
            "provider",
            "location",
        ],
    },
    "Condition": {
        "description": "Diagnoses, problems, or diseases (FHIR Condition / OMOP CONDITION_OCCURRENCE)",
        "keywords": ["diagnosis", "condition", "icd", "disease", "problem"],
        "typical_attributes": [
            "id",
            "code",
            "description",
            "patient_id",
            "date",
            "status",
        ],
    },
    "Procedure": {
        "description": "Medical procedures, surgeries, or interventions (FHIR Procedure)",
        "keywords": ["procedure", "surgery", "cpt", "intervention", "operation"],
        "typical_attributes": [
            "id",
            "code",
            "description",
            "date",
            "provider",
            "status",
        ],
    },
    "Medication": {
        "description": "Drugs, prescriptions, or medication orders (FHIR MedicationRequest)",
        "keywords": ["medication", "drug", "prescription", "pharmacy", "ndc"],
        "typical_attributes": ["id", "name", "ndc", "dose", "frequency", "route"],
    },
    "Observation": {
        "description": "Lab results, vitals, or clinical measurements (FHIR Observation / OMOP MEASUREMENT)",
        "keywords": ["lab", "result", "observation", "vital", "specimen"],
        "typical_attributes": [
            "id",
            "test_code",
            "value",
            "unit",
            "reference_range",
            "date",
        ],
    },
    "Claim": {
        "description": "Insurance claims or billing submissions (FHIR Claim)",
        "keywords": ["claim", "billing", "adjudication", "remittance", "eob"],
        "typical_attributes": [
            "id",
            "patient_id",
            "amount",
            "service_date",
            "status",
            "payer_id",
        ],
    },
    "Coverage": {
        "description": "Insurance plans, benefits, or member coverage (FHIR Coverage)",
        "keywords": ["coverage", "insurance", "benefit", "plan", "enrollment"],
        "typical_attributes": [
            "id",
            "member_id",
            "payer",
            "plan_name",
            "start_date",
            "end_date",
        ],
    },
    "DataTable": {
        "description": "Generic data table (fallback type)",
        "keywords": [],
        "typical_attributes": ["id"],
    },
}


_DEFAULT_ONTOLOGY_CONFIG_PATH = "configurations/ontology_config.yaml"


def _resolve_ontology_config_path(config_path: str, ontology_bundle: str) -> str:
    """Derive the ontology config path from the bundle when config_path is the default.

    When the user hasn't explicitly overridden ``ontology_config_path``, the
    bundle YAML is used instead so that entity discovery, domain classification,
    and tier indexes all come from the same source.
    """
    if ontology_bundle and config_path == _DEFAULT_ONTOLOGY_CONFIG_PATH:
        bundle_path = f"configurations/ontology_bundles/{ontology_bundle}.yaml"
        logger.info(
            "Deriving ontology config from bundle '%s' (config_path was default)",
            ontology_bundle,
        )
        return bundle_path
    return config_path


@dataclass
class OntologyConfig:
    """Configuration for ontology management."""

    catalog_name: str
    schema_name: str
    config_path: str = _DEFAULT_ONTOLOGY_CONFIG_PATH
    ontology_bundle: str = ""
    entities_table: str = "ontology_entities"
    metrics_table: str = "ontology_metrics"
    column_properties_table: str = "ontology_column_properties"
    relationships_table: str = "ontology_relationships"
    discovery_diff_table: str = "discovery_diff_report"
    kb_table: str = "table_knowledge_base"
    column_kb_table: str = "column_knowledge_base"
    nodes_table: str = "graph_nodes"
    incremental: bool = True
    entity_tag_key: str = "ontology_entity_type"
    metadata_cols_per_chunk: int = 120
    table_names: Optional[List[str]] = None
    exclude_infrastructure: bool = True
    # Pass 0 shortlist for three-pass entity prediction (see ontology_predictor)
    pass0_mode: str = "off"
    pass0_max_candidates: int = 48
    pass0_min_candidates: int = 12
    # Vector Search index for ontology retrieval (empty = disabled)
    ontology_vs_index: str = ""
    # VS endpoint name for ontology vector queries
    vs_endpoint_name: str = "dbxmetagen-vs"
    federation_mode: bool = False

    @property
    def fully_qualified_entities(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.entities_table}"

    @property
    def fully_qualified_metrics(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.metrics_table}"

    @property
    def fully_qualified_column_properties(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.column_properties_table}"

    @property
    def fully_qualified_relationships(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.relationships_table}"

    @property
    def fully_qualified_discovery_diff(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.discovery_diff_table}"

    @property
    def fully_qualified_kb(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.kb_table}"

    @property
    def fully_qualified_column_kb(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.column_kb_table}"

    @property
    def fully_qualified_nodes(self) -> str:
        return f"{self.catalog_name}.{self.schema_name}.{self.nodes_table}"


@dataclass
class PropertyDefinition:
    """Formal property definition from ontology bundle."""

    name: str
    kind: str  # "data_property" or "object_property"
    role: str  # references property_roles taxonomy
    typical_attributes: List[str] = field(default_factory=list)
    edge: Optional[str] = None  # edge catalog name for object_properties
    target_entity: Optional[Any] = None  # str or list of str
    datatype: Optional[str] = None
    composite_columns: Optional[List[str]] = None
    uri: Optional[str] = None
    cardinality: Optional[str] = None
    inverse: Optional[str] = None


@dataclass
class EdgeCatalogEntry:
    """Entry in the global edge catalog."""

    name: str
    inverse: Optional[str] = None
    domain: Optional[Any] = None  # str, list of str, or "Any"
    range: Optional[Any] = None
    symmetric: bool = False
    category: str = "business"
    uri: Optional[str] = None
    owl_type: Optional[str] = None
    bundle_name: Optional[str] = None

    def _matches(self, constraint: Any, entity_type: str) -> bool:
        if constraint is None or constraint == "Any":
            return True
        if isinstance(constraint, list):
            return entity_type in constraint
        return constraint == entity_type

    def matches_domain(self, entity_type: str) -> bool:
        return self._matches(self.domain, entity_type)

    def matches_range(self, entity_type: str) -> bool:
        return self._matches(self.range, entity_type)

    def validate_edge(self, src_entity: str, dst_entity: str) -> bool:
        return self.matches_domain(src_entity) and self.matches_range(dst_entity)

    def is_unconstrained(self) -> bool:
        """True when the entry constrains neither side (domain and range both
        absent or 'Any'). Such an entry carries no (src,dst) signal and would
        wildcard-match every pair, so it must never be selected by find_edge."""
        dom_any = self.domain is None or self.domain == "Any"
        rng_any = self.range is None or self.range == "Any"
        return dom_any and rng_any


class EdgeCatalog:
    """Utility wrapper around a dict of EdgeCatalogEntry objects."""

    # Built-in inverses for common structural/business relationships. Used as a
    # fallback when a bundle does not declare an explicit ``inverse`` (formal
    # bundles like FHIR/OMOP define none at the top level), so the auto-inverse
    # edge generation still produces a denser, navigable graph. Bidirectional.
    _DEFAULT_INVERSES: Dict[str, str] = {
        "references": "referenced_by",
        "referenced_by": "references",
        "has_part": "part_of",
        "part_of": "has_part",
        "contains": "contained_in",
        "contained_in": "contains",
        "depends_on": "required_by",
        "required_by": "depends_on",
        "derived_from": "derives",
        "derives": "derived_from",
        "precedes": "follows",
        "follows": "precedes",
        "causes": "caused_by",
        "caused_by": "causes",
    }

    def __init__(self, entries: Dict[str, "EdgeCatalogEntry"]):
        self._entries = entries

    def get(self, name: str) -> Optional[EdgeCatalogEntry]:
        return self._entries.get(name)

    def get_inverse(self, name: str) -> Optional[str]:
        entry = self._entries.get(name)
        if entry and entry.inverse:
            return entry.inverse
        return self._DEFAULT_INVERSES.get(name)

    def find_edge(self, src_entity: str, dst_entity: str,
                  bundle_name: Optional[str] = None) -> Optional[EdgeCatalogEntry]:
        """Find the best matching edge for a (src, dst) entity pair.

        When *bundle_name* is supplied, entries from that bundle are preferred
        over cross-bundle matches, avoiding false positives when multiple
        bundles define entities with the same name. Fully-unconstrained entries
        (no domain and no range) are skipped: they carry no (src,dst) signal and
        would wildcard-match every pair, which is how a custom-bundle catalog
        entry could pollute FK/discovered edge naming. Among matches, entries
        that constrain both sides outrank those that constrain only one side.
        """
        scoped = []
        unscoped = []
        for entry in self._entries.values():
            if entry.is_unconstrained():
                continue
            if entry.validate_edge(src_entity, dst_entity):
                if bundle_name and entry.bundle_name == bundle_name:
                    scoped.append(entry)
                else:
                    unscoped.append(entry)

        def specificity(e: "EdgeCatalogEntry") -> int:
            return int(e.domain not in (None, "Any")) + int(e.range not in (None, "Any"))

        scoped.sort(key=specificity, reverse=True)
        unscoped.sort(key=specificity, reverse=True)
        if scoped:
            return scoped[0]
        return unscoped[0] if unscoped else None

    def validate(self, edge_name: str, src_entity: str, dst_entity: str) -> Tuple[bool, str]:
        """Validate an edge. Returns (valid, message)."""
        entry = self._entries.get(edge_name)
        if not entry:
            return False, f"Edge '{edge_name}' not in catalog"
        if entry.is_unconstrained() and entry.category != "structural":
            return False, (
                f"Edge '{edge_name}' is unconstrained (no domain/range) and "
                f"not structural; refusing to wildcard-match {src_entity}->{dst_entity}"
            )
        if not entry.validate_edge(src_entity, dst_entity):
            return False, (
                f"Edge '{edge_name}' domain/range violation: "
                f"{src_entity}->{dst_entity} (expected {entry.domain}->{entry.range})"
            )
        return True, "ok"

    @property
    def entries(self) -> Dict[str, EdgeCatalogEntry]:
        return self._entries


@dataclass
class EntityDefinition:
    """Definition of a business entity."""

    name: str
    description: str
    keywords: List[str] = field(default_factory=list)
    typical_attributes: List[str] = field(default_factory=list)
    relationships: Dict[str, Dict[str, str]] = field(default_factory=dict)
    synonyms: List[str] = field(default_factory=list)
    business_questions: List[str] = field(default_factory=list)
    parent: Optional[str] = None
    properties: List[PropertyDefinition] = field(default_factory=list)
    uri: Optional[str] = None
    source_ontology: Optional[str] = None
    subclass_of: Optional[str] = None
    owl_equivalent_class: Optional[str] = None
    owl_properties: List[Dict[str, Any]] = field(default_factory=list)


BUNDLE_DIR = "configurations/ontology_bundles"


def _match_bundle_by_display_name(display_name: str) -> Optional[str]:
    """Scan the local bundle dir for a *.yaml whose metadata.name matches
    display_name (case-insensitive). Returns the file path or None.

    Rescues curated bundles whose display label != slugified stem
    (e.g. "General Cross-Industry" -> general.yaml). Reads only the small
    metadata header of each file, and only the first bundle dir that exists.
    """
    want = display_name.strip().lower()
    if not want:
        return None
    dirs = [
        BUNDLE_DIR,
        os.path.join(os.path.dirname(__file__), "..", "..", BUNDLE_DIR),
    ]
    try:
        dirs.append(os.path.join(os.getcwd(), BUNDLE_DIR))
    except Exception:
        pass
    for d in dirs:
        d = os.path.normpath(d)
        if not os.path.isdir(d):
            continue
        for fn in sorted(os.listdir(d)):
            if not fn.endswith(".yaml"):
                continue
            fpath = os.path.join(d, fn)
            try:
                with open(fpath) as f:
                    raw = yaml.safe_load(f) or {}
                name = (raw.get("metadata") or {}).get("name")
            except Exception:
                continue
            if name and str(name).strip().lower() == want:
                return fpath
        return None  # first existing dir is authoritative; don't scan further
    return None


def resolve_bundle_path(
    bundle_name: str,
    catalog_name: Optional[str] = None,
    schema_name: Optional[str] = None,
    volume_name: Optional[str] = None,
) -> str:
    """Resolve a bundle name (e.g. 'healthcare') to its YAML path.

    Searches ``configurations/ontology_bundles/`` (curated/wheel-bundled) first,
    then the UC Volume where the app persists imported bundles
    (``/Volumes/<catalog>/<schema>/<volume>/ontology_bundles/<name>.yaml``).
    Returns the first existing path, or falls back to
    ``<BUNDLE_DIR>/<bundle_name>.yaml``.

    Curated bundles are checked first so built-in names resolve unchanged; the
    Volume is the fallback for app-imported bundles that aren't shipped in the
    wheel. ``catalog_name``/``schema_name`` are required to search the Volume;
    ``volume_name`` defaults to ``$VOLUME_NAME`` or ``generated_metadata``.
    """
    stem = bundle_name[:-len(".yaml")] if bundle_name.endswith(".yaml") else bundle_name
    filename = f"{stem}.yaml"
    # Defense-in-depth: a display label ("FHIR R4", "OMOP CDM") may reach here
    # instead of the file stem ("fhir_r4", "omop_cdm") -- e.g. from a stale
    # localStorage value or a hand-typed --params. Try the verbatim name first,
    # then a slugified fallback (lowercased, non-alphanumerics -> underscore) so
    # curated bundles resolve either way. The verbatim path is always tried first
    # so a real file whose stem contains spaces/caps still wins.
    slug = re.sub(r"[^a-z0-9]+", "_", stem.lower()).strip("_")
    stems = [stem] if slug == stem else [stem, slug]

    def _paths_for(fn: str) -> list:
        out = [
            os.path.join(BUNDLE_DIR, fn),
            os.path.join("..", BUNDLE_DIR, fn),
            os.path.join(os.path.dirname(__file__), "..", "..", BUNDLE_DIR, fn),
        ]
        try:
            cwd = os.getcwd()
            out.append(os.path.join(cwd, BUNDLE_DIR, fn))
            out.append(os.path.join(cwd, "..", BUNDLE_DIR, fn))
        except Exception:
            pass
        return out

    candidates = []
    for s in stems:
        candidates.extend(_paths_for(f"{s}.yaml"))

    vol_path = None
    if catalog_name and schema_name:
        vol = volume_name or os.environ.get("VOLUME_NAME", "generated_metadata")
        vol_path = f"/Volumes/{catalog_name}/{schema_name}/{vol}/ontology_bundles/{filename}"
        candidates.append(vol_path)

    for path in candidates:
        if os.path.exists(path):
            logger.info("Resolved bundle '%s' -> %s", bundle_name, path)
            return path

    # Neither the verbatim stem nor the slug matched a file. A curated bundle's
    # display label (metadata.name, e.g. "General Cross-Industry" -> general.yaml,
    # "Healthcare & Life Sciences" -> healthcare.yaml) may have leaked in where a
    # stem was expected -- slugifying those does NOT yield the stem, so scan the
    # bundle dir and match on metadata.name (case-insensitive). Local dir only;
    # runs only on a miss.
    matched = _match_bundle_by_display_name(bundle_name)
    if matched:
        logger.info("Resolved bundle '%s' via metadata.name -> %s", bundle_name, matched)
        return matched

    # FUSE may not expose /Volumes on serverless job compute; fall back to an
    # SDK download (same mechanism the app uses to read imported bundles).
    if vol_path:
        local = _download_volume_bundle(vol_path)
        if local:
            logger.info("Resolved bundle '%s' via SDK download -> %s", bundle_name, vol_path)
            return local

    logger.warning(
        "Bundle '%s' not found in any candidate (tried %s); falling back to bare path",
        bundle_name, candidates,
    )
    return os.path.join(BUNDLE_DIR, filename)


def _download_volume_bundle(vol_path: str) -> Optional[str]:
    """Download a bundle YAML from a UC Volume via the SDK to a temp file.

    Returns the local temp path, or None if the file isn't there / SDK fails.
    Used as a FUSE-independent fallback for app-imported bundles.
    """
    try:
        import tempfile
        from databricks.sdk import WorkspaceClient

        resp = WorkspaceClient().files.download(vol_path)
        data = resp.contents.read()
        if not data:
            return None
        fd, tmp = tempfile.mkstemp(suffix="_" + os.path.basename(vol_path))
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        return tmp
    except Exception as e:
        logger.debug("SDK download of bundle %s failed: %s", vol_path, e)
        return None


def _resolve_tier_dir(resolved_yaml: str) -> Optional[str]:
    """Return the tier-index directory for a resolved bundle YAML path.

    The tier dir is the sibling directory named after the YAML stem
    (``.../<bundle>.yaml`` -> ``.../<bundle>/``). This works for built-in
    bundles and for app-imported bundles loaded from a UC Volume path.

    If the sibling dir is missing its tier files (e.g. the app's best-effort
    tier upload to the Volume did not run), tiers are regenerated locally from
    the YAML into a temp dir so three-pass grounding still works. Returns the
    effective tier dir, or None if tiers cannot be produced.
    """
    yaml_path = Path(resolved_yaml)
    sibling = yaml_path.parent / yaml_path.stem
    if (sibling / "entities_tier1.json").is_file() or (sibling / "entities_tier1.yaml").is_file():
        return str(sibling)

    if not yaml_path.is_file():
        return None
    try:
        import tempfile
        from dbxmetagen.ontology_bundle_indexes import (
            build_tiers,
            entities_from_bundle,
            load_edge_catalog,
        )

        entities = entities_from_bundle(yaml_path)
        if not entities:
            return None
        edge_catalog = load_edge_catalog(yaml_path)
        out_dir = Path(tempfile.mkdtemp(prefix=f"tiers_{yaml_path.stem}_"))
        build_tiers(entities, out_dir, edge_catalog=edge_catalog or None)
        logger.info("Regenerated tier indexes for '%s' into %s", yaml_path.stem, out_dir)
        return str(out_dir)
    except Exception as e:
        logger.warning("Could not regenerate tier indexes from %s: %s", resolved_yaml, e)
        return None


def list_available_bundles() -> List[Dict[str, Any]]:
    """Return metadata dicts for every bundle YAML found in the bundles directory."""
    bundles: List[Dict[str, Any]] = []
    candidates = [
        BUNDLE_DIR,
        os.path.join(os.path.dirname(__file__), "..", "..", BUNDLE_DIR),
    ]
    try:
        candidates.append(os.path.join(os.getcwd(), BUNDLE_DIR))
    except Exception:
        pass

    seen: set = set()
    for base in candidates:
        if not os.path.isdir(base):
            continue
        for fname in sorted(os.listdir(base)):
            if not fname.endswith(".yaml"):
                continue
            bundle_key = fname.replace(".yaml", "")
            if bundle_key in seen:
                continue
            seen.add(bundle_key)
            try:
                with open(os.path.join(base, fname), "r") as f:
                    raw = yaml.safe_load(f)
                meta = raw.get("metadata", {})
                entity_count = len(
                    raw.get("ontology", {}).get("entities", {}).get("definitions", {})
                )
                domain_count = len(raw.get("domains", {}))
                bundles.append(
                    {
                        "key": bundle_key,
                        "name": meta.get("name", bundle_key),
                        "industry": meta.get("industry", "general"),
                        "description": meta.get("description", ""),
                        "standards_alignment": meta.get("standards_alignment", ""),
                        "entity_count": entity_count,
                        "domain_count": domain_count,
                    }
                )
            except Exception as e:
                logger.debug(f"Could not read bundle {fname}: {e}")
    return bundles


class OntologyLoader:
    """Loads and parses ontology configuration with robust fallbacks."""

    @staticmethod
    def load_config(config_path: str) -> Dict[str, Any]:
        """Load ontology configuration from YAML file with workspace-aware paths.

        Supports both standalone ontology configs (with top-level ``ontology`` key)
        and bundle configs (which also contain ``domains``, ``metadata``, and
        ``ontology.domain_entity_affinity``).  In both cases the returned dict
        is the ``ontology`` section.  When a bundle is loaded the
        ``domain_entity_affinity`` map is preserved inside the returned config so
        that ``load_domain_entity_affinity()`` can extract it at runtime.
        """
        paths_to_try = [
            config_path,
            f"../{config_path}",
            f"../../{config_path}",
            os.path.join(os.path.dirname(__file__), "..", "..", config_path),
            f"/Workspace/{config_path}",
            f"/Workspace/Repos/{config_path}",
        ]
        try:
            cwd = os.getcwd()
            paths_to_try.append(os.path.join(cwd, config_path))
            paths_to_try.append(os.path.join(cwd, "..", config_path))
        except Exception:
            pass

        for path in paths_to_try:
            try:
                if os.path.exists(path):
                    with open(path, "r") as f:
                        config = yaml.safe_load(f)
                    if config and "ontology" in config:
                        loaded_config = config.get("ontology", {})
                        OntologyLoader._validate_config(loaded_config)
                        metadata = config.get("metadata", {})
                        is_formal = metadata.get("bundle_type") == "formal_ontology"
                        OntologyLoader._validate_cross_refs(loaded_config, is_formal)
                        if "metadata" in config:
                            loaded_config["_bundle_metadata"] = config["metadata"]
                        fmt_ver = config.get("metadata", {}).get("format_version", "1.0")
                        loaded_config["_format_version"] = str(fmt_ver)
                        if str(fmt_ver).startswith("2"):
                            logger.info("Detected v2 bundle format at %s", path)
                        entity_count = len(
                            loaded_config.get("entities", {}).get("definitions", {})
                        )
                        logger.info(
                            f"Loaded ontology config from {path} with {entity_count} entity definitions"
                        )
                        return loaded_config
            except ValueError as e:
                logger.error(f"Invalid ontology config at {path}: {e}")
                raise
            except Exception as e:
                logger.debug(f"Could not load from {path}: {e}")

        tried = ", ".join(paths_to_try)
        logger.warning(
            "Could not load ontology config from any candidate path "
            "(config_path='%s'). Tried: %s. Using embedded defaults.",
            config_path, tried,
        )
        return OntologyLoader._default_config()

    @staticmethod
    def _default_config() -> Dict[str, Any]:
        """Return default ontology configuration with embedded entity definitions."""
        return {
            "version": "1.0",
            "entities": {
                "auto_discover": True,
                "discovery_confidence_threshold": 0.4,  # Lowered from 0.7
                "definitions": DEFAULT_ENTITY_DEFINITIONS,
            },
            "relationships": {
                "types": [
                    "owns",
                    "contains",
                    "references",
                    "derives_from",
                    "similar_to",
                ]
            },
            "metrics": {"auto_discover": False, "definitions": []},
        }

    @staticmethod
    def _validate_config(config: Dict[str, Any]) -> None:
        """Validate ontology config structure. Raises ValueError on critical issues."""
        entities = config.get("entities")
        if not entities or not isinstance(entities, dict):
            raise ValueError("ontology config missing required 'entities' section")

        definitions = entities.get("definitions")
        if not definitions or not isinstance(definitions, dict):
            raise ValueError(
                "ontology config missing required 'entities.definitions' (must be non-empty dict)"
            )

        for name, defn in definitions.items():
            if not isinstance(defn, dict):
                raise ValueError(
                    f"Entity '{name}' definition must be a dict, got {type(defn).__name__}"
                )
            if "description" not in defn:
                logger.warning(f"Entity '{name}' missing 'description'")
            if not isinstance(defn.get("keywords", []), list):
                raise ValueError(f"Entity '{name}'.keywords must be a list")
            if not isinstance(defn.get("typical_attributes", []), list):
                raise ValueError(f"Entity '{name}'.typical_attributes must be a list")

        validation = config.get("validation", {})
        if validation:
            for key in ("min_entity_confidence", "max_entities_per_table"):
                val = validation.get(key)
                if val is not None and not isinstance(val, (int, float)):
                    raise ValueError(
                        f"validation.{key} must be numeric, got {type(val).__name__}"
                    )

    _VALID_PROPERTY_ROLES = frozenset({
        "primary_key", "business_key", "object_property", "measure",
        "dimension", "temporal", "geographic", "label", "audit",
        "derived", "composite_component",
    })

    @staticmethod
    def _validate_cross_refs(config: Dict[str, Any], is_formal: bool = False) -> None:
        """Warn on referential integrity issues (never raises).

        Skipped for formal ontologies where relationship targets commonly
        reference FHIR datatypes (Reference, CodeableConcept, etc.) that
        are not entity definitions.
        """
        try:
            definitions = config.get("entities", {}).get("definitions", {})
            entity_names = set(definitions.keys())

            if not is_formal:
                for name, defn in definitions.items():
                    if not isinstance(defn, dict):
                        continue
                    for rel_name, rel_info in (defn.get("relationships") or {}).items():
                        target = rel_info.get("target") if isinstance(rel_info, dict) else None
                        if target and target not in entity_names:
                            logger.warning(
                                "Entity '%s' relationship '%s' targets undefined entity '%s'",
                                name, rel_name, target,
                            )

                    for prop_name, prop_info in (defn.get("properties") or {}).items():
                        if not isinstance(prop_info, dict):
                            continue
                        role = prop_info.get("role")
                        if role and role not in OntologyLoader._VALID_PROPERTY_ROLES:
                            logger.warning(
                                "Entity '%s' property '%s' uses unknown role '%s'",
                                name, prop_name, role,
                            )

            edge_catalog = config.get("edge_catalog", {})
            if not is_formal and edge_catalog:
                for edge_name, info in edge_catalog.items():
                    if not isinstance(info, dict):
                        continue
                    domain = info.get("domain") or info.get("source")
                    rng = info.get("range") or info.get("target")
                    if domain and domain != "Any" and domain not in entity_names:
                        logger.warning(
                            "edge_catalog '%s' domain '%s' is not a defined entity",
                            edge_name, domain,
                        )
                    if rng and rng != "Any" and rng not in entity_names:
                        logger.warning(
                            "edge_catalog '%s' range '%s' is not a defined entity",
                            edge_name, rng,
                        )
        except Exception as e:
            logger.debug("Cross-reference validation skipped: %s", e)

    @staticmethod
    def get_entity_definitions(config: Dict[str, Any]) -> List[EntityDefinition]:
        """Extract entity definitions from config, using defaults if empty.

        Supports both the new ``relationships`` map format and the legacy
        ``typical_relationships`` flat list.  When the new format is present
        it takes precedence; otherwise the flat list is converted into a
        dict keyed by relationship name with empty target/cardinality.

        Also parses the ``properties`` block per entity into
        ``PropertyDefinition`` objects for bundle-driven classification.
        """
        definitions = config.get("entities", {}).get("definitions", {})

        if not definitions:
            logger.info("No entity definitions in config, using embedded defaults")
            definitions = DEFAULT_ENTITY_DEFINITIONS

        entities = []
        for name, details in definitions.items():
            rels: Dict[str, Dict[str, str]] = {}
            if "relationships" in details and isinstance(details["relationships"], dict):
                for rel_name, rel_info in details["relationships"].items():
                    if isinstance(rel_info, dict):
                        rels[rel_name] = {k: str(v) for k, v in rel_info.items()}
                    else:
                        rels[rel_name] = {"target": str(rel_info)}
            elif "typical_relationships" in details:
                for rel_name in details["typical_relationships"]:
                    rels[str(rel_name)] = {}

            props: List[PropertyDefinition] = []
            raw_props = details.get("properties", {})
            if isinstance(raw_props, dict):
                for prop_name, prop_info in raw_props.items():
                    if not isinstance(prop_info, dict):
                        continue
                    props.append(
                        PropertyDefinition(
                            name=prop_name,
                            kind=prop_info.get("kind", "data_property"),
                            role=prop_info.get("role", "attribute"),
                            typical_attributes=prop_info.get("typical_attributes", []),
                            edge=prop_info.get("edge"),
                            target_entity=prop_info.get("target_entity"),
                            datatype=prop_info.get("datatype"),
                            composite_columns=prop_info.get("composite_columns"),
                            uri=prop_info.get("uri"),
                            cardinality=prop_info.get("cardinality"),
                            inverse=prop_info.get("inverse"),
                        )
                    )

            # v2 owl_properties (list of dicts) -- merge into props, skip duplicates
            prop_names = {p.name for p in props}
            for owl_prop in details.get("owl_properties", []):
                if not isinstance(owl_prop, dict):
                    continue
                owl_name = owl_prop.get("name", "")
                if owl_name in prop_names:
                    continue
                prop_names.add(owl_name)
                props.append(
                    PropertyDefinition(
                        name=owl_prop.get("name", ""),
                        kind=owl_prop.get("type", "data_property"),
                        role=owl_prop.get("type", "attribute"),
                        uri=owl_prop.get("uri"),
                        datatype=owl_prop.get("datatype"),
                        target_entity=owl_prop.get("range"),
                        cardinality=owl_prop.get("cardinality"),
                        inverse=owl_prop.get("inverse"),
                    )
                )

            entities.append(
                EntityDefinition(
                    name=name,
                    description=details.get("description", f"{name} entity"),
                    keywords=details.get("keywords", []),
                    typical_attributes=details.get("typical_attributes", []),
                    relationships=rels,
                    synonyms=details.get("synonyms", []),
                    business_questions=details.get("business_questions", []),
                    parent=details.get("parent") or details.get("subclass_of") or (
                        details.get("parents", [None])[0]
                        if isinstance(details.get("parents"), list) and details.get("parents")
                        else None
                    ),
                    properties=props,
                    uri=details.get("uri"),
                    source_ontology=details.get("source_ontology"),
                    subclass_of=details.get("subclass_of"),
                    owl_equivalent_class=details.get("owl_equivalent_class"),
                    owl_properties=details.get("owl_properties", []),
                )
            )

        logger.info(f"Loaded {len(entities)} entity definitions")
        return entities

    @staticmethod
    def get_property_roles(config: Dict[str, Any]) -> Dict[str, Dict[str, str]]:
        """Extract the global property_roles taxonomy from config."""
        return config.get("property_roles", {})

    _STRUCTURAL_EDGES: Dict[str, Dict[str, Any]] = {
        "instance_of": {"inverse": "type_of", "symmetric": False, "category": "structural"},
        "subclass_of": {"inverse": "superclass_of", "symmetric": False, "category": "structural"},
        "has_part": {"inverse": "part_of", "symmetric": False, "category": "structural"},
        "contains": {"inverse": "contained_in", "symmetric": False, "category": "structural"},
        "member_of": {"inverse": "has_member", "symmetric": False, "category": "structural"},
        # categorized_as is emitted deterministically by _build_category_edges
        # (entity -> W5 category node). Auto-merged here (not persisted to bundle
        # edge_catalog/tiers) so it is never offered to the LLM edge predictor and
        # never wildcard-matched by find_edge for FK/discovered relationships.
        "categorized_as": {"inverse": "category_of", "symmetric": False, "category": "structural"},
    }

    _INFER_BLOCKLIST: frozenset = frozenset({
        "about", "subjectOf", "type_of", "instance_of", "is_a",
        "subclass_of", "superclass_of", "has_part", "part_of",
        "contains", "contained_in", "member_of", "has_member",
        "categorized_as", "category_of",
    })

    @staticmethod
    def get_edge_catalog(config: Dict[str, Any], bundle_name: Optional[str] = None) -> Dict[str, EdgeCatalogEntry]:
        """Extract the global edge catalog from config.

        Structural edges (instance_of, subclass_of, has_part, contains,
        member_of) are auto-merged when not explicitly defined so that
        hierarchy and structural edge operations work for all bundles.

        When *bundle_name* is provided it is stamped on every entry so
        that ``EdgeCatalog.find_edge`` can prefer same-bundle matches.
        """
        raw = config.get("edge_catalog", {})
        catalog: Dict[str, EdgeCatalogEntry] = {}
        for edge_name, info in raw.items():
            if not isinstance(info, dict):
                continue
            catalog[edge_name] = EdgeCatalogEntry(
                name=edge_name,
                inverse=info.get("inverse"),
                domain=info.get("domain") or info.get("source"),
                range=info.get("range") or info.get("target"),
                symmetric=info.get("symmetric", False),
                category=info.get("category", "business"),
                uri=info.get("uri"),
                owl_type=info.get("owl_type"),
                bundle_name=bundle_name,
            )
        for sname, sinfo in OntologyLoader._STRUCTURAL_EDGES.items():
            if sname not in catalog:
                catalog[sname] = EdgeCatalogEntry(
                    name=sname,
                    inverse=sinfo["inverse"],
                    symmetric=sinfo["symmetric"],
                    category=sinfo["category"],
                )
        return catalog


class EntityDiscoverer:
    """Discovers entities from knowledge base tables with flexible matching.

    Uses structured LLM output (ChatDatabricks), keyword scoring with
    domain-aware boosting, value enforcement, deduplication, and multi-entity
    support for relationship tables.
    """

    CONFIDENCE_PENALTY_SNAP = 0.1
    PRIMITIVE_TYPE_NAMES = frozenset({
        "boolean", "integer", "float", "number", "text", "date",
        "datetime", "time", "url", "datatypeclass",
    })

    def __init__(
        self,
        spark: SparkSession,
        config: OntologyConfig,
        ontology_config: Dict[str, Any],
        domain_entity_affinity: Optional[Dict[str, set]] = None,
        model_endpoint: Optional[str] = None,
    ):
        self.spark = spark
        self.config = config
        self.ontology_config = ontology_config
        self.entity_definitions = OntologyLoader.get_entity_definitions(ontology_config)
        self._domain_entity_affinity = (
            domain_entity_affinity or load_domain_entity_affinity(ontology_config)
        )
        self._validation_cfg = ontology_config.get("validation", {})
        self._relationship_types = {
            r["name"] if isinstance(r, dict) else r
            for r in ontology_config.get("relationships", {}).get("types", [])
        }
        self._model_endpoint = model_endpoint or self._validation_cfg.get(
            "classification_model",
            DEFAULT_CLASSIFICATION_MODEL,
        )
        self._entity_names = [
            e.name for e in self.entity_definitions if e.name != "DataTable"
        ]
        self._property_roles = OntologyLoader.get_property_roles(ontology_config)
        self._edge_catalog_entries = OntologyLoader.get_edge_catalog(
            ontology_config, bundle_name=getattr(config, "ontology_bundle", None)
        )
        self._bundle_geo_patterns = self._build_bundle_geo_patterns()
        self._edge_catalog = EdgeCatalog(self._edge_catalog_entries)
        self._entity_def_map: Dict[str, EntityDefinition] = {
            e.name: e for e in self.entity_definitions
        }
        self._stats = {
            "keyword_matches": 0,
            "ai_classifications": 0,
            "fallback_generic": 0,
            "column_keyword_matches": 0,
            "column_ai_classifications": 0,
            "column_fallback": 0,
        }

        # Three-pass prediction support (lazy init on first use)
        self._index_loader = None
        self._three_pass_available = None
        self._tier_dir = None

    def _build_bundle_geo_patterns(self) -> frozenset:
        """Collect keywords + typical_attributes from Geographic entities in the bundle."""
        geo_names = set()
        for e in self.entity_definitions:
            if e.name.lower() in ("geographic", "geocoordinate", "adminregion",
                                  "postalcode", "timezone", "address", "location"):
                geo_names.add(e.name)
            elif e.parent and e.parent.lower() in ("geographic", "location"):
                geo_names.add(e.name)
        if not geo_names:
            return frozenset()
        patterns: set = set()
        for e in self.entity_definitions:
            if e.name in geo_names:
                patterns.update(k.lower() for k in e.keywords)
                patterns.update(a.lower() for a in e.typical_attributes)
        return frozenset(patterns)

    def _get_bundle_version(self) -> str:
        """Derive a version string from the bundle config for incremental tracking.

        Must match OntologyBuilder._get_bundle_version() so the stored
        bundle_version column and incremental SQL comparison are consistent.
        """
        bundle = self.config.ontology_bundle or "default"
        ont = self.ontology_config.get("ontology", {}) or {}
        meta = self.ontology_config.get("metadata", {}) or {}
        ver = str(ont.get("version") or meta.get("version") or "1.0")
        return f"{bundle}:{ver}"

    # ------------------------------------------------------------------
    # Keyword matching helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _keyword_in_text(keyword: str, text: str, min_len: int = 4) -> bool:
        """Check if keyword appears in text at a word boundary.

        Returns False for short keywords (< min_len) to avoid common-word
        false positives like 'day', 'spa', 'set'. Uses negative lookaround
        for alphabetic chars so underscores, spaces, and string boundaries
        are treated as valid word separators.
        """
        if len(keyword) < min_len:
            return False
        pattern = r'(?<![a-zA-Z])' + re.escape(keyword) + r'(?![a-zA-Z])'
        return bool(re.search(pattern, text))

    # ------------------------------------------------------------------
    # LLM helpers
    # ------------------------------------------------------------------

    def _get_structured_llm(self):
        from dbxmetagen.chat_client import invoke_structured
        return _StructuredInvoker(
            invoke_structured, self._model_endpoint,
            EntityClassificationResult, 0.0, 512, 2,
        )

    def _get_batch_column_llm(self):
        from dbxmetagen.chat_client import invoke_structured
        # ON-19: raised 4096 -> 8192. One column emits ~75-80 output tokens of JSON;
        # a wide chunk (see _COLS_PER_CLASSIFY_CHUNK) plus headroom must fit under
        # this. A truncation still surfaces as StructuredTruncationError and drives
        # a sub-chunk retry, but the higher ceiling makes that rare.
        return _StructuredInvoker(
            invoke_structured, self._model_endpoint,
            BatchColumnClassificationResult, 0.0, 8192, 2,
        )

    def _get_batch_table_llm(self):
        from dbxmetagen.chat_client import invoke_structured
        return _StructuredInvoker(
            invoke_structured, self._model_endpoint,
            BatchTableClassificationResult, 0.0, 4096, 2,
        )

    @staticmethod
    def _format_entity_desc(e: "EntityDefinition") -> str:
        """Format an entity definition for use in classification prompts."""
        line = f"- {e.name}: {e.description}"
        if e.synonyms:
            line += f" (also known as: {', '.join(e.synonyms)})"
        return line

    def _get_column_summary(self, table_names: List[str]) -> Dict[str, str]:
        """Get top column names per table for enriching classification prompts."""
        if not table_names:
            return {}
        tbl_clause = ", ".join(f"'{t}'" for t in table_names)
        try:
            rows = self.spark.sql(
                f"SELECT table_name, column_name, data_type "
                f"FROM {self.config.fully_qualified_column_kb} "
                f"WHERE table_name IN ({tbl_clause}) "
                f"ORDER BY table_name, column_name"
            ).collect()
        except Exception:
            return {}
        by_table: Dict[str, List[str]] = {}
        for r in rows:
            by_table.setdefault(r.table_name, []).append(f"{r.column_name} {r.data_type}")
        return {t: ", ".join(cols[:10]) for t, cols in by_table.items()}

    # ------------------------------------------------------------------
    # Keyword scoring + domain-aware boosting
    # ------------------------------------------------------------------

    def _keyword_prefilter(
        self,
        name: str,
        comment: str,
        domain: str,
        top_n: int = 0,
    ) -> List[str]:
        """Score entity definitions by keyword overlap and domain affinity,
        returning the top-N candidate entity names for the LLM prompt.
        top_n=0 (default) returns all entity types, ranked by relevance."""
        name_lower = name.lower()
        comment_lower = (comment or "").lower()
        domain_lower = (domain or "").lower()

        affinity_set = self._domain_entity_affinity.get(domain_lower, set())

        scored: List[Tuple[str, float]] = []
        max_kw_only = 0.0
        for edef in self.entity_definitions:
            if edef.name == "DataTable":
                continue
            kw_score = 0.0
            all_terms = list(edef.keywords) + list(edef.synonyms)
            for kw in all_terms:
                kw_l = kw.lower()
                if kw_l in name_lower:
                    kw_score += 2.0
                elif self._keyword_in_text(kw_l, comment_lower):
                    kw_score += 1.0
            max_kw_only = max(max_kw_only, kw_score)
            has_affinity = edef.name in affinity_set
            scored.append((edef.name, kw_score, has_affinity))

        # If a strong keyword match exists for some entity, reduce the boost
        # for entities that scored purely from domain affinity (no keyword hit).
        has_strong_kw_competitor = max_kw_only >= 2.0
        final: List[Tuple[str, float]] = []
        for ename, kw_score, has_affinity in scored:
            total = kw_score
            if has_affinity:
                if kw_score == 0.0 and has_strong_kw_competitor:
                    total += 0.75  # halved affinity when outcompeted by keywords
                else:
                    total += 1.5
            final.append((ename, total))

        final.sort(key=lambda x: x[1], reverse=True)
        if top_n <= 0 or top_n >= len(final):
            return [s[0] for s in final]
        return [s[0] for s in final[:top_n]]

    # ------------------------------------------------------------------
    # Table-level discovery
    # ------------------------------------------------------------------

    def discover_entities_from_tables(self) -> List[Dict[str, Any]]:
        """Discover entities by matching tables to entity definitions."""
        current_bv = self._get_bundle_version()
        names = self.config.table_names or []
        tf_kb = table_filter_sql(names, column="kb.table_name")
        tf = table_filter_sql(names, column="table_name")
        infra_filter_kb = infrastructure_exclude_sql(column="kb.table_name") if self.config.exclude_infrastructure else ""
        infra_filter = infrastructure_exclude_sql(column="table_name") if self.config.exclude_infrastructure else ""
        try:
            if self.config.incremental:
                try:
                    tables_df = self.spark.sql(
                        f"""
                        SELECT kb.table_name, kb.table_short_name, kb.comment, kb.domain
                        FROM {self.config.fully_qualified_kb} kb
                        LEFT JOIN (
                            SELECT src_table, MAX(created_at) AS last_classified,
                                   MAX(bundle_version) AS last_bundle_version
                            FROM (
                                SELECT EXPLODE(source_tables) AS src_table, created_at, bundle_version
                                FROM {self.config.fully_qualified_entities}
                                WHERE COALESCE(attributes['granularity'], 'table') = 'table'
                            )
                            GROUP BY src_table
                        ) oe ON kb.table_name = oe.src_table
                        WHERE kb.table_name IS NOT NULL
                          AND (oe.last_classified IS NULL
                               OR kb.updated_at > oe.last_classified
                               OR COALESCE(oe.last_bundle_version, '') != '{current_bv}')
                          {tf_kb}
                          {infra_filter_kb}
                    """
                    )
                    table_count = tables_df.count()
                    total = self.spark.sql(
                        f"SELECT COUNT(*) AS n FROM {self.config.fully_qualified_kb} WHERE 1=1 {tf} {infra_filter}"
                    ).collect()[0].n
                    logger.info(f"Incremental mode: {table_count} tables need classification out of {total}")
                except Exception as e:
                    logger.warning(f"Incremental filtering failed ({e}), falling back to full scan")
                    tables_df = self.spark.sql(
                        f"""
                        SELECT table_name, table_short_name, comment, domain
                        FROM {self.config.fully_qualified_kb}
                        WHERE 1=1 {tf} {infra_filter}
                    """
                    )
                    table_count = tables_df.count()
            else:
                tables_df = self.spark.sql(
                    f"""
                    SELECT table_name, table_short_name, comment, domain
                    FROM {self.config.fully_qualified_kb}
                    WHERE 1=1 {tf} {infra_filter}
                """
                )
                table_count = tables_df.count()
        except Exception as e:
            logger.error(f"Could not read from knowledge base: {e}")
            return []

        if table_count == 0:
            logger.warning(
                f"Knowledge base table {self.config.fully_qualified_kb} is empty "
                "or all tables are up-to-date (incremental mode). "
                "Run build_knowledge_base first to populate it."
            )
            return []

        logger.info(f"Evaluating {table_count} tables for entity classification")

        discovered = []
        tables_without_matches = []

        for row in tables_df.collect():
            matches = self._match_table_to_entities(row)
            if matches:
                discovered.extend(matches)
                self._stats["keyword_matches"] += 1
            else:
                tables_without_matches.append(row)

        if tables_without_matches:
            n = len(tables_without_matches)
            batch_size = 15
            chunks = [
                tables_without_matches[i : i + batch_size]
                for i in range(0, n, batch_size)
            ]
            logger.info(
                f"Using AI to classify {n} unmatched tables in {len(chunks)} batches of <={batch_size}"
            )

            from concurrent.futures import ThreadPoolExecutor, as_completed

            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = {
                    executor.submit(self._ai_classify_tables_batch, chunk): chunk
                    for chunk in chunks
                }
                for future in as_completed(futures):
                    for table_entities in future.result():
                        discovered.extend(table_entities)

        logger.info(
            f"Entity discovery complete: {self._stats['keyword_matches']} keyword matches, "
            f"{self._stats['ai_classifications']} AI classifications, "
            f"{self._stats['fallback_generic']} generic fallbacks"
        )
        return discovered

    def _normalize_name(self, name: str) -> List[str]:
        """Generate name variations for flexible matching."""
        if not name:
            return []
        name = name.lower()
        variations = [name, name.replace("_", " "), name.replace("_", "")]
        if name.endswith("ies"):
            variations.append(name[:-3] + "y")
        elif name.endswith("es"):
            variations.append(name[:-2])
        elif name.endswith("s"):
            variations.append(name[:-1])
        variations.append(name + "s")
        return list(set(variations))

    def _match_table_to_entities(self, table_row) -> List[Dict[str, Any]]:
        """Match a table to potential entity definitions with flexible matching."""
        matches = []
        table_name = table_row.table_name
        short_name = (table_row.table_short_name or "").lower()
        comment = (table_row.comment or "").lower()
        name_variations = self._normalize_name(short_name)

        threshold = self.ontology_config.get("entities", {}).get(
            "discovery_confidence_threshold", 0.4
        )

        for entity_def in self.entity_definitions:
            confidence = self._calculate_match_confidence(
                name_variations, short_name, comment, entity_def
            )
            if confidence >= threshold:
                matches.append(
                    {
                        "entity_id": str(uuid.uuid4()),
                        "entity_name": entity_def.name,
                        "entity_type": entity_def.name,
                        "description": entity_def.description,
                        "source_tables": [table_name],
                        "source_columns": [],
                        "attributes": {
                            "expected_attributes": str(entity_def.typical_attributes),
                            "discovery_method": "keyword",
                        },
                        "confidence": confidence,
                        "auto_discovered": True,
                        "validated": False,
                        "validation_notes": None,
                        "entity_uri": getattr(entity_def, "uri", None),
                        "source_ontology": getattr(entity_def, "source_ontology", None),
                    }
                )
        return matches

    def _calculate_match_confidence(
        self,
        name_variations: List[str],
        original_name: str,
        comment: str,
        entity_def: EntityDefinition,
    ) -> float:
        """Calculate confidence score with flexible matching."""
        score = 0.0
        max_score = 0.0
        for keyword in entity_def.keywords:
            keyword_lower = keyword.lower()
            keyword_variations = self._normalize_name(keyword)
            max_score += 2.0
            if keyword_lower == original_name:
                score += 2.0
                continue
            matched = False
            for kw_var in keyword_variations:
                for name_var in name_variations:
                    if kw_var in name_var or name_var in kw_var:
                        score += 1.5
                        matched = True
                        break
                if matched:
                    break
            if not matched and self._keyword_in_text(keyword_lower, comment):
                score += 0.8
        for attr in entity_def.typical_attributes:
            max_score += 0.3
            if self._keyword_in_text(attr.lower(), comment):
                score += 0.3
        if max_score == 0:
            return 0.0
        raw = min(1.0, score / max_score)
        if entity_def.name.lower() in self.PRIMITIVE_TYPE_NAMES:
            raw *= 0.3
        return raw

    # ------------------------------------------------------------------
    # AI classification for tables (structured output + enforce + multi-entity)
    # ------------------------------------------------------------------

    def _ai_classify_tables_batch(
        self, table_rows: List, batch_size: int = 15
    ) -> List[List[Dict[str, Any]]]:
        """Classify a batch of tables in one LLM call.

        Returns a list parallel to table_rows, each element being the
        list of entity dicts for that table (same format as _ai_classify_table).
        Falls back to per-table classification on failure.
        """
        candidate_set: set = set()
        for row in table_rows:
            short = row.table_short_name or row.table_name.split(".")[-1]
            comment = row.comment or ""
            domain = getattr(row, "domain", None) or "unknown"
            candidate_set.update(self._keyword_prefilter(short, comment, domain))

        entity_descriptions = "\n".join(
            self._format_entity_desc(e)
            for e in self.entity_definitions
            if e.name in candidate_set
        )

        col_summaries = self._get_column_summary([r.table_name for r in table_rows])
        table_lines = []
        for i, row in enumerate(table_rows):
            short = row.table_short_name or row.table_name.split(".")[-1]
            comment = (row.comment or "No description")[:400]
            domain = getattr(row, "domain", None) or "unknown"
            line = f"{i+1}. {short} | Domain: {domain} | {comment}"
            cols_text = col_summaries.get(row.table_name, "")
            if cols_text:
                line += f" | Columns: {cols_text}"
            table_lines.append(line)
        tables_text = "\n".join(table_lines)

        system_prompt = (
            "You are an entity classifier for database tables. "
            "For each table, classify it into an entity type. "
            "Prefer domain-relevant business entities (e.g. Patient, Order, Product) over "
            "data-type primitives (e.g. Boolean, Integer, Text) -- primitive types describe "
            "column data types, not what a table represents. "
            "If a table clearly represents a relationship between two entities, "
            "also populate secondary_entity_type. "
            "If your confidence is below 0.5, populate recommended_entity. "
            "Tables with similar names, structures, or descriptions should receive similar confidence scores. "
            "If two tables contain essentially the same data (e.g., different sample sizes of the same source), "
            "they should get the same entity type and similar confidence. "
            "Return one classification per table, using the exact table_name provided."
        )
        user_prompt = (
            f"Tables:\n{tables_text}\n\n"
            f"Available entity types:\n{entity_descriptions}\n\n"
            "Classify every table listed above."
        )

        try:
            batch_llm = self._get_batch_table_llm()
            response: BatchTableClassificationResult = batch_llm.invoke(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ]
            )

            short_to_row = {}
            for row in table_rows:
                short = row.table_short_name or row.table_name.split(".")[-1]
                short_to_row[short.lower()] = row

            all_results: List[List[Dict[str, Any]]] = [[] for _ in table_rows]
            row_index = {id(r): i for i, r in enumerate(table_rows)}

            for item in response.classifications:
                matched_row = short_to_row.get(item.table_name.lower())
                if matched_row is None:
                    continue
                idx = row_index.get(id(matched_row))
                if idx is None:
                    continue

                table_name = matched_row.table_name
                enforced, exact = _enforce_entity_value(item.entity_type, self._entity_names)
                confidence = item.confidence
                if not exact:
                    confidence = max(0.0, confidence - self.CONFIDENCE_PENALTY_SNAP)

                edef = next((e for e in self.entity_definitions if e.name == enforced), None)
                attrs: Dict[str, str] = {"discovery_method": "ai_batch"}
                if item.reasoning:
                    attrs["reasoning"] = item.reasoning
                if item.recommended_entity:
                    attrs["recommended_entity"] = item.recommended_entity

                all_results[idx].append({
                    "entity_id": str(uuid.uuid4()),
                    "entity_name": enforced,
                    "entity_type": enforced,
                    "description": edef.description if edef else f"Auto-classified as {enforced}",
                    "source_tables": [table_name],
                    "source_columns": [],
                    "attributes": attrs,
                    "confidence": round(confidence, 3),
                    "auto_discovered": True,
                    "validated": False,
                    "validation_notes": item.reasoning,
                    "entity_uri": edef.uri if edef else None,
                    "source_ontology": edef.source_ontology if edef else None,
                })
                self._stats["ai_classifications"] += 1

                if item.secondary_entity_type:
                    sec_enforced, sec_exact = _enforce_entity_value(
                        item.secondary_entity_type, self._entity_names
                    )
                    sec_conf = item.confidence * 0.85
                    if not sec_exact:
                        sec_conf = max(0.0, sec_conf - self.CONFIDENCE_PENALTY_SNAP)
                    min_conf = self._validation_cfg.get("min_entity_confidence", 0.5)
                    if sec_conf >= min_conf and sec_enforced != enforced:
                        sec_edef = next(
                            (e for e in self.entity_definitions if e.name == sec_enforced), None
                        )
                        all_results[idx].append({
                            "entity_id": str(uuid.uuid4()),
                            "entity_name": sec_enforced,
                            "entity_type": sec_enforced,
                            "description": sec_edef.description if sec_edef else f"Secondary: {sec_enforced}",
                            "source_tables": [table_name],
                            "source_columns": [],
                            "attributes": {"discovery_method": "ai_batch_secondary", "reasoning": item.reasoning or ""},
                            "confidence": round(sec_conf, 3),
                            "auto_discovered": True,
                            "validated": False,
                            "validation_notes": f"Secondary entity from batch classification of {table_name}",
                            "entity_uri": getattr(sec_edef, "uri", None) if sec_edef else None,
                            "source_ontology": getattr(sec_edef, "source_ontology", None) if sec_edef else None,
                        })

            for i, row in enumerate(table_rows):
                if not all_results[i]:
                    all_results[i] = self._ai_classify_table(row)

            three_pass_threshold = self._validation_cfg.get("three_pass_upgrade_threshold", 0.6)
            max_upgrades = int(self._validation_cfg.get("max_three_pass_upgrades", 10))
            loader = self._get_index_loader()
            if loader:
                candidates = [
                    (i, all_results[i][0].get("confidence", 1.0))
                    for i in range(len(table_rows))
                    if all_results[i] and all_results[i][0].get("confidence", 1.0) < three_pass_threshold
                ]
                candidates.sort(key=lambda x: x[1])
                if len(candidates) > max_upgrades:
                    logger.info("Three-pass upgrade: capping %d candidates to %d", len(candidates), max_upgrades)
                    candidates = candidates[:max_upgrades]
                for i, conf in candidates:
                    top = all_results[i][0]
                    row = table_rows[i]
                    upgraded = self._three_pass_classify_table(row)
                    if upgraded and upgraded[0].get("confidence", 0) > conf:
                        logger.info("Three-pass upgrade %s: %.2f -> %.2f",
                                    row["table_name"] if "table_name" in row else "", conf, upgraded[0]["confidence"])
                        secondaries = all_results[i][1:]
                        all_results[i] = upgraded + secondaries

            return all_results

        except Exception as e:
            msg = (
                f"Batch table classification failed ({len(table_rows)} tables): "
                f"{type(e).__name__}: {e}. Falling back to per-table classification."
            )
            logger.warning(msg)
            return [self._ai_classify_table(row) for row in table_rows]

    def _get_index_loader(self):
        """Lazy-init the OntologyIndexLoader for three-pass prediction."""
        if self._three_pass_available is None:
            try:
                from dbxmetagen.ontology_index import OntologyIndexLoader
                bundle = self.config.ontology_bundle or "general"
                resolved_yaml = resolve_bundle_path(
                    bundle, self.config.catalog_name, self.config.schema_name
                )
                stem = Path(resolved_yaml).stem
                base = _resolve_tier_dir(resolved_yaml)
                self._tier_dir = base
                self._index_loader = OntologyIndexLoader(bundle_name=stem, base_dir=base)
                self._three_pass_available = self._index_loader.has_tier_indexes
                if self._three_pass_available:
                    logger.info(
                        "Three-pass prediction enabled (%d tier-1 entities)",
                        self._index_loader.entity_count(),
                    )
                else:
                    msg = (
                        f"Formal ontology grounding OFF for bundle '{bundle}': no tier index files found. "
                        "Entity classification will use single-pass LLM without FHIR/OMOP/Schema.org alignment. "
                        "Run scripts/build_ontology_indexes.py to generate tier indexes."
                    )
                    logger.warning(msg)
            except Exception as e:
                logger.debug("Three-pass prediction not available: %s", e)
                self._three_pass_available = False
        return self._index_loader if self._three_pass_available else None

    def _three_pass_classify_table(self, table_row) -> Optional[List[Dict[str, Any]]]:
        """Attempt three-pass classification using tiered indexes.
        Returns None if tier indexes are unavailable (caller falls back to single-pass).
        """
        loader = self._get_index_loader()
        if not loader:
            return None

        from dbxmetagen.ontology_predictor import predict_entity

        table_name = table_row.table_name
        short_name = table_row.table_short_name or table_name.split(".")[-1]
        comment = table_row.comment or ""
        col_summary = self._get_column_summary([table_name])
        columns = col_summary.get(table_name, "")

        def llm_fn(system_prompt: str, user_prompt: str) -> str:
            from databricks_langchain import ChatDatabricks
            llm = ChatDatabricks(
                endpoint=self._model_endpoint, temperature=0.0,
                max_tokens=2048, max_retries=2,
            )
            response = llm.invoke([
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ])
            return response.content if hasattr(response, "content") else str(response)

        from dbxmetagen.ontology_provenance import compute_tier_index_hash, read_bundle_metadata_version

        bundle = self.config.ontology_bundle or "healthcare"
        bundle_yaml = Path(
            resolve_bundle_path(bundle, self.config.catalog_name, self.config.schema_name)
        )
        tier_dir = Path(self._tier_dir) if getattr(self, "_tier_dir", None) else bundle_yaml.parent / bundle_yaml.stem
        tier_hash = compute_tier_index_hash(tier_dir) if tier_dir.is_dir() else ""
        bundle_ver = read_bundle_metadata_version(bundle_yaml) or ""

        domain_hint = getattr(table_row, "primary_domain", None) or getattr(
            table_row, "domain", None
        )

        vs_index = getattr(self.config, "ontology_vs_index", "") or ""
        effective_pass0 = getattr(self.config, "pass0_mode", "off")
        if vs_index and effective_pass0 != "vector":
            effective_pass0 = "vector"

        result = predict_entity(
            table_name=short_name,
            columns=columns,
            sample=f"Description: {comment[:500]}",
            loader=loader,
            llm_fn=llm_fn,
            pass0_mode=effective_pass0,
            pass0_max_candidates=getattr(self.config, "pass0_max_candidates", 48),
            pass0_min_candidates=getattr(self.config, "pass0_min_candidates", 12),
            domain_hint=str(domain_hint) if domain_hint else None,
            domain_entity_affinity=getattr(self, "_domain_entity_affinity", None),
            vs_index=vs_index if effective_pass0 == "vector" else None,
            vs_bundle=bundle if effective_pass0 == "vector" else None,
            vs_endpoint=self.config.vs_endpoint_name,
        )

        # Accept any entity name the LLM was shown (tier-1) plus bundle definitions
        tier1_names = [e["name"] for e in loader.get_entities_tier1()]
        allowed = list(set(self._entity_names) | set(tier1_names))
        enforced, exact = _enforce_entity_value(result.predicted_entity, allowed)
        if not exact:
            logger.info("Three-pass entity '%s' snapped to '%s'", result.predicted_entity, enforced)
            result = dc_replace(
                result,
                predicted_entity=enforced,
                confidence_score=max(0.0, result.confidence_score - self.CONFIDENCE_PENALTY_SNAP),
            )

        edef = next((e for e in self.entity_definitions if e.name == enforced), None)
        # Canonical URI/vocabulary from bundle definition when snapped to a known type
        if edef:
            canon_uri = edef.uri
            canon_so = edef.source_ontology
        else:
            canon_uri = result.equivalent_class_uri
            canon_so = result.source_ontology or None
        attr_extra = {}
        if edef and result.equivalent_class_uri and result.equivalent_class_uri != (edef.uri or ""):
            attr_extra["llm_equivalent_class_uri"] = result.equivalent_class_uri
        if edef and result.source_ontology and result.source_ontology != (edef.source_ontology or ""):
            attr_extra["llm_source_ontology"] = result.source_ontology
        entity_dict = {
            "entity_id": str(uuid.uuid4()),
            "entity_name": enforced,
            "entity_type": enforced,
            "description": edef.description if edef else result.rationale,
            "source_tables": [table_name],
            "source_columns": [],
            "attributes": {
                "discovery_method": f"three_pass_{result.passes_run}",
                "reasoning": result.rationale,
                "ontology_bundle": bundle,
                "ontology_bundle_version": bundle_ver,
                "tier_index_hash": tier_hash,
                **({"owl_properties": str(result.matched_properties)} if result.matched_properties else {}),
                **attr_extra,
            },
            "confidence": round(result.confidence_score, 3),
            "auto_discovered": True,
            "validated": False,
            "validation_notes": result.rationale,
            "entity_uri": canon_uri,
            "source_ontology": canon_so,
        }
        if result.needs_human_review:
            entity_dict["attributes"]["needs_human_review"] = "true"

        logger.info(
            "Three-pass classified %s -> %s (%.2f, %d passes)",
            short_name, result.predicted_entity, result.confidence_score, result.passes_run,
        )
        return [entity_dict]

    def _ai_classify_table(self, table_row) -> List[Dict[str, Any]]:
        """Classify a table using structured LLM output. May return 1-2 entities
        (primary + optional secondary for relationship tables).
        
        Attempts three-pass classification first if tier indexes are available."""
        try:
            three_pass = self._three_pass_classify_table(table_row)
            if three_pass is not None:
                return three_pass
        except Exception as e:
            logger.warning("Three-pass classification failed for %s, falling back to single-pass: %s",
                           table_row.table_name, e)
        table_name = table_row.table_name
        short_name = table_row.table_short_name or table_name.split(".")[-1]
        comment = table_row.comment or "No description available"
        domain = getattr(table_row, "domain", None) or "unknown"

        candidates = self._keyword_prefilter(short_name, comment, domain)
        entity_descriptions = "\n".join(
            self._format_entity_desc(e)
            for e in self.entity_definitions
            if e.name in candidates
        )

        system_prompt = (
            "You are an entity classifier for database tables. "
            "Classify each table into an entity type. "
            "Prefer domain-relevant business entities (e.g. Patient, Order, Product) over "
            "data-type primitives (e.g. Boolean, Integer, Text) -- primitive types describe "
            "column data types, not what a table represents. "
            "If the table clearly represents a relationship between two entities "
            "(e.g. patient_encounters links Patient and Encounter), also populate secondary_entity_type. "
            "If your confidence is below 0.5, populate recommended_entity with what you think "
            "the entity should really be called, even if it is not in the provided list."
        )
        col_summary = self._get_column_summary([table_row.table_name])
        cols_text = col_summary.get(table_row.table_name, "")
        user_prompt = (
            f"Table name: {short_name}\n"
            f"Description: {comment[:500]}\n"
            f"Domain: {domain}\n"
        )
        if cols_text:
            user_prompt += f"Columns: {cols_text}\n"
        user_prompt += (
            f"\nAvailable entity types:\n{entity_descriptions}\n\n"
            "Classify this table."
        )

        results = []
        try:
            structured_llm = self._get_structured_llm()
            response: EntityClassificationResult = structured_llm.invoke(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ]
            )

            # --- primary entity ---
            enforced, exact = _enforce_entity_value(
                response.entity_type, self._entity_names
            )
            confidence = response.confidence
            if not exact:
                confidence = max(0.0, confidence - self.CONFIDENCE_PENALTY_SNAP)
                logger.debug(
                    f"Snapped '{response.entity_type}' -> '{enforced}' for {short_name}"
                )

            attrs: Dict[str, str] = {"discovery_method": "ai"}
            if response.reasoning:
                attrs["reasoning"] = response.reasoning
            if response.recommended_entity:
                attrs["recommended_entity"] = response.recommended_entity

            edef = next(
                (e for e in self.entity_definitions if e.name == enforced), None
            )
            entity_dict = {
                "entity_id": str(uuid.uuid4()),
                "entity_name": enforced,
                "entity_type": enforced,
                "description": (
                    edef.description if edef else f"Auto-classified as {enforced}"
                ),
                "source_tables": [table_name],
                "source_columns": [],
                "attributes": attrs,
                "confidence": round(confidence, 3),
                "auto_discovered": True,
                "validated": False,
                "validation_notes": response.reasoning,
                "entity_uri": edef.uri if edef else None,
                "source_ontology": edef.source_ontology if edef else None,
            }
            results.append(entity_dict)
            self._stats["ai_classifications"] += 1

            # --- secondary entity (multi-entity support) ---
            if response.secondary_entity_type:
                sec_enforced, sec_exact = _enforce_entity_value(
                    response.secondary_entity_type,
                    self._entity_names,
                )
                sec_conf = response.confidence * 0.85
                if not sec_exact:
                    sec_conf = max(0.0, sec_conf - self.CONFIDENCE_PENALTY_SNAP)
                min_conf = self._validation_cfg.get("min_entity_confidence", 0.5)
                if sec_conf >= min_conf and sec_enforced != enforced:
                    sec_edef = next(
                        (e for e in self.entity_definitions if e.name == sec_enforced),
                        None,
                    )
                    results.append(
                        {
                            "entity_id": str(uuid.uuid4()),
                            "entity_name": sec_enforced,
                            "entity_type": sec_enforced,
                            "description": (
                                sec_edef.description
                                if sec_edef
                                else f"Secondary: {sec_enforced}"
                            ),
                            "source_tables": [table_name],
                            "source_columns": [],
                            "attributes": {
                                "discovery_method": "ai_secondary",
                                "reasoning": response.reasoning or "",
                            },
                            "confidence": round(sec_conf, 3),
                            "auto_discovered": True,
                            "validated": False,
                            "validation_notes": f"Secondary entity from relationship table {short_name}",
                            "entity_uri": getattr(sec_edef, "uri", None) if sec_edef else None,
                            "source_ontology": getattr(sec_edef, "source_ontology", None) if sec_edef else None,
                        }
                    )

        except Exception as e:
            logger.warning(
                f"AI classification failed for {table_name}, using fallback: {e}"
            )
            self._stats["fallback_generic"] += 1
            results.append(
                {
                    "entity_id": str(uuid.uuid4()),
                    "entity_name": "DataTable",
                    "entity_type": "DataTable",
                    "description": "Generic data table (AI classification failed)",
                    "source_tables": [table_name],
                    "source_columns": [],
                    "attributes": {"discovery_method": "ai_fallback"},
                    "confidence": 0.3,
                    "auto_discovered": True,
                    "validated": False,
                    "validation_notes": str(e),
                    "entity_uri": None,
                    "source_ontology": None,
                }
            )
        return results

    # ------------------------------------------------------------------
    # Column-level entity discovery
    # ------------------------------------------------------------------

    def discover_entities_from_columns(self) -> List[Dict[str, Any]]:
        """Discover entities by matching columns to entity definitions."""
        current_bv = self._get_bundle_version()
        names = self.config.table_names or []
        tf_ckb = table_filter_sql(names, column="ckb.table_name")
        tf = table_filter_sql(names, column="table_name")
        try:
            if self.config.incremental:
                try:
                    cols_df = self.spark.sql(
                        f"""
                        SELECT ckb.column_name, ckb.table_name, ckb.table_short_name, ckb.comment,
                               ckb.data_type, ckb.classification, ckb.classification_type
                        FROM {self.config.fully_qualified_column_kb} ckb
                        INNER JOIN {self.config.fully_qualified_kb} kb ON ckb.table_name = kb.table_name
                        LEFT JOIN (
                            SELECT src_table, MAX(created_at) AS last_classified,
                                   MAX(bundle_version) AS last_bundle_version
                            FROM (
                                SELECT EXPLODE(source_tables) AS src_table, created_at, bundle_version
                                FROM {self.config.fully_qualified_entities}
                                WHERE attributes['granularity'] = 'column'
                            )
                            GROUP BY src_table
                        ) oe ON ckb.table_name = oe.src_table
                        WHERE (oe.last_classified IS NULL
                          OR kb.updated_at > oe.last_classified
                          OR COALESCE(oe.last_bundle_version, '') != '{current_bv}')
                          {tf_ckb}
                    """
                    )
                    col_count = cols_df.count()
                    total = self.spark.sql(
                        f"SELECT COUNT(*) AS n FROM {self.config.fully_qualified_column_kb} WHERE 1=1 {tf}"
                    ).collect()[0].n
                    logger.info(f"Incremental mode: {col_count} columns need classification out of {total}")
                except Exception as e:
                    logger.warning(f"Incremental column filtering failed ({e}), falling back to full scan")
                    cols_df = self.spark.sql(
                        f"""
                        SELECT column_name, table_name, table_short_name, comment,
                               data_type, classification, classification_type
                        FROM {self.config.fully_qualified_column_kb}
                        WHERE 1=1 {tf}
                    """
                    )
                    col_count = cols_df.count()
            else:
                cols_df = self.spark.sql(
                    f"""
                    SELECT column_name, table_name, table_short_name, comment,
                           data_type, classification, classification_type
                    FROM {self.config.fully_qualified_column_kb}
                    WHERE 1=1 {tf}
                """
                )
                col_count = cols_df.count()
        except Exception as e:
            logger.warning(
                f"Could not read column_knowledge_base, skipping column discovery: {e}"
            )
            return []

        if col_count == 0:
            logger.info("column_knowledge_base is empty or all up-to-date, skipping column discovery")
            return []

        logger.info(f"Evaluating {col_count} columns for entity classification")

        min_confidence = self._validation_cfg.get("min_entity_confidence", 0.55)
        max_per_table = self._validation_cfg.get("max_entities_per_table", 3)

        table_entity_map: Dict[tuple, Dict[str, Any]] = {}
        unmatched = []

        # Paginate by table to avoid OOM on large column KBs.
        # Collect distinct table names (small), then batch-filter cols_df.
        _TABLE_BATCH = 200
        all_tables = [r.table_name for r in cols_df.select("table_name").distinct().collect()]
        logger.info(f"Column discovery: {len(all_tables)} distinct tables, {col_count} columns")

        for batch_start in range(0, len(all_tables), _TABLE_BATCH):
            table_batch = all_tables[batch_start : batch_start + _TABLE_BATCH]
            batch_rows = cols_df.filter(F.col("table_name").isin(table_batch)).collect()
            for row in batch_rows:
                matches = self._match_column_to_entities(row)
                if matches:
                    for entity_type, conf in matches:
                        key = (row.table_name, entity_type)
                        if key not in table_entity_map:
                            table_entity_map[key] = {
                                "columns": [],
                                "conf_sum": 0.0,
                                "count": 0,
                                "table_short_name": row.table_short_name,
                            }
                        table_entity_map[key]["columns"].append(row.column_name)
                        table_entity_map[key]["conf_sum"] += conf
                        table_entity_map[key]["count"] += 1
                    self._stats["column_keyword_matches"] += 1
                else:
                    unmatched.append(row)
            if batch_start + _TABLE_BATCH < len(all_tables):
                logger.info(f"Column entity classification progress: {batch_start + _TABLE_BATCH}/{len(all_tables)} tables")

        if unmatched:
            logger.info(f"Using AI to classify {len(unmatched)} unmatched columns")
            from collections import defaultdict

            grouped: Dict[str, List] = defaultdict(list)
            for row in unmatched:
                grouped[row.table_name].append(row)

            logger.info(
                f"Batching {len(unmatched)} columns across {len(grouped)} tables"
            )

            def _classify_table_cols(table_name, rows):
                short = rows[0].table_short_name or table_name.split(".")[-1]
                return self._ai_classify_columns_for_table(table_name, short, rows)

            from concurrent.futures import ThreadPoolExecutor, as_completed

            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = {
                    executor.submit(_classify_table_cols, tbl, rows): tbl
                    for tbl, rows in grouped.items()
                }
                for future in as_completed(futures):
                    tbl = futures[future]
                    short_name = grouped[tbl][0].table_short_name
                    for col_name, entity_type, conf in future.result():
                        key = (tbl, entity_type)
                        if key not in table_entity_map:
                            table_entity_map[key] = {
                                "columns": [],
                                "conf_sum": 0.0,
                                "count": 0,
                                "table_short_name": short_name,
                            }
                        table_entity_map[key]["columns"].append(col_name)
                        table_entity_map[key]["conf_sum"] += conf
                        table_entity_map[key]["count"] += 1

        discovered = []
        table_groups: Dict[str, list] = {}
        for (tbl, etype), info in table_entity_map.items():
            avg_conf = info["conf_sum"] / info["count"]
            if avg_conf < min_confidence:
                continue
            entity_def = next(
                (e for e in self.entity_definitions if e.name == etype), None
            )
            bindings = []
            if entity_def:
                for col in info["columns"]:
                    attr = self._best_attribute_for_column(col, entity_def)
                    bindings.append({"attribute_name": attr, "bound_table": tbl, "bound_column": col})
            entry = {
                "entity_id": str(uuid.uuid4()),
                "entity_name": etype,
                "entity_type": etype,
                "description": (
                    entity_def.description if entity_def else f"Column-derived {etype}"
                ),
                "entity_uri": getattr(entity_def, "uri", None) if entity_def else None,
                "source_ontology": getattr(entity_def, "source_ontology", None)
                if entity_def
                else None,
                "source_tables": [tbl],
                "source_columns": info["columns"],
                "column_bindings": bindings,
                "attributes": {
                    "granularity": "column",
                    "discovery_method": "column_keyword",
                },
                "confidence": round(avg_conf, 3),
                "auto_discovered": True,
                "validated": False,
                "validation_notes": None,
                "_avg_conf": avg_conf,
            }
            table_groups.setdefault(tbl, []).append(entry)

        for tbl, entries in table_groups.items():
            entries.sort(key=lambda e: e["_avg_conf"], reverse=True)
            for entry in entries[:max_per_table]:
                entry.pop("_avg_conf", None)
                discovered.append(entry)

        logger.info(
            f"Column entity discovery: {self._stats['column_keyword_matches']} keyword, "
            f"{self._stats['column_ai_classifications']} AI, "
            f"{self._stats['column_fallback']} fallback. "
            f"{len(discovered)} column entities kept after thresholds."
        )
        return discovered

    def _match_column_to_entities(self, col_row) -> List[tuple]:
        """Match a column to entity definitions. Returns top-1 entity (+ close runner-up)."""
        col_name = (col_row.column_name or "").lower()
        comment = (col_row.comment or "").lower()
        classification = (col_row.classification or "").lower()
        col_variations = self._normalize_name(col_name)

        matches = []
        for entity_def in self.entity_definitions:
            if entity_def.name == "DataTable":
                continue
            score = self._column_match_score(
                col_variations, col_name, comment, classification, entity_def
            )
            if score >= 0.4:
                matches.append((entity_def.name, score))
        if not matches:
            return []
        matches.sort(key=lambda x: x[1], reverse=True)
        best_score = matches[0][1]
        return [m for m in matches if m[1] >= best_score - 0.1]

    def _column_match_score(
        self,
        col_variations: List[str],
        col_name: str,
        comment: str,
        classification: str,
        entity_def: EntityDefinition,
    ) -> float:
        """Score how well a column matches an entity definition."""
        score = 0.0
        max_score = 0.0
        for attr in entity_def.typical_attributes:
            attr_lower = attr.lower()
            max_score += 2.0
            if attr_lower == col_name:
                score += 2.0
            elif self._keyword_in_text(attr_lower, col_name):
                score += 1.2
            elif any(self._keyword_in_text(attr_lower, v) for v in col_variations):
                score += 0.8
        for kw in entity_def.keywords:
            kw_lower = kw.lower()
            max_score += 1.0
            if self._keyword_in_text(kw_lower, col_name):
                score += 1.0
            elif self._keyword_in_text(kw_lower, comment):
                score += 0.5
        entity_lower = entity_def.name.lower()
        if re.match(rf"{entity_lower}[_\s]?id$", col_name):
            score += 2.0
            max_score += 2.0
        healthcare_entities = {
            "patient",
            "provider",
            "encounter",
            "condition",
            "procedure",
            "medication",
            "observation",
            "claim",
            "coverage",
        }
        if classification in ("phi", "pii") and entity_lower in healthcare_entities:
            score += 0.5
            max_score += 0.5
        if max_score == 0:
            return 0.0
        raw = min(1.0, score / max_score)
        if entity_lower in self.PRIMITIVE_TYPE_NAMES:
            raw *= 0.3
        return raw

    @staticmethod
    def _best_attribute_for_column(col_name: str, entity_def: EntityDefinition) -> str:
        """Derive the best-matching business attribute for a physical column.

        Strips entity-name prefixes (e.g. ``patient_mrn`` -> ``mrn``) and
        matches against ``typical_attributes``.  Falls back to the raw
        column name when no attribute matches.
        """
        cn = col_name.lower()
        prefix = entity_def.name.lower() + "_"
        stripped = cn[len(prefix):] if cn.startswith(prefix) else cn
        for attr in entity_def.typical_attributes:
            al = attr.lower()
            if al == stripped or al == cn:
                return attr
        for attr in entity_def.typical_attributes:
            al = attr.lower()
            if al in stripped or stripped in al:
                return attr
        return stripped

    def compute_conformance(
        self,
        table_entities: List[Dict[str, Any]],
        column_properties: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """Compare discovered columns vs bundle declared properties per table.

        Returns per-table conformance metrics: declared_properties, matched_properties,
        extra_columns, missing_properties, conformance_score, missing, extras.
        """
        results: List[Dict[str, Any]] = []
        table_entity: Dict[str, str] = {}
        for r in table_entities:
            for t in r.get("source_tables") or []:
                if r.get("entity_role") == "primary":
                    table_entity[t] = r.get("entity_type", "")

        cols_by_table: Dict[str, set] = {}
        matched_by_table: Dict[str, set] = {}
        for cp in column_properties:
            tbl = cp.get("table_name")
            col = cp.get("column_name")
            if not tbl or not col:
                continue
            cols_by_table.setdefault(tbl, set()).add(col)
            dm = cp.get("discovery_method") or ""
            if "bundle" in dm.lower() or dm == "bundle_match":
                matched_by_table.setdefault(tbl, set()).add(col)

        for tbl, entity_type in table_entity.items():
            if not entity_type:
                continue
            edef = self._entity_def_map.get(entity_type)
            declared_attrs: set = set()
            if edef and edef.properties:
                for prop in edef.properties:
                    for attr in prop.typical_attributes:
                        declared_attrs.add(attr.lower())
            declared_count = len(declared_attrs)
            discovered = cols_by_table.get(tbl, set())
            matched = matched_by_table.get(tbl, set())
            matched_count = len(matched)
            missing = [a for a in declared_attrs if not any(
                c.lower() == a or a in c.lower() for c in discovered
            )]
            extras = [c for c in discovered if c.lower() not in declared_attrs]
            score = matched_count / declared_count if declared_count > 0 else 1.0
            results.append({
                "table_name": tbl,
                "entity_type": entity_type,
                "declared_properties": declared_count,
                "matched_properties": matched_count,
                "extra_columns": len(extras),
                "missing_properties": len(missing),
                "conformance_score": round(score, 2),
                "missing": missing[:20],
                "extras": sorted(extras)[:20],
            })
        return results

    # ------------------------------------------------------------------
    # AI classification for columns (structured output + enforce)
    # ------------------------------------------------------------------

    def _classify_column_chunk(
        self, short_name: str, columns: List
    ) -> List[Tuple[str, str, float]]:
        """Classify a chunk of columns via a single LLM call.

        Returns list of (column_name, entity_type, confidence).
        """
        entity_descriptions = "\n".join(
            self._format_entity_desc(e)
            for e in self.entity_definitions
            if e.name != "DataTable"
        )

        col_lines = []
        for row in columns:
            cname = row.column_name or "unknown"
            dtype = row.data_type or "unknown"
            desc = (row.comment or "")[:200]
            col_lines.append(f"  - {cname} ({dtype}): {desc}")
        columns_text = "\n".join(col_lines)

        system_prompt = (
            "You are an entity classifier for database columns. "
            "For each column, classify it into the entity type it most likely belongs to. "
            "Prefer domain-relevant business entities over data-type primitives "
            "(e.g. Boolean, Integer, Text) -- primitive types describe data formats, "
            "not what a column semantically represents. "
            "Classify based on what the column itself represents, not the table's domain. "
            "Tables in specialized domains (e.g. healthcare) often contain commercial, "
            "supply-chain, or financial columns (product_name, supplier_id, unit_price) "
            "that should map to Product, Supplier, or Transaction -- not to domain-specific "
            "entities like Procedure or Medication. "
            "Return one classification per column, using the exact column_name provided."
        )
        user_prompt = (
            f"Table: {short_name}\n\n"
            f"Columns:\n{columns_text}\n\n"
            f"Entity types:\n{entity_descriptions}\n\n"
            "Classify every column listed above."
        )

        batch_llm = self._get_batch_column_llm()
        response: BatchColumnClassificationResult = batch_llm.invoke(
            [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ]
        )
        results = []
        for item in response.classifications:
            enforced, exact = _enforce_entity_value(item.entity_type, self._entity_names)
            conf = item.confidence
            if not exact:
                conf = max(0.0, conf - self.CONFIDENCE_PENALTY_SNAP)
            results.append((item.column_name, enforced, round(conf, 3)))
        self._stats["column_ai_classifications"] += len(results)
        return results

    def _ai_query_classify_columns(
        self, columns: List
    ) -> List[Tuple[str, str, float]]:
        """Classify columns via Spark SQL ai_query -- batch fallback for failed chunks."""
        entity_descriptions = "\n".join(
            self._format_entity_desc(e)
            for e in self.entity_definitions
            if e.name != "DataTable"
        )
        entity_names_csv = ", ".join(self._entity_names)
        escaped_desc = entity_descriptions.replace("'", "''")
        escaped_names = entity_names_csv.replace("'", "''")

        rows = [
            {
                "column_name": r.column_name or "unknown",
                "table_short_name": getattr(r, "table_short_name", None) or r.table_name or "unknown",
                "data_type": r.data_type or "unknown",
                "comment": (r.comment or "")[:200],
            }
            for r in columns
        ]
        df = self.spark.createDataFrame(rows)
        view_name = f"_ontology_ai_classify_cols_{uuid.uuid4().hex[:8]}"
        df.createOrReplaceTempView(view_name)

        sql = f"""
            SELECT
                column_name,
                ai_query(
                    '{self._model_endpoint}',
                    CONCAT(
                        'You are an entity classifier for database columns. ',
                        'Classify this column into the entity type it most likely belongs to. ',
                        'Classify based on what the column itself represents, not the table domain. ',
                        'Valid entity types: {escaped_names}. ',
                        'Entity descriptions:\\n{escaped_desc}\\n\\n',
                        'Column: ', column_name,
                        '\\nTable: ', table_short_name,
                        '\\nData type: ', data_type,
                        '\\nDescription: ', comment,
                        '\\n\\nReturn JSON with entity_type and confidence (0-1).'
                    ),
                    responseFormat => 'STRUCT<result: STRUCT<entity_type: STRING, confidence: DOUBLE>>',
                    failOnError => false
                ) AS classification
            FROM {view_name}
        """
        try:
            result_rows = self.spark.sql(sql).collect()
        except Exception as e:
            logger.warning(f"ai_query batch classification failed: {e}. Using DataTable fallback.")
            self.spark.catalog.dropTempView(view_name)
            return [(r["column_name"], "DataTable", 0.2) for r in rows]

        self.spark.catalog.dropTempView(view_name)

        results = []
        for rr in result_rows:
            col_name = rr.column_name
            cls = rr.classification
            if cls and cls.result and cls.result.entity_type:
                enforced, exact = _enforce_entity_value(cls.result.entity_type, self._entity_names)
                conf = cls.result.confidence or 0.5
                if not exact:
                    conf = max(0.0, conf - self.CONFIDENCE_PENALTY_SNAP)
                results.append((col_name, enforced, round(conf, 3)))
                self._stats["column_ai_classifications"] += 1
            else:
                results.append((col_name, "DataTable", 0.2))
                self._stats["column_fallback"] += 1
        return results

    def _ai_classify_columns_for_table(
        self, table_name: str, short_name: str, columns: List
    ) -> List[Tuple[str, str, float]]:
        """Classify all columns for a single table, chunking if needed.

        Returns list of (column_name, entity_type, confidence).

        Columns are split into token-budget-sized chunks (`_COLS_PER_CLASSIFY_CHUNK`);
        a chunk that truncates at the token limit is bisected and retried (ON-19),
        falling back to ai_query only when even a single-column chunk fails.
        """
        n = _COLS_PER_CLASSIFY_CHUNK
        num_chunks = -(-len(columns) // n)
        all_results = []
        for i in range(0, len(columns), n):
            chunk = columns[i : i + n]
            if num_chunks > 1:
                logger.info(
                    f"Classifying {table_name}: chunk {i // n + 1}/{num_chunks} ({len(chunk)} cols)"
                )
            all_results.extend(self._classify_column_chunk_resilient(table_name, short_name, chunk))
        return all_results

    def _classify_column_chunk_resilient(
        self, table_name: str, short_name: str, columns: List
    ) -> List[Tuple[str, str, float]]:
        """Classify one chunk; on truncation bisect and retry, else ai_query fallback.

        A `StructuredTruncationError` means the batch was too large for the output
        budget -- bisecting and retrying recovers the content (ON-19). Any other
        failure on an already-small chunk falls back to per-column ai_query.
        """
        from dbxmetagen.chat_client import StructuredTruncationError
        try:
            return self._classify_column_chunk(short_name, columns)
        except StructuredTruncationError as e:
            if len(columns) <= 1:
                _cn = getattr(columns[0], "column_name", "?") if columns else "?"
                logger.warning(
                    f"Single-column chunk still truncated for {table_name} "
                    f"({_cn}); falling back to ai_query: {e}"
                )
                return self._ai_query_classify_columns(columns)
            mid = len(columns) // 2
            logger.warning(
                f"Batch column classification truncated for {table_name} "
                f"({len(columns)} cols); bisecting into {mid}+{len(columns) - mid}."
            )
            results = []
            for sub in (columns[:mid], columns[mid:]):
                results.extend(self._classify_column_chunk_resilient(table_name, short_name, sub))
            return results
        except Exception as e:
            if len(columns) <= 1:
                logger.warning(
                    f"Chunk failed for {table_name} ({len(columns)} cols), "
                    f"ai_query fallback: {type(e).__name__}: {e}"
                )
                return self._ai_query_classify_columns(columns)
            # A non-truncation error on a multi-column chunk: try one bisection
            # before giving the whole chunk to ai_query (a single bad column
            # shouldn't sink its neighbors).
            mid = len(columns) // 2
            logger.warning(
                f"Chunk classification failed for {table_name} ({len(columns)} cols): "
                f"{type(e).__name__}: {e}. Bisecting before ai_query fallback."
            )
            results = []
            for sub in (columns[:mid], columns[mid:]):
                results.extend(self._classify_column_chunk_resilient(table_name, short_name, sub))
            return results

    def _ai_classify_column(self, col_row) -> Tuple[str, float]:
        """AI classification for a single column using structured output."""
        col_name = col_row.column_name or "unknown"
        table_name = col_row.table_short_name or col_row.table_name or "unknown"
        comment = col_row.comment or "No description"
        data_type = col_row.data_type or "unknown"

        entity_descriptions = "\n".join(
            self._format_entity_desc(e)
            for e in self.entity_definitions
            if e.name != "DataTable"
        )

        system_prompt = (
            "You are an entity classifier for database columns. "
            "Classify each column into the entity type it most likely belongs to. "
            "If your confidence is below 0.5, populate recommended_entity with a better name."
        )
        user_prompt = (
            f"Column: {col_name}\nTable: {table_name}\n"
            f"Data type: {data_type}\nDescription: {comment[:300]}\n\n"
            f"Entity types:\n{entity_descriptions}\n\nClassify this column."
        )

        try:
            structured_llm = self._get_structured_llm()
            response: EntityClassificationResult = structured_llm.invoke(
                [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ]
            )
            enforced, exact = _enforce_entity_value(
                response.entity_type, self._entity_names
            )
            conf = response.confidence
            if not exact:
                conf = max(0.0, conf - self.CONFIDENCE_PENALTY_SNAP)
            self._stats["column_ai_classifications"] += 1
            return (enforced, round(conf, 3))
        except Exception as e:
            logger.warning(f"AI column classification failed for {col_name}: {e}")
            self._stats["column_fallback"] += 1
            return ("DataTable", 0.2)

    # ------------------------------------------------------------------
    # Deduplication / merge
    # ------------------------------------------------------------------

    @staticmethod
    def enrich_provenance_from_definitions(
        entities: List[Dict[str, Any]],
        definitions: Optional[List[Any]] = None,
    ) -> List[Dict[str, Any]]:
        """Backfill entity_uri / source_ontology from bundle definitions when missing."""
        if not definitions:
            return entities
        name_to_def = {
            getattr(d, "name", None): d
            for d in definitions
            if getattr(d, "name", None)
        }
        for ent in entities:
            et = ent.get("entity_type")
            edef = name_to_def.get(et) if et else None
            if not edef:
                continue
            if not ent.get("source_ontology"):
                ent["source_ontology"] = getattr(edef, "source_ontology", None)
            if not ent.get("entity_uri"):
                ent["entity_uri"] = getattr(edef, "uri", None)
        return entities

    @staticmethod
    def deduplicate_entities(entities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Merge duplicate entities from different discovery methods.

        Groups by (source_table, entity_type) and merges source_columns,
        takes max confidence, and combines attributes.
        """
        groups: Dict[tuple, Dict[str, Any]] = {}
        for ent in entities:
            for tbl in ent.get("source_tables", ["unknown"]):
                key = (tbl, ent["entity_type"])
                if key not in groups:
                    groups[key] = {
                        **ent,
                        "source_tables": [tbl],
                        "source_columns": list(ent.get("source_columns", [])),
                        "attributes": dict(ent.get("attributes", {})),
                    }
                else:
                    existing = groups[key]
                    existing["confidence"] = max(
                        existing["confidence"], ent.get("confidence", 0)
                    )
                    for col in ent.get("source_columns", []):
                        if col not in existing["source_columns"]:
                            existing["source_columns"].append(col)
                    for k, v in ent.get("attributes", {}).items():
                        if k not in existing["attributes"]:
                            existing["attributes"][k] = v
                    if ent.get("validation_notes") and not existing.get(
                        "validation_notes"
                    ):
                        existing["validation_notes"] = ent["validation_notes"]
                    if ent.get("entity_uri") and not existing.get("entity_uri"):
                        existing["entity_uri"] = ent["entity_uri"]
                    if ent.get("source_ontology") and not existing.get("source_ontology"):
                        existing["source_ontology"] = ent["source_ontology"]
        return list(groups.values())


# ---------------------------------------------------------------------------
# Entity-role reconciliation (classify -> dedup -> flag)
#
# Module-level so both OntologyBuilder and OntologyValidator can run the exact
# same logic without OntologyValidator needing to construct a builder. Entities
# are single-table (zero or one source_tables entry), so scoping by
# get(source_tables, 0) selects exactly the scoped entities. When table_names is
# None the SQL is byte-identical to the original OntologyBuilder methods.
# ---------------------------------------------------------------------------

_DEFAULT_PRIMARY_CONFIDENCE_FLOOR = 0.3


def _classify_entity_roles_sql(spark, ent_table: str, table_names=None) -> int:
    """Assign 'primary'/'referenced' roles per source table (see OntologyBuilder.classify_entity_roles)."""
    tbl_scope = table_filter_sql(table_names, column="tbl") if table_names else ""
    where_scope = f"WHERE 1=1 {tbl_scope}" if table_names else ""
    spark.sql(f"""
        MERGE INTO {ent_table} AS target
        USING (
            WITH                 exploded AS (
                SELECT entity_id,
                       COALESCE(attributes['granularity'], 'table') AS granularity,
                       confidence, tbl,
                       COALESCE(auto_discovered, TRUE) AS auto_discovered
                FROM {ent_table}
                LATERAL VIEW EXPLODE(source_tables) AS tbl
                {where_scope}
            ),
            per_table AS (
                SELECT tbl,
                       BOOL_OR(granularity = 'table') AS has_table_level
                FROM exploded GROUP BY tbl
            ),
            ent_agg AS (
                SELECT entity_id,
                       BOOL_OR(granularity = 'table') AS owned,
                       COUNT(DISTINCT CASE WHEN granularity = 'column' THEN tbl END) AS column_table_count
                FROM exploded GROUP BY entity_id
            ),
            ranked AS (
                SELECT e.entity_id,
                       ROW_NUMBER() OVER (
                           PARTITION BY e.tbl
                           ORDER BY
                               CASE WHEN h.has_table_level AND e.granularity = 'table' THEN 0
                                    WHEN NOT h.has_table_level AND e.granularity = 'column' THEN 0
                                    ELSE 1 END,
                               -- Ownership penalty: a column-level entity for this table
                               -- that is owned (table-level) elsewhere AND appears as a
                               -- column across many tables (ubiquitous FK like patient_id)
                               -- is deprioritized so a table-specific subject wins primary.
                               CASE WHEN e.granularity = 'column' AND a.owned
                                         AND a.column_table_count >= 4
                                         AND e.auto_discovered THEN 1 ELSE 0 END,
                               e.confidence DESC
                       ) AS rn
                FROM exploded e
                JOIN per_table h ON e.tbl = h.tbl
                JOIN ent_agg a ON e.entity_id = a.entity_id
            )
            SELECT entity_id,
                   CASE WHEN MAX(CASE WHEN rn = 1 THEN 1 ELSE 0 END) = 1
                        THEN 'primary' ELSE 'referenced' END AS computed_role
            FROM ranked
            GROUP BY entity_id
        ) AS source
        ON target.entity_id = source.entity_id
        WHEN MATCHED AND (
            COALESCE(target.entity_role, '') != source.computed_role
            OR target.discovery_confidence IS NULL
        ) THEN UPDATE SET
            entity_role = source.computed_role,
            discovery_confidence = COALESCE(target.discovery_confidence, target.confidence),
            updated_at = CURRENT_TIMESTAMP()
    """)
    # Default orphan (NULL/empty source_tables) entities to 'referenced'. Skipped
    # when scoped: such entities have no source table to match the scope filter.
    if not table_names:
        spark.sql(f"""
            UPDATE {ent_table}
            SET entity_role = 'referenced', updated_at = CURRENT_TIMESTAMP()
            WHERE (source_tables IS NULL OR SIZE(source_tables) = 0)
              AND entity_role IS NULL
        """)
    counts = spark.sql(f"""
        SELECT entity_role, COUNT(*) AS cnt
        FROM {ent_table}
        WHERE entity_role IN ('primary', 'referenced')
        GROUP BY entity_role
    """).collect()
    role_counts = {r.entity_role: r.cnt for r in counts}
    n_primary = role_counts.get("primary", 0)
    n_referenced = role_counts.get("referenced", 0)
    logger.info("classify_entity_roles: %d primary, %d referenced", n_primary, n_referenced)
    return n_primary + n_referenced


def _deduplicate_primary_entities_sql(spark, ent_table: str, table_names=None) -> int:
    """Demote duplicate primaries per table to 'referenced' (see OntologyBuilder._deduplicate_primary_entities)."""
    tbl_scope = table_filter_sql(table_names, column="tbl") if table_names else ""
    spark.sql(f"""
        MERGE INTO {ent_table} AS target
        USING (
            WITH exploded AS (
                SELECT entity_id, confidence, auto_discovered, tbl
                FROM {ent_table}
                LATERAL VIEW EXPLODE(source_tables) AS tbl
                WHERE entity_role = 'primary' {tbl_scope}
            ),
            ranked AS (
                SELECT entity_id, tbl,
                       ROW_NUMBER() OVER (
                           PARTITION BY tbl
                           ORDER BY
                               CASE WHEN auto_discovered = FALSE THEN 0 ELSE 1 END,
                               confidence DESC
                       ) AS rn
                FROM exploded
            ),
            losers AS (
                SELECT entity_id
                FROM ranked
                WHERE rn > 1
                GROUP BY entity_id
                HAVING entity_id NOT IN (
                    SELECT entity_id FROM ranked WHERE rn = 1
                )
            )
            SELECT entity_id FROM losers
        ) AS source
        ON target.entity_id = source.entity_id
        WHEN MATCHED AND target.auto_discovered = TRUE THEN UPDATE SET
            entity_role = 'referenced',
            updated_at = CURRENT_TIMESTAMP()
    """)
    counts = spark.sql(f"""
        SELECT entity_role, COUNT(*) AS cnt
        FROM {ent_table}
        WHERE entity_role = 'primary'
        GROUP BY entity_role
    """).collect()
    n_primary = counts[0].cnt if counts else 0
    logger.info("_deduplicate_primary_entities: %d primary entities remain", n_primary)
    return n_primary


def _flag_low_confidence_primaries_sql(
    spark, ent_table: str, table_names=None,
    primary_floor: float = _DEFAULT_PRIMARY_CONFIDENCE_FLOOR,
) -> int:
    """Flag below-floor primaries for human review (see OntologyBuilder._flag_low_confidence_primaries)."""
    st_scope = table_filter_sql(table_names, column="get(source_tables, 0)") if table_names else ""
    result = spark.sql(f"""
        UPDATE {ent_table}
        SET attributes = map_concat(
                map_filter(attributes, (k, v) -> k != 'needs_human_review'),
                map('needs_human_review', 'true')),
            updated_at = CURRENT_TIMESTAMP()
        WHERE COALESCE(entity_role, 'primary') = 'primary'
          AND COALESCE(confidence, 1.0) < {primary_floor}
          AND attributes IS NOT NULL
          AND COALESCE(attributes['needs_human_review'], 'false') <> 'true'
          -- Never touch human-locked (steward override) or already-validated
          -- entities: their review state is authoritative.
          AND COALESCE(auto_discovered, TRUE) = TRUE
          AND COALESCE(validated, FALSE) = FALSE
          {st_scope}
    """)
    try:
        n = result.first()[0] if result is not None and result.first() else 0
    except Exception:
        n = 0
    logger.info("_flag_low_confidence_primaries: flagged %s primaries below floor %.2f",
                n, primary_floor)
    return n


def reconcile_entity_roles(
    spark, ent_table: str, table_names=None,
    primary_floor: float = _DEFAULT_PRIMARY_CONFIDENCE_FLOOR,
) -> int:
    """Recompute entity roles end-to-end: classify -> deduplicate -> flag.

    When *table_names* is set, scope every write to entities of those tables
    (single-table entities, so get(source_tables, 0) identifies them) without
    touching out-of-scope entities. Returns the classify primary+referenced count.
    """
    n = _classify_entity_roles_sql(spark, ent_table, table_names)
    _deduplicate_primary_entities_sql(spark, ent_table, table_names)
    _flag_low_confidence_primaries_sql(spark, ent_table, table_names, primary_floor)
    return n


class OntologyBuilder:
    """
    Builder for creating and managing the ontology layer.

    Creates ontology_entities and ontology_metrics tables, discovers
    entities from the knowledge base, and manages relationships.
    """

    _BINDING_SCHEMA = ArrayType(
        StructType(
            [
                StructField("attribute_name", StringType(), True),
                StructField("bound_table", StringType(), True),
                StructField("bound_column", StringType(), True),
            ]
        )
    )

    ENTITIES_SCHEMA = StructType(
        [
            StructField("entity_id", StringType(), False),
            StructField("entity_name", StringType(), True),
            StructField("entity_type", StringType(), True),
            StructField("description", StringType(), True),
            StructField("source_tables", ArrayType(StringType()), True),
            StructField("source_columns", ArrayType(StringType()), True),
            StructField("attributes", MapType(StringType(), StringType()), True),
            StructField("confidence", DoubleType(), True),
            StructField("discovery_confidence", DoubleType(), True),
            StructField("entity_role", StringType(), True),
            StructField("is_canonical", BooleanType(), True),
            StructField("auto_discovered", BooleanType(), True),
            StructField("validated", BooleanType(), True),
            StructField("validation_notes", StringType(), True),
            StructField("ontology_bundle", StringType(), True),
            StructField("bundle_version", StringType(), True),
            StructField("discovery_timestamp", TimestampType(), True),
            StructField("created_at", TimestampType(), True),
            StructField("updated_at", TimestampType(), True),
            StructField("column_bindings", _BINDING_SCHEMA, True),
            StructField("entity_uri", StringType(), True),
            StructField("source_ontology", StringType(), True),
        ]
    )

    def __init__(self, spark: SparkSession, config: OntologyConfig, model_endpoint: Optional[str] = None):
        self.spark = spark
        self.config = config
        self._model_endpoint = model_endpoint
        effective_path = _resolve_ontology_config_path(
            config.config_path, config.ontology_bundle,
        )
        self.ontology_config = OntologyLoader.load_config(effective_path)
        self._validation_cfg = self.ontology_config.get("validation", {})
        bundle_tag_key = (
            self.ontology_config
            .get("_bundle_metadata", {})
            .get("tag_key")
        )
        if bundle_tag_key and config.entity_tag_key in ("entity_type", "ontology_entity_type", "ontology.entity_type"):
            config.entity_tag_key = bundle_tag_key
            logger.info(f"Using entity_tag_key '{bundle_tag_key}' from bundle metadata")
        affinity = load_domain_entity_affinity(self.ontology_config)
        self.discoverer = EntityDiscoverer(
            spark, config, self.ontology_config, domain_entity_affinity=affinity,
            model_endpoint=model_endpoint,
        )

    def _get_bundle_version(self) -> str:
        """Get bundle version string for incremental tracking.

        Must match the format used by EntityDiscoverer._get_bundle_version()
        so that the stored bundle_version column and the incremental SQL
        comparison target are consistent ('{bundle}:{ver}').
        """
        bundle = self.config.ontology_bundle or "default"
        ont = self.ontology_config.get("ontology", {}) or {}
        meta = self.ontology_config.get("metadata", {}) or {}
        ver = str(ont.get("version") or meta.get("version") or "1.0")
        return f"{bundle}:{ver}"

    # _insert_edges_safe removed — all edge writes now go through merge_edges()

    def create_entities_table(self) -> None:
        """Create the ontology entities table."""
        ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.config.fully_qualified_entities} (
            entity_id STRING NOT NULL,
            entity_name STRING,
            entity_type STRING,
            description STRING,
            source_tables ARRAY<STRING>,
            source_columns ARRAY<STRING>,
            attributes MAP<STRING, STRING>,
            confidence DOUBLE,
            auto_discovered BOOLEAN,
            validated BOOLEAN,
            validation_notes STRING,
            ontology_bundle STRING,
            column_bindings ARRAY<STRUCT<attribute_name: STRING, bound_table: STRING, bound_column: STRING>>,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        )
        COMMENT 'Ontology entities discovered from knowledge base'
        """
        self.spark.sql(ddl)
        existing = {f.name for f in self.spark.table(self.config.fully_qualified_entities).schema.fields}
        new_columns = {
            "ontology_bundle": "STRING",
            "column_bindings": "ARRAY<STRUCT<attribute_name: STRING, bound_table: STRING, bound_column: STRING>>",
            "entity_role": "STRING",
            "is_canonical": "BOOLEAN",
            "discovery_confidence": "DOUBLE",
            "bundle_version": "STRING",
            "discovery_timestamp": "TIMESTAMP",
            "entity_uri": "STRING",
            "source_ontology": "STRING",
        }
        for col_name, col_type in new_columns.items():
            if col_name not in existing:
                try:
                    self.spark.sql(
                        f"ALTER TABLE {self.config.fully_qualified_entities} ADD COLUMN {col_name} {col_type}"
                    )
                    logger.info("Added column %s to entities table", col_name)
                except Exception as e:
                    logger.warning("Could not add column %s: %s", col_name, e)
        # UPDATE: Clamp confidence and discovery_confidence to [0.0, 1.0] after
        # schema migration. LLM-generated scores can occasionally exceed the valid
        # range, and legacy rows from before discovery_confidence was added have NULL.
        # WHY: Downstream consumers (role classification, conformance scoring, graph
        # weighting) assume confidence is a valid probability. Out-of-range values
        # would break ranking ORDER BY and percentage displays.
        # TRADEOFFS: A post-hoc clamp is simpler than validating at every insertion
        # point (there are 3+ code paths that write entities). The WHERE filter
        # limits Delta write amp to only out-of-range rows plus legacy NULLs.
        # The guard `AND confidence IS NOT NULL` prevents GREATEST/LEAST from
        # turning a NULL confidence into 1.0 (Spark skips NULLs in GREATEST/LEAST).
        try:
            self.spark.sql(
                f"UPDATE {self.config.fully_qualified_entities} "
                f"SET confidence = GREATEST(0.0, LEAST(1.0, confidence)), "
                f"    discovery_confidence = GREATEST(0.0, LEAST(1.0, COALESCE(discovery_confidence, confidence))) "
                f"WHERE confidence < 0.0 OR confidence > 1.0 "
                f"   OR discovery_confidence < 0.0 OR discovery_confidence > 1.0"
                f"   OR (discovery_confidence IS NULL AND confidence IS NOT NULL)"
            )
        except Exception as e:
            logger.error("Confidence cleanup FAILED on %s: %s", self.config.fully_qualified_entities, e)
        logger.info(f"Entities table {self.config.fully_qualified_entities} ready")

    def create_metrics_table(self) -> None:
        """Create the ontology metrics table.

        NOTE: This table is intentionally a stub for future Unity Catalog
        metric views integration. It is created but not populated. When UC
        metric views become generally available, this table will hold
        entity-level metric definitions that map to UC metric views.
        """
        ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.config.fully_qualified_metrics} (
            metric_id STRING NOT NULL,
            metric_name STRING,
            description STRING,
            entity_id STRING,
            sql_definition STRING,
            uc_view_name STRING,
            aggregation_type STRING,
            source_field STRING,
            filter_condition STRING,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        )
        COMMENT 'Ontology metrics linked to entities (stub for UC metric views)'
        """
        self.spark.sql(ddl)
        logger.info(f"Metrics table {self.config.fully_qualified_metrics} ready")

    def create_column_properties_table(self) -> None:
        """Create the ontology column properties table for property-level classification."""
        ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.config.fully_qualified_column_properties} (
            property_id STRING NOT NULL,
            table_name STRING,
            column_name STRING,
            property_name STRING,
            property_role STRING,
            owning_entity_id STRING,
            owning_entity_type STRING,
            linked_entity_type STRING,
            confidence DOUBLE,
            auto_discovered BOOLEAN,
            discovery_method STRING,
            is_sensitive BOOLEAN,
            is_surrogate_key BOOLEAN,
            is_semi_structured BOOLEAN,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        )
        COMMENT 'Column-level property roles and orthogonal flags'
        """
        self.spark.sql(ddl)
        existing = set()
        try:
            existing = {f.name for f in self.spark.table(self.config.fully_qualified_column_properties).schema.fields}
        except Exception:
            pass
        for col_name, col_type in [("bundle_version", "STRING"), ("discovery_timestamp", "TIMESTAMP")]:
            if col_name not in existing:
                try:
                    self.spark.sql(
                        f"ALTER TABLE {self.config.fully_qualified_column_properties} ADD COLUMN {col_name} {col_type}"
                    )
                    logger.info("Added column %s to column properties table", col_name)
                except Exception as e:
                    logger.warning("Could not add column %s: %s", col_name, e)
        logger.info("Column properties table %s ready", self.config.fully_qualified_column_properties)

    def create_discovery_diff_table(self) -> None:
        """Create the discovery diff report table for storing run diffs."""
        ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.config.fully_qualified_discovery_diff} (
            report_id STRING NOT NULL,
            catalog STRING,
            schema STRING,
            bundle_version STRING,
            previous_version STRING,
            timestamp TIMESTAMP,
            diff_json STRING,
            created_at TIMESTAMP
        )
        COMMENT 'Discovery diff reports from ontology runs'
        """
        self.spark.sql(ddl)
        logger.info("Discovery diff table %s ready", self.config.fully_qualified_discovery_diff)

    _REL_MIGRATION_COLUMNS = {
        "label": "STRING",
        "facet": "STRING",
        "sub_property_of": "STRING",
        "ranges": "ARRAY<STRING>",
        "source_ontology": "STRING",
        "edge_uri": "STRING",
    }

    def create_relationships_table(self) -> None:
        """Create the ontology relationships table for named entity-to-entity relationships."""
        ddl = f"""
        CREATE TABLE IF NOT EXISTS {self.config.fully_qualified_relationships} (
            relationship_id STRING NOT NULL,
            src_entity_type STRING,
            relationship_name STRING,
            dst_entity_type STRING,
            cardinality STRING,
            evidence_column STRING,
            evidence_table STRING,
            source STRING,
            confidence DOUBLE,
            label STRING,
            facet STRING,
            sub_property_of STRING,
            ranges ARRAY<STRING>,
            created_at TIMESTAMP,
            updated_at TIMESTAMP
        )
        COMMENT 'Named relationships between ontology entity types'
        """
        self.spark.sql(ddl)
        existing = {f.name for f in self.spark.table(self.config.fully_qualified_relationships).schema.fields}
        for col_name, col_type in self._REL_MIGRATION_COLUMNS.items():
            if col_name not in existing:
                try:
                    self.spark.sql(
                        f"ALTER TABLE {self.config.fully_qualified_relationships} ADD COLUMN {col_name} {col_type}"
                    )
                    logger.info("Added column %s to relationships table", col_name)
                except Exception as e:
                    logger.warning("Could not add column %s to relationships: %s", col_name, e)
        logger.info("Relationships table %s ready", self.config.fully_qualified_relationships)

    _MIN_STORE_CONFIDENCE = 0.2
    # Primary entities below this confidence are treated as abstentions: they are
    # flagged needs_human_review and their authoritative instance_of (table->entity)
    # edge is suppressed so the knowledge graph never asserts a low-confidence type.
    _PRIMARY_CONFIDENCE_FLOOR = 0.3

    def _store_entities(
        self,
        entities: List[Dict[str, Any]],
        view_name: str = "new_entities",
        bundle_version: Optional[str] = None,
        discovery_timestamp: Optional[datetime] = None,
    ) -> int:
        """Store entity dicts via MERGE (insert new, update existing)."""
        if not entities:
            return 0

        before = len(entities)
        entities = [
            e for e in entities
            if float(e.get("confidence", 0.0)) >= self._MIN_STORE_CONFIDENCE
        ]
        if len(entities) < before:
            logger.info("Filtered %d low-confidence entities (< %.2f)",
                        before - len(entities), self._MIN_STORE_CONFIDENCE)

        # Drop primitive datatype types (Date, Integer, Boolean, etc.): these are
        # schema.org DataTypes, not semantic entities, and add no value while
        # crowding out meaningful mappings. Inert for bundles that never produce
        # such types (FHIR/OMOP define none of these names as entities).
        before = len(entities)
        entities = [
            e for e in entities
            if (e.get("entity_type") or e.get("entity_name") or "").lower()
            not in EntityDiscoverer.PRIMITIVE_TYPE_NAMES
        ]
        if len(entities) < before:
            logger.info("Filtered %d primitive datatype entities", before - len(entities))

        if not entities:
            return 0

        bundle_name = self.config.ontology_bundle or None
        now = datetime.now()
        version = bundle_version or self._get_bundle_version()
        ts = discovery_timestamp or now
        rows = []
        for entity in entities:
            attributes = entity.get("attributes", {})
            if isinstance(attributes, dict):
                attributes = {k: str(v) for k, v in attributes.items()}
            else:
                attributes = {}
            bindings = entity.get("column_bindings") or []
            rows.append(
                (
                    entity["entity_id"],
                    entity.get("entity_name"),
                    entity.get("entity_type"),
                    entity.get("description"),
                    entity.get("source_tables", []),
                    entity.get("source_columns", []),
                    attributes,
                    max(0.0, min(1.0, float(entity.get("confidence", 0.0)))),
                    max(0.0, min(1.0, float(entity.get("discovery_confidence") or entity.get("confidence", 0.0)))),
                    entity.get("entity_role"),
                    bool(entity.get("is_canonical", False)),
                    bool(entity.get("auto_discovered", True)),
                    bool(entity.get("validated", False)),
                    entity.get("validation_notes"),
                    bundle_name,
                    version,
                    ts,
                    now,
                    now,
                    bindings,
                    entity.get("entity_uri"),
                    entity.get("source_ontology"),
                )
            )

        df = self.spark.createDataFrame(rows, schema=self.ENTITIES_SCHEMA)
        df.createOrReplaceTempView(view_name)

        # Content-change guard: only update system-owned entities when discovery
        # produces meaningfully different results. Resets validated + validation_notes
        # so the validator re-evaluates after upstream changes.
        match_condition = (
            "WHEN MATCHED AND target.auto_discovered = TRUE"
            " AND (target.confidence != source.confidence"
            " OR COALESCE(array_join(target.source_columns, ','), '') != COALESCE(array_join(source.source_columns, ','), '')"
            " OR COALESCE(target.entity_uri, '') != COALESCE(source.entity_uri, '')"
            " OR COALESCE(target.source_ontology, '') != COALESCE(source.source_ontology, ''))"
            " THEN UPDATE SET"
        )
        extra_sets = ",\n            target.validated = FALSE,\n            target.validation_notes = NULL"

        self.spark.sql(
            f"""
        MERGE INTO {self.config.fully_qualified_entities} AS target
        USING {view_name} AS source
        ON target.entity_name = source.entity_name
           AND array_join(array_sort(target.source_tables), ',') = array_join(array_sort(source.source_tables), ',')
        {match_condition}
            target.confidence = source.confidence,
            target.source_columns = source.source_columns,
            target.attributes = CASE
                WHEN COALESCE(target.attributes['granularity'], 'table') = 'table'
                     AND source.attributes['granularity'] = 'column'
                THEN map_concat(
                       map_filter(source.attributes, (k, v) -> k NOT IN ('granularity', 'discovery_method')),
                       map('granularity', 'table',
                           'discovery_method', COALESCE(target.attributes['discovery_method'], source.attributes['discovery_method'])))
                ELSE source.attributes
            END,
            target.column_bindings = source.column_bindings,
            target.bundle_version = source.bundle_version,
            target.entity_uri = source.entity_uri,
            target.source_ontology = source.source_ontology,
            target.updated_at = source.updated_at{extra_sets}
        WHEN NOT MATCHED THEN INSERT *
        """
        )
        # UPDATE: Post-MERGE confidence clamp -- same logic as create_entities_table
        # but runs after each _store_entities call to catch any new out-of-range
        # values introduced by the LLM confidence scores in this batch.
        # WHY: LLM-generated confidence values are not guaranteed to be in [0, 1],
        # and legacy rows may have NULL discovery_confidence that needs backfilling.
        # TRADEOFFS: Running this after every MERGE adds a small UPDATE overhead,
        # but the WHERE clause limits it to only out-of-range rows plus legacy NULLs.
        try:
            self.spark.sql(
                f"UPDATE {self.config.fully_qualified_entities} "
                f"SET confidence = GREATEST(0.0, LEAST(1.0, confidence)), "
                f"    discovery_confidence = GREATEST(0.0, LEAST(1.0, COALESCE(discovery_confidence, confidence))) "
                f"WHERE confidence < 0.0 OR confidence > 1.0 "
                f"   OR discovery_confidence < 0.0 OR discovery_confidence > 1.0"
                f"   OR (discovery_confidence IS NULL AND confidence IS NOT NULL)"
            )
        except Exception as e:
            logger.error("Post-MERGE confidence clamp failed: %s", e)
        return len(entities)

    def discover_and_store_entities(self) -> int:
        """Discover table-level entities, deduplicate, and store."""
        entities = self.discoverer.discover_entities_from_tables()
        if not entities:
            logger.warning(
                "No entities discovered. Check that table_knowledge_base has data."
            )
            return 0
        entities = EntityDiscoverer.enrich_provenance_from_definitions(
            entities, self.discoverer.entity_definitions
        )
        entities = EntityDiscoverer.deduplicate_entities(entities)
        now = datetime.now()
        stored = self._store_entities(
            entities, "new_table_entities",
            bundle_version=self._get_bundle_version(),
            discovery_timestamp=now,
        )
        logger.info(f"Stored {stored} table-level entities (after dedup)")
        return stored

    def discover_and_store_column_entities(self) -> int:
        """Discover column-level entities, deduplicate, and store."""
        entities = self.discoverer.discover_entities_from_columns()
        if not entities:
            logger.info("No column-level entities discovered")
            return 0
        entities = EntityDiscoverer.enrich_provenance_from_definitions(
            entities, self.discoverer.entity_definitions
        )
        entities = EntityDiscoverer.deduplicate_entities(entities)
        now = datetime.now()
        stored = self._store_entities(
            entities, "new_column_entities",
            bundle_version=self._get_bundle_version(),
            discovery_timestamp=now,
        )
        logger.info(f"Stored {stored} column-level entities (after dedup)")
        return stored

    def backfill_source_columns(self) -> int:
        """Update table-level entities' source_columns and column_bindings from column-level matches."""
        try:
            self.spark.sql(
                f"ALTER TABLE {self.config.fully_qualified_entities} "
                "ADD COLUMN IF NOT EXISTS column_bindings "
                "ARRAY<STRUCT<attribute_name: STRING, bound_table: STRING, bound_column: STRING>>"
            )
        except Exception:
            pass
        # MERGE: Backfill source_columns and column_bindings on table-level
        # entities from their associated column-level entities. Groups all
        # column-level entities by entity_name, flattens their source_columns
        # into a single array, then merges into the matching table-level entity.
        # Only updates rows where source_columns is currently empty (SIZE = 0),
        # so manual overrides are preserved.
        # WHY: Table-level entities are discovered first (from table names/comments),
        # then column-level entities add finer detail. This backfill propagates
        # column knowledge upward so the table entity knows which columns it owns.
        # TRADEOFFS: GROUP BY entity_name alone (not per-table) means if two
        # tables produce column entities with the same entity_name, their columns
        # are merged together. This is intentional -- the entity type is the same
        # regardless of which table the column came from. The alternative (grouping
        # by entity_name + source_tables[0]) caused a MERGE multi-match error when
        # multiple source rows matched the same target via array_contains.
        try:
            self.spark.sql(
                f"""
            MERGE INTO {self.config.fully_qualified_entities} AS tbl
            USING (
                SELECT entity_name,
                       array_distinct(flatten(collect_list(source_columns))) AS cols,
                       flatten(collect_list(COALESCE(column_bindings, array()))) AS bindings
                FROM {self.config.fully_qualified_entities}
                WHERE attributes['granularity'] = 'column'
                  AND SIZE(source_columns) > 0
                GROUP BY entity_name
            ) AS col_agg
            ON tbl.entity_name = col_agg.entity_name
               AND COALESCE(tbl.attributes['granularity'], 'table') = 'table'
            WHEN MATCHED AND SIZE(tbl.source_columns) = 0 THEN
                UPDATE SET source_columns = col_agg.cols,
                           column_bindings = col_agg.bindings,
                           updated_at = current_timestamp()
            """
            )
            logger.info("Backfilled source_columns and column_bindings on table-level entities")
            return 1
        except Exception as e:
            logger.warning(f"Could not backfill source_columns: {e}")
            return 0

    def populate_entity_metrics(
        self, model_endpoint: Optional[str] = None,
    ) -> int:
        """Generate entity-level metric suggestions and populate ontology_metrics."""
        model_endpoint = model_endpoint or "databricks-gpt-oss-120b"
        ents = self.spark.sql(
            f"""
            SELECT entity_id, entity_name, entity_type, description,
                   source_tables, source_columns
            FROM {self.config.fully_qualified_entities}
            WHERE confidence >= 0.5 AND COALESCE(attributes['granularity'], 'table') = 'table'
        """
        ).collect()
        if not ents:
            return 0

        # Get column metadata for the source tables
        all_tables = set()
        for e in ents:
            for t in e["source_tables"] or []:
                all_tables.add(t)
        tbl_clause = ", ".join(f"'{t}'" for t in all_tables)
        col_meta = {}
        if tbl_clause:
            col_rows = self.spark.sql(
                f"SELECT table_name, column_name, data_type FROM {self.config.fully_qualified_column_kb} "
                f"WHERE table_name IN ({tbl_clause})"
            ).collect()
            for c in col_rows:
                col_meta.setdefault(c["table_name"], []).append(
                    f"{c['column_name']} {c['data_type']}"
                )

        all_metrics = []
        for e in ents:
            tables = e["source_tables"] or []
            cols_context = ""
            for t in tables:
                c_list = col_meta.get(t, [])
                if c_list:
                    cols_context += f"  {t}: {', '.join(c_list)}\n"
            prompt = (
                f"Entity: {e['entity_name']} ({e['entity_type']})\n"
                f"Description: {e['description']}\n"
                f"Tables and columns:\n{cols_context}\n"
                "Generate 3-5 business metrics for this entity as JSON array. "
                'Each: {{"metric_name": "...", "description": "...", '
                '"aggregation_type": "SUM|COUNT|AVG|MIN|MAX", '
                '"source_field": "column_name", "filter_condition": "optional WHERE clause"}}. '
                "Only output JSON array."
            )
            escaped = prompt.replace("'", "''")
            try:
                result = self.spark.sql(
                    f"SELECT AI_QUERY('{model_endpoint}', '{escaped}') as response"
                ).collect()[0]["response"]
                text = result.strip()
                text = re.sub(r"^```(?:json)?\s*", "", text)
                text = re.sub(r"\s*```$", "", text)
                s, end = text.find("["), text.rfind("]")
                if s != -1 and end != -1:
                    metrics = json.loads(text[s : end + 1])
                else:
                    continue
            except Exception as ex:
                logger.warning(
                    "AI metric generation failed for %s: %s", e["entity_name"], ex
                )
                continue

            now = datetime.now().isoformat()
            for m in metrics:
                mname = m.get("metric_name", "")
                # Deterministic ID: idempotent on re-run (fixes duplicate bug)
                mid = str(uuid.uuid5(
                    uuid.NAMESPACE_DNS, f"{e['entity_id']}_{mname}"
                ))
                all_metrics.append({
                    "metric_id": mid,
                    "metric_name": mname,
                    "description": m.get("description", ""),
                    "entity_id": e["entity_id"],
                    "aggregation_type": m.get("aggregation_type", ""),
                    "source_field": m.get("source_field", ""),
                    "filter_condition": m.get("filter_condition", ""),
                    "created_at": now,
                })

        if not all_metrics:
            return 0

        # Dedup by metric_id (LLM can return duplicate metric_name for one entity)
        seen = {}
        for m in all_metrics:
            seen[m["metric_id"]] = m
        all_metrics = list(seen.values())

        # Batch write via MERGE (idempotent on re-run)
        from pyspark.sql.types import StructType, StructField, StringType
        schema = StructType([
            StructField("metric_id", StringType()),
            StructField("metric_name", StringType()),
            StructField("description", StringType()),
            StructField("entity_id", StringType()),
            StructField("aggregation_type", StringType()),
            StructField("source_field", StringType()),
            StructField("filter_condition", StringType()),
            StructField("created_at", StringType()),
        ])
        metrics_df = self.spark.createDataFrame(all_metrics, schema)
        metrics_df.createOrReplaceTempView("_new_entity_metrics")
        # MERGE: Upsert LLM-generated entity-level metric suggestions into
        # ontology_metrics. Keyed on metric_id (deterministic uuid5 from entity_id
        # + metric_name). Existing metrics get their description/aggregation updated;
        # new metrics are inserted with NULL sql_definition and uc_view_name (to be
        # filled later by the semantic layer builder).
        # WHY: The LLM suggests business metrics per entity (e.g., "Average length
        # of stay" for a Patient entity). These are stored centrally so the semantic
        # layer can later generate SQL definitions and deploy as UC metric views.
        # TRADEOFFS: MERGE-by-metric_id is idempotent across re-runs. The LLM may
        # suggest slightly different names/descriptions each run, which overwrites
        # the prior version. If a steward has edited a metric, the LLM's update
        # will overwrite those edits -- a future enhancement could add a
        # steward_override flag similar to entities.
        self.spark.sql(f"""
            MERGE INTO {self.config.fully_qualified_metrics} AS t
            USING _new_entity_metrics AS s ON t.metric_id = s.metric_id
            WHEN MATCHED THEN UPDATE SET
                metric_name = s.metric_name, description = s.description,
                aggregation_type = s.aggregation_type, source_field = s.source_field,
                filter_condition = s.filter_condition, updated_at = s.created_at
            WHEN NOT MATCHED THEN INSERT (
                metric_id, metric_name, description, entity_id,
                sql_definition, uc_view_name, aggregation_type,
                source_field, filter_condition, created_at, updated_at
            ) VALUES (
                s.metric_id, s.metric_name, s.description, s.entity_id,
                NULL, NULL, s.aggregation_type,
                s.source_field, s.filter_condition, s.created_at, NULL
            )
        """)

        logger.info("Populated %d ontology metrics (MERGE, idempotent)", len(all_metrics))
        return len(all_metrics)

    def compute_ontology_metrics(self) -> int:
        """Compute aggregate ontology health metrics and write to ontology_metrics."""
        ent = self.config.fully_qualified_entities
        edges = f"{self.config.catalog_name}.{self.config.schema_name}.graph_edges"
        kb = self.config.fully_qualified_kb
        metrics_tbl = self.config.fully_qualified_metrics
        now = datetime.now().isoformat()

        try:
            rows = self.spark.sql(f"""
                WITH ent AS (SELECT * FROM {ent}),
                kb AS (SELECT DISTINCT table_name FROM {kb}),
                covered AS (
                    SELECT DISTINCT t.table_name
                    FROM ent e LATERAL VIEW EXPLODE(e.source_tables) t AS table_name
                    WHERE COALESCE(e.attributes['granularity'], 'table') = 'table'
                ),
                edge_counts AS (
                    SELECT relationship, COUNT(*) as cnt FROM {edges}
                    WHERE relationship IN ('instance_of','has_attribute','is_a','references')
                    GROUP BY relationship
                )
                SELECT
                    COUNT(DISTINCT e.entity_id) as total_entities,
                    COUNT(DISTINCT e.entity_type) as total_entity_types,
                    ROUND(AVG(e.confidence), 4) as avg_confidence,
                    ROUND(COALESCE(
                        (SELECT COUNT(*) FROM covered) * 100.0 / NULLIF((SELECT COUNT(*) FROM kb), 0)
                    , 0), 1) as table_coverage_pct,
                    SUM(CASE WHEN SIZE(COALESCE(e.column_bindings, ARRAY())) > 0 THEN 1 ELSE 0 END) as entities_with_bindings,
                    SUM(CASE WHEN COALESCE(e.attributes['discovery_method'],'') LIKE '%keyword%' THEN 1 ELSE 0 END) as keyword_discovered,
                    SUM(CASE WHEN COALESCE(e.attributes['discovery_method'],'') LIKE '%ai%' THEN 1 ELSE 0 END) as ai_discovered,
                    SUM(CASE WHEN e.confidence < 0.5 THEN 1 ELSE 0 END) as low_confidence_count,
                    (SELECT COALESCE(SUM(cnt),0) FROM edge_counts) as ontology_edges_total,
                    (SELECT COALESCE(MAX(cnt),0) FROM edge_counts WHERE relationship='instance_of') as instance_of_edges,
                    (SELECT COALESCE(MAX(cnt),0) FROM edge_counts WHERE relationship='has_attribute') as has_attribute_edges,
                    (SELECT COALESCE(MAX(cnt),0) FROM edge_counts WHERE relationship='is_a') as is_a_edges,
                    (SELECT COALESCE(MAX(cnt),0) FROM edge_counts WHERE relationship='references') as references_edges
                FROM ent e
            """).collect()[0]

            metrics = [
                ("total_entities", "Total discovered entities", str(rows.total_entities)),
                ("total_entity_types", "Distinct entity types", str(rows.total_entity_types)),
                ("avg_confidence", "Average entity confidence", str(rows.avg_confidence)),
                ("table_coverage_pct", "% of KB tables with an entity", str(rows.table_coverage_pct)),
                ("binding_completeness_pct", "% of entities with column bindings",
                 str(round(rows.entities_with_bindings * 100.0 / max(rows.total_entities, 1), 1))),
                ("keyword_discovered", "Entities discovered by keyword", str(rows.keyword_discovered)),
                ("ai_discovered", "Entities discovered by AI", str(rows.ai_discovered)),
                ("low_confidence_count", "Entities with confidence < 0.5", str(rows.low_confidence_count)),
                ("ontology_edges_total", "Total ontology relationship edges", str(rows.ontology_edges_total)),
                ("instance_of_edges", "Table-to-entity edges", str(rows.instance_of_edges)),
                ("has_attribute_edges", "Entity-to-column edges", str(rows.has_attribute_edges)),
                ("is_a_edges", "Hierarchy edges", str(rows.is_a_edges)),
                ("references_edges", "Entity cross-reference edges", str(rows.references_edges)),
            ]

            for name, desc, val in metrics:
                mid = str(uuid.uuid5(uuid.NAMESPACE_DNS, f"ontology_metric_{name}"))
                escaped_desc = desc.replace("'", "''")
                # MERGE: Upsert a single computed aggregate metric (e.g., entity_count,
                # coverage_pct, low_confidence_count) into ontology_metrics. Executed
                # once per metric name in a loop. The sql_definition field stores the
                # computed value as a string (not actual SQL).
                # WHY: These aggregate health metrics give the dashboard a quick
                # overview of ontology quality without expensive live queries.
                # TRADEOFFS: Running one MERGE per metric in a loop is N round-trips
                # to the Delta table. A batch approach (single MERGE with all metrics)
                # would be more efficient but harder to read. The metric count is
                # small (~15) so the overhead is negligible.
                self.spark.sql(f"""
                    MERGE INTO {metrics_tbl} t
                    USING (SELECT '{mid}' as metric_id) s ON t.metric_id = s.metric_id
                    WHEN MATCHED THEN UPDATE SET
                        sql_definition = '{val}', updated_at = '{now}'
                    WHEN NOT MATCHED THEN INSERT (
                        metric_id, metric_name, description, entity_id,
                        sql_definition, uc_view_name, aggregation_type,
                        source_field, filter_condition, created_at, updated_at
                    ) VALUES (
                        '{mid}', '{name}', '{escaped_desc}', NULL,
                        '{val}', NULL, 'COMPUTED', NULL, NULL, '{now}', '{now}'
                    )
                """)

            logger.info("Computed %d ontology metrics", len(metrics))
            return len(metrics)
        except Exception as e:
            logger.warning("Failed to compute ontology metrics: %s", e)
            return 0

    def apply_entity_tags(self) -> int:
        """Apply entity tags to UC tables and columns from discovered entities.

        Also writes an audit log to ``{schema}.entity_tag_audit_log`` for
        compliance traceability.
        """
        from datetime import datetime as _dt

        min_conf = self._validation_cfg.get("min_entity_confidence", 0.5)
        tag_key = self.config.entity_tag_key
        bundle_ver = self._get_bundle_version()
        tagged = 0
        audit_rows: list = []
        now = _dt.utcnow().isoformat()

        fed = getattr(self.config, "federation_mode", False)

        # Table-level tags
        try:
            table_ents_df = self.spark.sql(
                f"""
                SELECT entity_type, confidence,
                       COALESCE(attributes['discovery_method'], 'unknown') AS discovery_method,
                       EXPLODE(source_tables) AS table_name
                FROM {self.config.fully_qualified_entities}
                WHERE COALESCE(attributes['granularity'], 'table') = 'table'
                  AND confidence >= {min_conf}
            """
            )
            for row in table_ents_df.toLocalIterator():
                action = "failed"
                try:
                    if fed:
                        self.spark.sql(
                            f"SET TAG ON TABLE {row.table_name} "
                            f"{tag_key} = '{row.entity_type}', "
                            f"ontology_bundle_version = '{bundle_ver}'"
                        )
                    else:
                        self.spark.sql(
                            f"ALTER TABLE {row.table_name} SET TAGS ("
                            f"'{tag_key}' = '{row.entity_type}', "
                            f"'ontology_bundle_version' = '{bundle_ver}')"
                        )
                    tagged += 1
                    action = "applied"
                except Exception as e:
                    logger.warning("Failed to tag table %s: %s", row.table_name, e)
                audit_rows.append((
                    now, row.table_name, None, tag_key, row.entity_type,
                    float(row.confidence), bundle_ver, row.discovery_method, action,
                ))
        except Exception as e:
            logger.warning("Could not read table-level entities for tagging: %s", e)

        # Column-level tags
        try:
            from collections import defaultdict as _defaultdict

            col_ents = self.spark.sql(
                f"""
                SELECT entity_type, confidence,
                       COALESCE(attributes['discovery_method'], 'unknown') AS discovery_method,
                       get(source_tables, 0) AS table_name,
                       EXPLODE(source_columns) AS col_name
                FROM {self.config.fully_qualified_entities}
                WHERE attributes['granularity'] = 'column'
                  AND confidence >= {min_conf}
                  AND SIZE(source_columns) > 0
            """
            ).collect()

            table_col_tags = _defaultdict(list)
            for row in col_ents:
                table_col_tags[row.table_name].append(row)

            for tbl, rows in table_col_tags.items():
                if fed:
                    # SET TAG ON COLUMN: one statement per column for federation
                    for r in rows:
                        try:
                            self.spark.sql(
                                f"SET TAG ON COLUMN {tbl}.`{r.col_name}` "
                                f"{tag_key} = '{r.entity_type}', "
                                f"ontology_bundle_version = '{bundle_ver}'"
                            )
                            tagged += 1
                            audit_rows.append((
                                now, tbl, r.col_name, tag_key, r.entity_type,
                                float(r.confidence), bundle_ver, r.discovery_method, "applied",
                            ))
                        except Exception as e:
                            logger.warning("Failed to tag column %s.%s: %s", tbl, r.col_name, e)
                            audit_rows.append((
                                now, tbl, r.col_name, tag_key, r.entity_type,
                                float(r.confidence), bundle_ver, r.discovery_method, "failed",
                            ))
                else:
                    # Batched ALTER TABLE ... ALTER COLUMN (DBR 16.3+)
                    col_specs = [
                        f"`{r.col_name}` SET TAGS "
                        f"('{tag_key}' = '{r.entity_type}', "
                        f"'ontology_bundle_version' = '{bundle_ver}')"
                        for r in rows
                    ]
                    try:
                        self.spark.sql(f"ALTER TABLE {tbl} ALTER COLUMN {', '.join(col_specs)}")
                        tagged += len(rows)
                        for r in rows:
                            audit_rows.append((
                                now, tbl, r.col_name, tag_key, r.entity_type,
                                float(r.confidence), bundle_ver, r.discovery_method, "applied",
                            ))
                    except Exception as e:
                        logger.warning("Batch column tagging failed for %s: %s", tbl, e)
                        for r in rows:
                            audit_rows.append((
                                now, tbl, r.col_name, tag_key, r.entity_type,
                                float(r.confidence), bundle_ver, r.discovery_method, "failed",
                            ))
        except Exception as e:
            logger.warning("Could not read column-level entities for tagging: %s", e)

        # Write audit log
        if audit_rows:
            audit_tbl = f"{self.config.catalog_name}.{self.config.schema_name}.entity_tag_audit_log"
            try:
                self.spark.sql(f"""
                    CREATE TABLE IF NOT EXISTS {audit_tbl} (
                        timestamp STRING, table_name STRING, column_name STRING,
                        tag_key STRING, tag_value STRING, confidence DOUBLE,
                        bundle_version STRING, discovery_method STRING, action STRING
                    ) USING DELTA
                """)
                cols = ["timestamp", "table_name", "column_name", "tag_key",
                        "tag_value", "confidence", "bundle_version",
                        "discovery_method", "action"]
                audit_df = self.spark.createDataFrame(audit_rows, cols)
                # APPEND: Write entity tag audit records to entity_tag_audit_log.
                # Each row records which UC tag was applied or failed, on which table/
                # column, at what confidence, and by which bundle version.
                # WHY: Compliance and governance traceability -- if a table gets
                # tagged as PHI, the audit log proves when and why.
                # TRADEOFFS: Append-only means the table grows without bound. A
                # retention policy (DELETE WHERE timestamp < X) could be added but
                # isn't critical given the low volume (one row per tag operation).
                audit_df.write.mode("append").saveAsTable(audit_tbl)
                logger.info("Wrote %d rows to %s", len(audit_rows), audit_tbl)
            except Exception as e:
                logger.warning("Failed to write tag audit log: %s", e)

        logger.info("Applied %d entity tags to UC objects", tagged)
        return tagged

    def get_entity_summary(self) -> DataFrame:
        """Get summary of discovered entities."""
        return self.spark.sql(
            f"""
            SELECT 
                entity_type,
                COUNT(*) as entity_count,
                ROUND(AVG(confidence), 2) as avg_confidence,
                SUM(CASE WHEN validated THEN 1 ELSE 0 END) as validated_count
            FROM {self.config.fully_qualified_entities}
            GROUP BY entity_type
            ORDER BY entity_count DESC
        """
        )

    def get_geographic_coverage_report(self) -> DataFrame:
        """Column-level geographic classification completeness report.

        Joins column_properties, entities, and column_knowledge_base to produce
        a per-column view showing whether each column has been classified as
        geographic, non_geographic, or remains unreviewed.
        """
        cp = self.config.fully_qualified_column_properties
        ent = self.config.fully_qualified_entities
        ckb = f"{self.config.catalog_name}.{self.config.schema_name}.{self.config.column_kb_table}"

        return self.spark.sql(f"""
            WITH all_cols AS (
                SELECT DISTINCT table_name, column_name FROM {ckb}
                WHERE table_name IS NOT NULL AND column_name IS NOT NULL
            ),
            cp_roles AS (
                SELECT table_name, column_name, property_role, confidence
                FROM {cp}
            ),
            geo_entities AS (
                SELECT EXPLODE(source_columns) AS col_name,
                       get(source_tables, 0) AS table_name,
                       entity_type AS geo_entity_subtype,
                       confidence AS entity_confidence
                FROM {ent}
                WHERE attributes['granularity'] = 'column'
                  AND (entity_type IN ('Geographic','Address','GeoCoordinate',
                       'AdminRegion','PostalCode','Timezone','Location')
                       OR LOWER(entity_type) LIKE '%geo%'
                       OR LOWER(entity_type) LIKE '%location%')
            )
            SELECT
                ac.table_name,
                ac.column_name,
                cp.property_role,
                cp.confidence AS property_confidence,
                ge.geo_entity_subtype,
                ge.entity_confidence,
                CASE
                    WHEN cp.property_role = 'geographic' OR ge.geo_entity_subtype IS NOT NULL
                        THEN 'geographic'
                    WHEN cp.property_role IS NOT NULL
                        THEN 'non_geographic'
                    ELSE 'unreviewed'
                END AS classification_status
            FROM all_cols ac
            LEFT JOIN cp_roles cp
                ON ac.table_name = cp.table_name AND ac.column_name = cp.column_name
            LEFT JOIN geo_entities ge
                ON ac.table_name = ge.table_name AND ac.column_name = ge.col_name
            ORDER BY classification_status, ac.table_name, ac.column_name
        """)

    def reconcile_geographic_classifications(self, dry_run: bool = True) -> DataFrame:
        """Find columns where property_role and entity classification disagree on geographic status.

        Args:
            dry_run: If True (default), only report conflicts. If False, update
                     column_properties.property_role to 'geographic' for columns
                     bound to geographic entities.

        Returns:
            DataFrame of conflicting rows.
        """
        cp = self.config.fully_qualified_column_properties
        ent = self.config.fully_qualified_entities

        conflicts = self.spark.sql(f"""
            WITH geo_bound AS (
                SELECT EXPLODE(source_columns) AS col_name,
                       get(source_tables, 0) AS table_name,
                       entity_type
                FROM {ent}
                WHERE attributes['granularity'] = 'column'
                  AND (entity_type IN ('Geographic','Address','GeoCoordinate',
                       'AdminRegion','PostalCode','Timezone','Location')
                       OR LOWER(entity_type) LIKE '%geo%'
                       OR LOWER(entity_type) LIKE '%location%')
            )
            SELECT cp.table_name, cp.column_name, cp.property_role,
                   gb.entity_type AS geo_entity_type,
                   CASE
                       WHEN gb.entity_type IS NOT NULL AND cp.property_role != 'geographic'
                           THEN 'entity_says_geo_but_role_disagrees'
                       WHEN gb.entity_type IS NULL AND cp.property_role = 'geographic'
                           THEN 'role_says_geo_but_no_entity'
                   END AS conflict_type
            FROM {cp} cp
            LEFT JOIN geo_bound gb
                ON cp.table_name = gb.table_name AND cp.column_name = gb.col_name
            WHERE (gb.entity_type IS NOT NULL AND cp.property_role != 'geographic')
               OR (gb.entity_type IS NULL AND cp.property_role = 'geographic')
        """)

        conflict_count = conflicts.count()
        logger.info("Geographic reconciliation: %d conflicts found (dry_run=%s)",
                     conflict_count, dry_run)

        if not dry_run and conflict_count > 0:
            fix_rows = conflicts.filter("conflict_type = 'entity_says_geo_but_role_disagrees'").collect()
            updated = 0
            for row in fix_rows:
                try:
                    # UPDATE: Fix a specific column's property_role to 'geographic'
                    # when the geo classifier and ontology entity disagree. Applied
                    # row-by-row for conflicting columns identified by the reconciliation
                    # query above.
                    # WHY: The geo classifier and ontology discoverer run independently.
                    # When an entity marks a column as geographic but the column
                    # property says otherwise, the entity takes precedence.
                    # TRADEOFFS: Row-by-row UPDATE in a loop is slow for large conflict
                    # sets. A batch UPDATE with a JOIN would be faster, but conflicts
                    # are rare (typically < 10) so the simplicity is worth it.
                    self.spark.sql(f"""
                        UPDATE {cp}
                        SET property_role = 'geographic'
                        WHERE table_name = '{row.table_name}'
                          AND column_name = '{row.column_name}'
                    """)
                    updated += 1
                except Exception as e:
                    logger.warning("Failed to reconcile %s.%s: %s",
                                   row.table_name, row.column_name, e)
            logger.info("Reconciliation updated %d column property roles to 'geographic'", updated)

        return conflicts

    def discover_inter_entity_relationships(self) -> Dict[str, Any]:
        """Discover typed relationships between entities using declared relationships.

        Builds a lookup from entity definitions' ``relationships`` maps.
        For each FK-linked table pair whose entities match a declared
        relationship, the declared name and cardinality are used.
        Falls back to ``"references"`` when no declaration matches.

        Returns a summary dict with ``edges_added`` and
        ``undiscovered_declared`` (declared relationships not found via FKs).
        """
        fk_table = f"{self.config.catalog_name}.{self.config.schema_name}.fk_predictions"
        ent_table = self.config.fully_qualified_entities
        result: Dict[str, Any] = {"edges_added": 0, "undiscovered_declared": []}

        # Build declared relationship lookup as a broadcast DataFrame
        decl_rows = [
            (edef.name, rel_info.get("target", ""), rel_name, rel_info.get("cardinality", ""))
            for edef in self.discoverer.entity_definitions
            for rel_name, rel_info in edef.relationships.items()
            if rel_info.get("target")
        ]

        from pyspark.sql.types import (
            StructType, StructField, StringType, DoubleType, TimestampType,
        )
        import pyspark.sql.functions as F

        # Compute entity pairs via SQL joins (no driver-side collect + nested loop)
        try:
            ent_df = self.spark.sql(
                f"SELECT entity_id, entity_type, "
                f"COALESCE(ontology_bundle, '_default') AS ontology_bundle, "
                f"EXPLODE(source_tables) AS tbl "
                f"FROM {ent_table} WHERE COALESCE(attributes['granularity'], 'table') = 'table' "
                f"AND confidence >= 0.4"
            )
        except Exception:
            return result

        try:
            fk_df = self.spark.sql(
                f"SELECT DISTINCT src_table, dst_table FROM {fk_table}"
                f" WHERE final_confidence >= 0.5 AND (is_fk IS NULL OR is_fk = TRUE)"
            )
        except Exception:
            logger.debug("No FK predictions available for relationship discovery")
            return result

        src_ent = ent_df.alias("se")
        dst_ent = ent_df.alias("de")
        pairs = (
            fk_df
            .join(src_ent, fk_df.src_table == F.col("se.tbl"))
            .join(dst_ent, fk_df.dst_table == F.col("de.tbl"))
            # Same-bundle resolver: a table can map to entities of different bundles, and an
            # FK can link two tables across bundles. Resolving entity-concept endpoints purely
            # by table name would fan out into cross-bundle edges (entity::fhir::X ->
            # entity::schema_org::Y). Require both endpoints to share a bundle. Table-level FK
            # structure is preserved separately via source_system='fk_predictions'.
            .where(F.col("se.ontology_bundle") == F.col("de.ontology_bundle"))
            .where(F.col("se.entity_type") != F.col("de.entity_type"))
            .select(
                F.concat(F.lit("entity::"), F.col("se.ontology_bundle"), F.lit("::"), F.col("se.entity_type")).alias("src_canonical"),
                F.col("se.entity_type").alias("src_type"),
                F.concat(F.lit("entity::"), F.col("de.ontology_bundle"), F.lit("::"), F.col("de.entity_type")).alias("dst_canonical"),
                F.col("de.entity_type").alias("dst_type"),
            )
            .distinct()
        )

        if decl_rows:
            decl_schema = StructType([
                StructField("d_src", StringType()), StructField("d_dst", StringType()),
                StructField("rel_name", StringType()), StructField("cardinality", StringType()),
            ])
            decl_df = F.broadcast(self.spark.createDataFrame(decl_rows, decl_schema))
            edges_df = pairs.join(
                decl_df,
                (pairs.src_type == decl_df.d_src) & (pairs.dst_type == decl_df.d_dst),
                "left",
            ).select(
                pairs.src_canonical.alias("src"),
                pairs.dst_canonical.alias("dst"),
                F.coalesce(decl_df.rel_name, F.lit("references")).alias("relationship"),
                F.when(decl_df.rel_name.isNotNull(), F.lit(0.8)).otherwise(F.lit(0.6)).alias("weight"),
                pairs.src_type, pairs.dst_type,
                decl_df.rel_name.alias("_matched_rel"),
            )
        else:
            edges_df = pairs.select(
                pairs.src_canonical.alias("src"), pairs.dst_canonical.alias("dst"),
                F.lit("references").alias("relationship"), F.lit(0.6).alias("weight"),
                pairs.src_type, pairs.dst_type,
                F.lit(None).cast("string").alias("_matched_rel"),
            )

        edge_count = edges_df.count()

        # Identify undiscovered declared relationships
        if decl_rows:
            if edge_count > 0:
                discovered = edges_df.where(F.col("_matched_rel").isNotNull()).select(
                    "src_type", "dst_type"
                ).distinct().collect()
                discovered_pairs = {(r.src_type, r.dst_type) for r in discovered}
            else:
                discovered_pairs = set()
            declared_map = {(s, t): rn for s, t, rn, _ in decl_rows}
            undiscovered = [
                {"source": s, "target": t, "relationship": declared_map[(s, t)]}
                for s, t in declared_map if (s, t) not in discovered_pairs
            ]
        else:
            undiscovered = []
        result["undiscovered_declared"] = undiscovered
        if undiscovered:
            logger.info(
                "Declared relationships not found via FK: %s",
                ", ".join(f"{u['source']}->{u['relationship']}->{u['target']}" for u in undiscovered),
            )

        if edge_count == 0:
            logger.info("No inter-entity relationships discovered")
            return result

        write_df = edges_df.select(
            "src", "dst", "relationship", "weight",
            F.concat_ws("::", F.col("src"), F.col("dst"), F.col("relationship")).alias("edge_id"),
            F.col("relationship").alias("edge_type"),
            F.lit("out").alias("direction"),
            F.col("relationship").alias("ontology_rel"),
            F.lit("ontology").alias("source_system"),
            F.lit("candidate").alias("status"),
            F.current_timestamp().alias("created_at"),
            F.current_timestamp().alias("updated_at"),
        ).dropDuplicates(["edge_id"])
        edge_count = write_df.count()
        logger.info("Built %d inter-entity relationship edges", edge_count)
        result["edges_added"] = edge_count
        result["edges_df"] = write_df
        return result

    def _seed_concept_parent_entities(self) -> int:
        """Seed abstract concept rows for parent entity types referenced by
        discovered entities but never discovered themselves (FHIR
        DomainResource/Resource, OMOP OmopCDMThing, schema_org intermediates).

        Without these rows, _build_hierarchy_edges skips is_a edges to
        undiscovered parents (it requires both endpoints in discovered_types)
        and the roots have no graph node. Seeded rows carry empty source_tables
        so they stay 'referenced', never get instance_of edges, and are ignored
        by primary/FK logic.

        INSERT-only MERGE: never overwrites an existing (possibly human-edited)
        row and never bumps updated_at on re-runs, preserving incremental
        watermarks. Seeding is bounded to the ancestor closure of discovered
        types, keeping the set tiny.
        """
        entity_defs = self.ontology_config.get("entities", {}).get("definitions", {})
        parent_map: Dict[str, List[str]] = {}
        category_map: Dict[str, List[str]] = {}
        for name, defn in entity_defs.items():
            if not isinstance(defn, dict):
                continue
            single = defn.get("parent") or defn.get("subclass_of")
            if single:
                parent_map[name] = [single]
            else:
                plist = defn.get("parents", [])
                if isinstance(plist, list) and plist:
                    parent_map[name] = [p for p in plist if isinstance(p, str)]
            cats = defn.get("categories", [])
            if isinstance(cats, list) and cats:
                category_map[name] = [c for c in cats if isinstance(c, str)]
        if not parent_map and not category_map:
            return 0

        ent_table = self.config.fully_qualified_entities
        try:
            discovered = {
                r.entity_type
                for r in self.spark.sql(
                    f"SELECT DISTINCT entity_type FROM {ent_table}"
                ).collect()
            }
        except Exception:
            return 0
        if not discovered:
            return 0

        # Ancestor closure of discovered types only.
        ancestors: set = set()
        seen: set = set()
        stack = list(discovered)
        while stack:
            node = stack.pop()
            for p in parent_map.get(node, []):
                if p not in discovered:
                    ancestors.add(p)
                if p not in seen:
                    seen.add(p)
                    stack.append(p)

        # Category nodes referenced by discovered types but not discovered (flat,
        # no closure). Seeded so categorized_as edges have an existing target node.
        categories: set = set()
        for node in discovered:
            for c in category_map.get(node, []):
                if c not in discovered:
                    categories.add(c)

        # Drop primitive datatype names (Number, Date, Integer, ...): they are
        # schema.org DataTypes, not semantic ancestors, and add noise. Mirrors the
        # discovered-entity filter in _store_entities. Inert for FHIR/OMOP, which
        # define none of these names as parents/categories.
        ancestors = {a for a in ancestors if a.lower() not in EntityDiscoverer.PRIMITIVE_TYPE_NAMES}
        categories = {c for c in categories if c.lower() not in EntityDiscoverer.PRIMITIVE_TYPE_NAMES}

        if not ancestors and not categories:
            return 0

        bundle = self.config.ontology_bundle or "default"
        now = datetime.now()
        rows = []

        def _row(name, granularity):
            d = entity_defs.get(name)
            desc = (d.get("description") if isinstance(d, dict) else "") or ""
            return (
                f"seeded::{bundle}::{name}", name, name, desc,
                [], [], {"discovery_method": "seeded_hierarchy", "granularity": granularity},
                1.0, True, False, bundle, "referenced", now, now,
            )

        for name in sorted(ancestors):
            rows.append(_row(name, "abstract"))
        for name in sorted(categories - ancestors):
            rows.append(_row(name, "category"))

        seed_schema = StructType([
            StructField("entity_id", StringType()),
            StructField("entity_name", StringType()),
            StructField("entity_type", StringType()),
            StructField("description", StringType()),
            StructField("source_tables", ArrayType(StringType())),
            StructField("source_columns", ArrayType(StringType())),
            StructField("attributes", MapType(StringType(), StringType())),
            StructField("confidence", DoubleType()),
            StructField("auto_discovered", BooleanType()),
            StructField("validated", BooleanType()),
            StructField("ontology_bundle", StringType()),
            StructField("entity_role", StringType()),
            StructField("created_at", TimestampType()),
            StructField("updated_at", TimestampType()),
        ])
        seed_df = self.spark.createDataFrame(rows, schema=seed_schema)
        seed_df.createOrReplaceTempView("_seed_concept_entities")
        self.spark.sql(f"""
            MERGE INTO {ent_table} AS target
            USING _seed_concept_entities AS source
            ON target.entity_id = source.entity_id
            WHEN NOT MATCHED THEN INSERT (
                entity_id, entity_name, entity_type, description,
                source_tables, source_columns, attributes, confidence,
                auto_discovered, validated, ontology_bundle, entity_role,
                created_at, updated_at
            ) VALUES (
                source.entity_id, source.entity_name, source.entity_type, source.description,
                source.source_tables, source.source_columns, source.attributes, source.confidence,
                source.auto_discovered, source.validated, source.ontology_bundle, source.entity_role,
                source.created_at, source.updated_at
            )
        """)
        self.spark.sql("DROP VIEW IF EXISTS _seed_concept_entities")
        logger.info(
            "Seeded %d concept nodes (%d abstract ancestors, %d categories)",
            len(rows), len(ancestors), len(categories - ancestors),
        )
        return len(rows)

    def _build_hierarchy_edges(self) -> Optional[DataFrame]:
        """Build is_a edges from child entity types to their parent types.

        Uses canonical concept node IDs so hierarchy edges connect concept
        nodes directly (e.g., entity::_default::Encounter -> entity::_default::Event).
        Supports both singular `parent:` and plural `parents:` list in bundle YAML.
        """
        entity_defs = self.ontology_config.get("entities", {}).get("definitions", {})
        parent_map: Dict[str, List[str]] = {}
        for name, defn in entity_defs.items():
            parents: List[str] = []
            single = defn.get("parent") or defn.get("subclass_of")
            if single:
                parents.append(single)
            else:
                plist = defn.get("parents", [])
                if isinstance(plist, list):
                    parents = [p for p in plist if isinstance(p, str)]
            if parents:
                parent_map[name] = parents

        if not parent_map:
            return None

        ent_table = self.config.fully_qualified_entities
        try:
            discovered_types = {
                r.entity_type
                for r in self.spark.sql(
                    f"SELECT DISTINCT entity_type FROM {ent_table}"
                ).collect()
            }
        except Exception:
            return None

        bundle = self.config.ontology_bundle or None

        new_edges = []
        for child_type, parent_types in parent_map.items():
            if child_type not in discovered_types:
                continue
            for parent_type in parent_types:
                if parent_type not in discovered_types:
                    continue
                child_id = self.canonical_entity_id(child_type, bundle)
                parent_id = self.canonical_entity_id(parent_type, bundle)
                new_edges.append((child_id, parent_id, "is_a", 1.0))

        if not new_edges:
            return None

        now = datetime.now()
        _hierarchy_schema = StructType([
            StructField("src", StringType()),
            StructField("dst", StringType()),
            StructField("relationship", StringType()),
            StructField("weight", DoubleType()),
            StructField("edge_id", StringType()),
            StructField("edge_type", StringType()),
            StructField("direction", StringType()),
            StructField("ontology_rel", StringType()),
            StructField("source_system", StringType()),
            StructField("status", StringType()),
            StructField("created_at", TimestampType()),
            StructField("updated_at", TimestampType()),
        ])
        edge_df = self.spark.createDataFrame(
            [
                (s, d, "is_a", w,
                 f"{s}::{d}::is_a", "is_a", "out",
                 "is_a", "ontology", "candidate", now, now)
                for s, d, _, w in new_edges
            ],
            schema=_hierarchy_schema,
        )
        logger.info("Built %d hierarchy (is_a) edges", len(new_edges))
        return edge_df

    def _build_category_edges(self) -> Optional[DataFrame]:
        """Build categorized_as edges from entities to their category nodes.

        Mirrors _build_hierarchy_edges but reads the `categories` field (e.g. FHIR
        W5 groupings like clinical.general). Keeps categorization on a separate axis
        from is_a so the class hierarchy stays clean. Category target nodes are
        seeded by _seed_concept_parent_entities.
        """
        entity_defs = self.ontology_config.get("entities", {}).get("definitions", {})
        category_map: Dict[str, List[str]] = {}
        for name, defn in entity_defs.items():
            cats = defn.get("categories", []) if isinstance(defn, dict) else []
            if isinstance(cats, list):
                vals = [c for c in cats if isinstance(c, str)]
                if vals:
                    category_map[name] = vals
        if not category_map:
            return None

        ent_table = self.config.fully_qualified_entities
        try:
            discovered_types = {
                r.entity_type
                for r in self.spark.sql(
                    f"SELECT DISTINCT entity_type FROM {ent_table}"
                ).collect()
            }
        except Exception:
            return None

        bundle = self.config.ontology_bundle or None
        new_edges = []
        for child_type, cats in category_map.items():
            if child_type not in discovered_types:
                continue
            for cat in cats:
                if cat not in discovered_types:
                    continue
                child_id = self.canonical_entity_id(child_type, bundle)
                cat_id = self.canonical_entity_id(cat, bundle)
                new_edges.append((child_id, cat_id))

        if not new_edges:
            return None

        now = datetime.now()
        _category_schema = StructType([
            StructField("src", StringType()),
            StructField("dst", StringType()),
            StructField("relationship", StringType()),
            StructField("weight", DoubleType()),
            StructField("edge_id", StringType()),
            StructField("edge_type", StringType()),
            StructField("direction", StringType()),
            StructField("ontology_rel", StringType()),
            StructField("source_system", StringType()),
            StructField("status", StringType()),
            StructField("created_at", TimestampType()),
            StructField("updated_at", TimestampType()),
        ])
        edge_df = self.spark.createDataFrame(
            [
                (s, d, "categorized_as", 1.0,
                 f"{s}::{d}::categorized_as", "categorized_as", "out",
                 "categorized_as", "ontology", "candidate", now, now)
                for s, d in new_edges
            ],
            schema=_category_schema,
        )
        logger.info("Built %d categorized_as edges", len(new_edges))
        return edge_df

    @staticmethod
    def canonical_entity_id(entity_name: str, ontology_bundle: Optional[str] = None) -> str:
        """Deterministic graph node ID for an ontology entity concept.

        One node per (entity_name, ontology_bundle) pair in graph_nodes.
        """
        bundle = ontology_bundle or "_default"
        return f"entity::{bundle}::{entity_name}"

    CANONICAL_ID_SQL = "CONCAT('entity::', COALESCE(ontology_bundle, '_default'), '::', entity_name)"

    @staticmethod
    def _source_tables_scope_predicate(table_names: Optional[list]) -> str:
        """Return a boolean SQL predicate (no leading ``AND``) keeping only entities
        whose source_tables intersect *table_names*. Returns "" when table_names is empty.

        source_tables is an array, so this uses the higher-order ``exists`` predicate.
        Supports ``catalog.schema.*`` wildcards (LIKE) and literal names (=)."""
        if not table_names:
            return ""
        literals: list[str] = []
        wild_prefixes: list[str] = []
        for t in table_names:
            esc = t.replace("\\", "\\\\").replace("'", "''")
            if esc.endswith(".*"):
                wild_prefixes.append(esc[:-2])
            else:
                literals.append(f"'{esc}'")
        parts: list[str] = []
        if literals:
            parts.append(f"exists(source_tables, x -> x IN ({', '.join(literals)}))")
        for pfx in wild_prefixes:
            parts.append(f"exists(source_tables, x -> x LIKE '{pfx}.%')")
        return " OR ".join(parts)

    def _purge_entities_for_rebuild(self, table_names: Optional[list] = None) -> int:
        """Table-scoped refresh: delete auto-discovered entities (and their orphaned entity nodes)
        for the tables in scope so an explicit sweep re-run rebuilds those tables cleanly.

        Primarily a table refresh, NOT a bundle operation:
        - Scoped by source_tables intersection with table_names (via _source_tables_scope_predicate).
          Tables NOT in scope are never touched, so entities from other bundles keep coexisting.
        - Empty table_names = all tables in scope (full-schema replacement).
        - Bundle-agnostic for table-attributed rows: any auto-discovered entity on an in-scope table
          is removed, then the subsequent discovery pass repopulates those tables from the current
          bundle. (Entities the run no longer produces -- e.g. a different bundle's old
          classification, or filtered primitive datatypes -- are thus cleared.)

        One exception, for table-LESS seeded ancestors only: seeded hierarchy concepts
        (_seed_concept_parent_entities) carry empty source_tables, so a table scope can never match
        them. When a table scope is present, this also deletes the CURRENT bundle's table-less seeds
        (re-seeded fresh after the purge), so stale seeds (e.g. a primitive no longer seeded) clear.
        This is the single place a bundle filter is allowed -- it is the only attribution a table-less
        row has -- and it is scoped to the current bundle so OTHER bundles' seeds keep coexisting.

        Preservation rule:
        - auto_discovered=FALSE rows are steward overrides / human locks and are ALWAYS preserved.
          (The `validated` column is only a reviewer UI status, NOT deletion protection.)

        After deleting entities, orphan entity concept nodes (those whose deterministic id no longer
        maps to any surviving entity) are removed from graph_nodes via an exact anti-join on
        CANONICAL_ID_SQL. Returns the number of entity rows deleted.
        """
        ent_table = self.config.fully_qualified_entities
        nodes_table = f"{self.config.catalog_name}.{self.config.schema_name}.{self.config.nodes_table}"
        scope_pred = self._source_tables_scope_predicate(table_names)
        if scope_pred:
            # Table-attributed entities are matched by the table scope (bundle-agnostic).
            # Seeded hierarchy ancestors carry empty source_tables, so they have no table to
            # scope by -- the only safe attribution is the bundle that seeded them. Refresh ONLY
            # the current bundle's table-less seeds (re-seeded after the purge); other bundles'
            # seeds are preserved, keeping coexistence intact.
            bundle = (self.config.ontology_bundle or "").replace("\\", "\\\\").replace("'", "''")
            seed_pred = (
                "(source_tables IS NULL OR cardinality(source_tables) = 0) "
                f"AND COALESCE(ontology_bundle, '') = '{bundle}'"
            )
            where = (
                "COALESCE(auto_discovered, TRUE) = TRUE "
                f"AND (({scope_pred}) OR ({seed_pred}))"
            )
        else:
            # Empty table_names = full replacement: delete all auto-discovered rows (incl. seeds).
            where = "COALESCE(auto_discovered, TRUE) = TRUE"
        try:
            deleted = self.spark.sql(
                f"SELECT COUNT(*) AS c FROM {ent_table} WHERE {where}"
            ).collect()[0].c
            self.spark.sql(f"DELETE FROM {ent_table} WHERE {where}")
            self.spark.sql(
                f"DELETE FROM {nodes_table} "
                f"WHERE node_type = 'entity' AND source_system = 'ontology' "
                f"AND id NOT IN (SELECT {self.CANONICAL_ID_SQL} FROM {ent_table} WHERE entity_name IS NOT NULL)"
            )
            logger.warning(
                "Purged %d auto-discovered entities (table_scope=%s) and their orphaned graph nodes",
                deleted, table_names or "all",
            )
            return deleted
        except Exception as e:
            logger.warning("Could not purge entities for rebuild: %s", e)
            return 0

    def _purge_orphaned_bundle_seeds(self) -> int:
        """Delete table-less seeded ancestors of bundles that no longer have any
        table-attributed entities, then drop their now-orphaned concept nodes.

        Runs AFTER discovery + seeding -- deliberately NOT folded into
        _purge_entities_for_rebuild, whose DELETE evaluates its subquery on the
        pre-discovery snapshot: on a bundle switch (e.g. schema_org -> fhir_r4 on
        the same tables) the old bundle still has table-attributed entities at
        purge time, so it would never be detected as orphaned. At this later
        point a purged foreign bundle has zero table-attributed rows, so the
        orphan test is correct. Only auto-discovered seeds are touched (steward
        locks preserved); a bundle with any real table-attributed entity keeps
        its seeds (coexistence preserved). Gated by the caller on
        sweep_stale_entities AND NOT incremental.
        """
        ent_table = self.config.fully_qualified_entities
        nodes_table = f"{self.config.catalog_name}.{self.config.schema_name}.{self.config.nodes_table}"
        where = (
            "COALESCE(auto_discovered, TRUE) = TRUE "
            "AND (source_tables IS NULL OR cardinality(source_tables) = 0) "
            f"AND COALESCE(ontology_bundle, '') NOT IN ("
            f"SELECT DISTINCT COALESCE(ontology_bundle, '') FROM {ent_table} "
            "WHERE source_tables IS NOT NULL AND cardinality(source_tables) > 0)"
        )
        try:
            deleted = self.spark.sql(
                f"SELECT COUNT(*) AS c FROM {ent_table} WHERE {where}"
            ).collect()[0].c
            if deleted == 0:
                return 0
            self.spark.sql(f"DELETE FROM {ent_table} WHERE {where}")
            self.spark.sql(
                f"DELETE FROM {nodes_table} "
                f"WHERE node_type = 'entity' AND source_system = 'ontology' "
                f"AND id NOT IN (SELECT {self.CANONICAL_ID_SQL} FROM {ent_table} WHERE entity_name IS NOT NULL)"
            )
            logger.warning(
                "Purged %d orphaned table-less bundle seeds and their orphaned graph nodes",
                deleted,
            )
            return deleted
        except Exception as e:
            logger.warning("Could not purge orphaned bundle seeds: %s", e)
            return 0

    def _purge_stale_relationships(self) -> int:
        """Delete all auto-generated rows from ontology_relationships so they are
        regenerated cleanly on a non-incremental sweep.

        ontology_relationships has no other delete path: emit_bundle_edges is
        INSERT-only and discover_named_relationships is a natural-key upsert, so
        stale rows (renamed/removed relationships, a prior bundle's edges, the
        categorized_as/category_of regression) would otherwise persist forever.
        Every source here is auto-generated -- 'bundle' (emit_bundle_edges) and
        'fk_inferred'/'discovered'/'auto_inverse'/'configured' (discover_named_
        relationships; 'configured' is subclass_of from the bundle hierarchy, NOT
        a steward lock). The allowlist deletes exactly those plus NULL; any future
        human-authored source is preserved. Gated by the caller on a
        non-incremental sweep; callers re-run emit_bundle_edges +
        discover_named_relationships afterward to repopulate.
        """
        rels_table = self.config.fully_qualified_relationships
        cond = (
            "source IN ('bundle','fk_inferred','discovered','auto_inverse','configured') "
            "OR source IS NULL"
        )
        try:
            deleted = self.spark.sql(
                f"SELECT COUNT(*) AS c FROM {rels_table} WHERE {cond}"
            ).collect()[0].c
            self.spark.sql(f"DELETE FROM {rels_table} WHERE {cond}")
            logger.warning(
                "Purged %d auto-generated ontology_relationships rows for rebuild", deleted
            )
            return deleted
        except Exception as e:
            logger.warning("Could not purge stale relationships: %s", e)
            return 0

    def _sync_entity_nodes_to_graph(self) -> int:
        """Merge one canonical entity concept node per (entity_name, bundle) into graph_nodes.

        Each unique entity type gets exactly one graph node with a deterministic ID
        (entity::{bundle}::{entity_name}). Multiple instance rows in ontology_entities
        are collapsed: highest confidence wins, description from the highest-confidence
        row is used.
        """
        nodes_table = f"{self.config.catalog_name}.{self.config.schema_name}.{self.config.nodes_table}"
        edges_table = f"{self.config.catalog_name}.{self.config.schema_name}.graph_edges"
        ent_table = self.config.fully_qualified_entities
        canonical_id = self.CANONICAL_ID_SQL
        try:
            # Self-healing: only run legacy cleanup if UUID-based entity nodes exist
            has_legacy = self.spark.sql(f"""
                SELECT 1 FROM {nodes_table}
                WHERE node_type = 'entity' AND source_system = 'ontology' AND id NOT LIKE 'entity::%'
                LIMIT 1
            """).count() > 0

            if has_legacy:
                self.spark.sql(f"""
                    DELETE FROM {nodes_table}
                    WHERE node_type = 'entity'
                      AND source_system = 'ontology'
                      AND id NOT LIKE 'entity::%'
                """)
                self.spark.sql(f"""
                    DELETE FROM {edges_table}
                    WHERE source_system = 'ontology'
                      AND (
                        (edge_type = 'instance_of' AND dst NOT LIKE 'entity::%' AND dst NOT LIKE '%%.%%')
                        OR (edge_type IN ('has_property', 'has_attribute') AND src NOT LIKE 'entity::%' AND src NOT LIKE '%%.%%')
                        OR (edge_type = 'is_a' AND src NOT LIKE 'entity::%')
                        OR (edge_type NOT IN ('instance_of','has_property','has_attribute','is_a','same_entity_type')
                            AND src NOT LIKE 'entity::%' AND src NOT LIKE '%%.%%'
                            AND dst NOT LIKE 'entity::%' AND dst NOT LIKE '%%.%%')
                      )
                """)
                logger.info("Cleaned up legacy UUID-based entity nodes and associated edges")

            self.spark.sql(f"""
                MERGE INTO {nodes_table} AS target
                USING (
                    SELECT {canonical_id} AS canonical_id,
                           FIRST(entity_name) AS entity_name,
                           FIRST(entity_type) AS entity_type,
                           FIRST(description) AS description,
                           MAX(confidence) AS confidence,
                           MIN(created_at) AS created_at,
                           MAX(updated_at) AS updated_at
                    FROM {ent_table}
                    GROUP BY entity_name, COALESCE(ontology_bundle, '_default')
                ) AS source
                ON target.id = source.canonical_id
                    AND target.node_type = 'entity'

                WHEN MATCHED AND (
                    target.quality_score != source.confidence
                    OR target.ontology_type != source.entity_type
                    OR COALESCE(target.comment, '') != COALESCE(source.description, '')
                ) THEN UPDATE SET
                    target.table_short_name = source.entity_name,
                    target.comment = COALESCE(source.description, target.comment),
                    target.quality_score = source.confidence,
                    target.ontology_type = source.entity_type,
                    target.display_name = source.entity_name,
                    target.short_description = COALESCE(source.description, target.short_description),
                    target.status = 'primary',
                    target.updated_at = source.updated_at

                WHEN NOT MATCHED THEN INSERT (
                    id, table_name, catalog, `schema`, table_short_name,
                    domain, subdomain, has_pii, has_phi, security_level,
                    comment, node_type, parent_id, data_type,
                    quality_score, embedding,
                    ontology_id, ontology_type, display_name, short_description,
                    sensitivity, status, source_system, keywords,
                    created_at, updated_at
                ) VALUES (
                    source.canonical_id, NULL, NULL, NULL, source.entity_name,
                    NULL, NULL, FALSE, FALSE, 'PUBLIC',
                    source.description, 'entity', NULL, NULL,
                    source.confidence, NULL,
                    source.canonical_id, source.entity_type, source.entity_name, source.description,
                    'public', 'primary', 'ontology', NULL,
                    source.created_at, source.updated_at
                )
            """)
            count = self.spark.sql(
                f"SELECT COUNT(*) as cnt FROM {nodes_table} WHERE node_type = 'entity'"
            ).collect()[0].cnt
            logger.info("Entity concept nodes in graph: %d", count)
            return count
        except Exception as e:
            logger.warning("Could not sync entity nodes to graph: %s", e)
            return 0

    def _enrich_table_nodes_with_ontology(self) -> int:
        """Backfill ontology_id/ontology_type on table-type graph nodes from primary entities.

        Sets ontology_id to the canonical concept node ID so it matches the
        entity node's id in graph_nodes (enabling direct lookup).
        """
        nodes_table = f"{self.config.catalog_name}.{self.config.schema_name}.{self.config.nodes_table}"
        ent_table = self.config.fully_qualified_entities
        canonical_id = self.CANONICAL_ID_SQL
        try:
            result = self.spark.sql(f"""
                MERGE INTO {nodes_table} AS target
                USING (
                    SELECT table_name, canonical_id, entity_type FROM (
                        SELECT table_name, canonical_id, entity_type,
                               ROW_NUMBER() OVER (PARTITION BY table_name ORDER BY confidence DESC) AS rn
                        FROM (
                            SELECT EXPLODE(source_tables) AS table_name,
                                   {canonical_id} AS canonical_id,
                                   entity_type, confidence
                            FROM {ent_table}
                            WHERE COALESCE(entity_role, 'primary') = 'primary'
                              AND source_tables IS NOT NULL AND SIZE(source_tables) > 0
                        )
                    ) WHERE rn = 1
                ) AS source
                ON target.id = source.table_name AND target.node_type = 'table'
                WHEN MATCHED THEN UPDATE SET
                    target.ontology_id = source.canonical_id,
                    target.ontology_type = source.entity_type
            """)
            count = self.spark.sql(
                f"SELECT COUNT(*) AS cnt FROM {nodes_table} "
                f"WHERE node_type = 'table' AND ontology_type IS NOT NULL"
            ).collect()[0].cnt
            logger.info("Enriched %d table nodes with ontology classifications", count)
            return count
        except Exception as e:
            logger.warning("Could not enrich table nodes with ontology: %s", e)
            return 0

    def _build_same_entity_type_edges(self) -> Optional[DataFrame]:
        """Build same_entity_type edges between tables sharing a primary entity type.

        Returns a DataFrame of edges, or None if none exist.
        """
        ent_table = self.config.fully_qualified_entities
        try:
            # Require the SAME ontology_bundle on both sides. Without this guard, two
            # DISCONNECTED datasets classified under different bundles that happen to share
            # a type name (e.g. "Person" under schema_org and under fhir_r4) get linked by a
            # spurious same_entity_type edge -- the "way too many connections" problem. Every
            # other entity-concept edge builder already enforces same-bundle
            # (_build_structural_edges, discover_inter_entity_relationships); this one was
            # missing it. COALESCE so single-bundle / null-bundle deployments still match.
            pairs = self.spark.sql(f"""
                SELECT a.table_name AS src, b.table_name AS dst, a.entity_type,
                       CAST(1.0 AS DOUBLE) AS weight
                FROM (
                    SELECT EXPLODE(source_tables) AS table_name, entity_type,
                           COALESCE(ontology_bundle, '_default') AS ontology_bundle
                    FROM {ent_table}
                    WHERE COALESCE(entity_role, 'primary') = 'primary'
                      AND source_tables IS NOT NULL AND SIZE(source_tables) > 0
                ) a
                JOIN (
                    SELECT EXPLODE(source_tables) AS table_name, entity_type,
                           COALESCE(ontology_bundle, '_default') AS ontology_bundle
                    FROM {ent_table}
                    WHERE COALESCE(entity_role, 'primary') = 'primary'
                      AND source_tables IS NOT NULL AND SIZE(source_tables) > 0
                ) b
                ON a.entity_type = b.entity_type
                   AND a.ontology_bundle = b.ontology_bundle
                   AND a.table_name < b.table_name
            """)
            count = pairs.count()
            if count == 0:
                logger.info("No same_entity_type edges to build")
                return None

            edge_df = pairs.select(
                F.col("src"), F.col("dst"),
                F.lit("same_entity_type").alias("relationship"),
                F.col("weight"),
                F.concat_ws("::", F.col("src"), F.col("dst"), F.lit("same_entity_type")).alias("edge_id"),
                F.lit("same_entity_type").alias("edge_type"),
                F.lit("undirected").alias("direction"),
                F.col("entity_type").alias("ontology_rel"),
                F.lit("ontology").alias("source_system"),
                F.lit("candidate").alias("status"),
                F.current_timestamp().alias("created_at"),
                F.current_timestamp().alias("updated_at"),
            )
            logger.info("Built %d same_entity_type edges", count)
            return edge_df
        except Exception as e:
            logger.warning("Could not build same_entity_type edges: %s", e)
            return None

    # _clear_ontology_edges removed — stale edges are now swept by merge_edges()

    def _build_structural_edges(self) -> Optional[DataFrame]:
        """Build instance_of, has_property, and named relationship edge DataFrames.

        Returns a single unioned DataFrame of all structural ontology edges,
        or None if no edges could be built.
        """
        dfs = []

        def _add_edge_columns(df, rel: str, etype: str, ont_rel: str = None):
            return df.select(
                F.col("src"), F.col("dst"),
                F.lit(rel).alias("relationship"),
                F.col("weight") if "weight" in df.columns else F.lit(1.0).alias("weight"),
                F.concat_ws("::", F.col("src"), F.col("dst"), F.lit(rel)).alias("edge_id"),
                F.lit(etype).alias("edge_type"),
                F.lit("out").alias("direction"),
                F.lit(ont_rel).alias("ontology_rel"),
                F.lit("ontology").alias("source_system"),
                F.lit("candidate").alias("status"),
                F.current_timestamp().alias("created_at"),
                F.current_timestamp().alias("updated_at"),
            )

        canonical_id = self.CANONICAL_ID_SQL
        ent_table = self.config.fully_qualified_entities

        try:
            table_entities = self.spark.sql(f"""
                SELECT DISTINCT
                    tbl AS table_name,
                    {canonical_id} AS canonical_dst
                FROM {ent_table}
                LATERAL VIEW EXPLODE(source_tables) AS tbl
                WHERE source_tables IS NOT NULL AND SIZE(source_tables) > 0
                  AND COALESCE(entity_role, 'primary') = 'primary'
                  -- Abstain floor applies only to auto-discovered, unvalidated
                  -- primaries. Human-locked (auto_discovered=FALSE) and validated
                  -- entities always keep their instance_of edge regardless of score.
                  AND (
                        COALESCE(validated, FALSE) = TRUE
                        OR COALESCE(auto_discovered, TRUE) = FALSE
                        OR (COALESCE(confidence, 1.0) >= {self._PRIMARY_CONFIDENCE_FLOOR}
                            AND COALESCE(attributes['needs_human_review'], 'false') <> 'true')
                      )
            """)
            if table_entities.count() > 0:
                raw = table_entities.select(
                    F.col("table_name").alias("src"),
                    F.col("canonical_dst").alias("dst"),
                    F.lit(1.0).alias("weight"),
                )
                dfs.append(_add_edge_columns(raw, "instance_of", "instance_of"))
        except Exception as e:
            logger.warning("Could not build instance_of edges: %s", e)

        try:
            cp_table = self.config.fully_qualified_column_properties
            raw = self.spark.sql(f"""
                SELECT DISTINCT
                    CONCAT('entity::', COALESCE(e.ontology_bundle, '_default'), '::', cp.owning_entity_type) AS src,
                    CONCAT(cp.table_name, '.', cp.column_name) AS dst,
                    CAST(1.0 AS DOUBLE) AS weight
                FROM {cp_table} cp
                JOIN {ent_table} e ON cp.owning_entity_id = e.entity_id
            """)
            if raw.count() > 0:
                dfs.append(_add_edge_columns(raw, "has_property", "has_property"))
        except Exception as e:
            logger.warning("Could not build has_property edges: %s", e)

        try:
            rels_table = self.config.fully_qualified_relationships
            raw = self.spark.sql(f"""
                SELECT DISTINCT
                    CONCAT('entity::', COALESCE(se.ontology_bundle, '_default'), '::', r.src_entity_type) AS src,
                    CONCAT('entity::', COALESCE(de.ontology_bundle, '_default'), '::', r.dst_entity_type) AS dst,
                    r.relationship_name AS rel_name,
                    r.confidence AS weight,
                    r.label AS rel_label,
                    r.facet AS rel_facet
                FROM {rels_table} r
                JOIN (
                    SELECT DISTINCT entity_type, COALESCE(ontology_bundle, '_default') AS ontology_bundle
                    FROM {ent_table}
                ) se ON se.entity_type = r.src_entity_type
                JOIN (
                    SELECT DISTINCT entity_type, COALESCE(ontology_bundle, '_default') AS ontology_bundle
                    FROM {ent_table}
                ) de ON de.entity_type = r.dst_entity_type
                -- Same-bundle resolver: build an entity-concept edge only when src and
                -- dst resolve within the SAME bundle. A bare entity_type (e.g. 'Organization')
                -- can exist in multiple coexisting bundles; without this an edge would fan
                -- out across bundles (fhir::Patient -> schema_org::Organization). Compares the
                -- two coalesced bundle values (NOT a current-bundle filter, which would drop a
                -- coexisting live bundle's own within-bundle edges).
                WHERE se.ontology_bundle = de.ontology_bundle
                  AND r.src_entity_type != r.dst_entity_type
                  AND r.source != 'configured'
                  AND r.relationship_name NOT IN (
                    'instance_of', 'type_of', 'subclass_of', 'superclass_of',
                    'is_a', 'about', 'subjectOf',
                    -- categorized_as/category_of have a dedicated bundle-scoped builder
                    -- (_build_category_edges); excluding them here stops stale rows in
                    -- ontology_relationships from being re-emitted as graph edges (the
                    -- categorized_as regression). NOT the full _INFER_BLOCKLIST: bundle
                    -- YAMLs legitimately define contains/part_of/member_of, which only this
                    -- function turns into edges, so those must keep flowing through.
                    'categorized_as', 'category_of'
                  )
            """)
            if raw.count() > 0:
                ref_edges = raw.select(
                    F.col("src"), F.col("dst"),
                    F.col("rel_name").alias("relationship"),
                    F.col("weight"),
                    F.concat_ws("::", F.col("src"), F.col("dst"), F.col("rel_name")).alias("edge_id"),
                    F.col("rel_name").alias("edge_type"),
                    F.lit("out").alias("direction"),
                    F.col("rel_name").alias("ontology_rel"),
                    F.lit("ontology").alias("source_system"),
                    F.lit("candidate").alias("status"),
                    F.col("rel_label").alias("edge_label"),
                    F.col("rel_facet").alias("edge_facet"),
                    F.current_timestamp().alias("created_at"),
                    F.current_timestamp().alias("updated_at"),
                )
                dfs.append(ref_edges)
        except Exception as e:
            logger.warning("Could not build ontology relationship edges: %s", e)

        if not dfs:
            return None
        from functools import reduce
        combined = reduce(lambda a, b: a.unionByName(b, allowMissingColumns=True), dfs)
        combined = combined.dropDuplicates(["edge_id"])
        return combined

    def validate_ontology_completeness(self) -> Dict[str, Any]:
        """Compare discovered entity types against the bundle's definitions.

        Missing types are expected -- not all bundle entity types will have
        matching tables in the data.  This is informational, not an error.
        """
        defined_types = {e.name for e in self.discoverer.entity_definitions if e.name != "DataTable"}
        try:
            discovered = self.spark.sql(
                f"SELECT DISTINCT entity_type FROM {self.config.fully_qualified_entities}"
            ).collect()
            discovered_types = {r.entity_type for r in discovered}
        except Exception:
            discovered_types = set()

        missing = defined_types - discovered_types
        extra = discovered_types - defined_types

        # Count per type
        try:
            counts_rows = self.spark.sql(
                f"SELECT entity_type, COUNT(*) as cnt FROM {self.config.fully_qualified_entities} "
                f"GROUP BY entity_type ORDER BY cnt DESC"
            ).collect()
            counts = {r.entity_type: r.cnt for r in counts_rows}
        except Exception:
            counts = {}

        total = sum(counts.values())
        over_represented = [
            t for t, c in counts.items() if total > 0 and c / total > 0.4
        ]

        # Low confidence entities
        try:
            low_conf = self.spark.sql(
                f"SELECT COUNT(*) AS n FROM {self.config.fully_qualified_entities} WHERE confidence < 0.5"
            ).collect()[0].n
        except Exception:
            low_conf = 0

        if missing:
            logger.warning(f"Ontology completeness: {len(missing)} defined entity types not discovered: {missing}")
        if over_represented:
            logger.warning(f"Ontology completeness: over-represented types (>40%%): {over_represented}")
        if low_conf > 0:
            logger.info(f"Ontology completeness: {low_conf} entities with confidence < 0.5")

        result = {
            "defined_types": len(defined_types),
            "discovered_types": len(discovered_types),
            "missing_types": sorted(missing),
            "extra_types": sorted(extra),
            "over_represented": over_represented,
            "low_confidence_count": low_conf,
        }
        logger.info(f"Ontology completeness: {result['discovered_types']}/{result['defined_types']} types found")
        return result

    # ------------------------------------------------------------------
    # Phase 2: New classification steps for the redesigned ontology model
    # ------------------------------------------------------------------

    def classify_entity_roles(self, table_names=None) -> int:
        """Mark each entity as 'primary' or 'referenced' per table.

        For each source table, the highest-confidence table-granularity entity
        becomes 'primary'. All column-granularity entities are 'referenced'.
        If no table-granularity entity exists, promote the highest-confidence
        column entity to primary. *table_names* scopes the recomputation.
        """
        return _classify_entity_roles_sql(
            self.spark, self.config.fully_qualified_entities, table_names=table_names
        )

    def _deduplicate_primary_entities(self, table_names=None) -> int:
        """Ensure each source table has at most one primary entity.

        When multiple entities share entity_role='primary' for the same
        source_tables entry, keep only the highest-confidence one and
        demote the rest to 'referenced'. Human-created entities
        (auto_discovered=FALSE) always win the ranking and are never
        demoted, since those represent explicit steward overrides. *table_names*
        scopes the deduplication.
        """
        return _deduplicate_primary_entities_sql(
            self.spark, self.config.fully_qualified_entities, table_names=table_names
        )

    def _flag_low_confidence_primaries(self, table_names=None) -> int:
        """Flag below-floor primary entities as needing human review.

        Sets attributes['needs_human_review']='true' on primary entities whose
        confidence is below _PRIMARY_CONFIDENCE_FLOOR. _build_structural_edges
        then suppresses their instance_of edge. The map_filter drops any existing
        key before re-adding it to avoid map_concat duplicate-key errors, and the
        WHERE guard makes the UPDATE a no-op once flags are set (idempotent).
        *table_names* scopes the flagging.
        """
        return _flag_low_confidence_primaries_sql(
            self.spark, self.config.fully_qualified_entities,
            table_names=table_names, primary_floor=self._PRIMARY_CONFIDENCE_FLOOR,
        )

    def _build_bundle_property_index(self, entity_type: str) -> Dict[str, Tuple[str, str, Optional[str], Optional[Any]]]:
        """Build column_name_lower -> (role, property_name, edge, target_entity) from bundle properties."""
        edef = self.discoverer._entity_def_map.get(entity_type)
        if not edef or not edef.properties:
            return {}
        index: Dict[str, Tuple[str, str, Optional[str], Optional[Any]]] = {}
        for prop in edef.properties:
            for attr in prop.typical_attributes:
                index[attr.lower()] = (prop.role, prop.name, prop.edge, prop.target_entity)
        return index

    def _heuristic_classify(
        self,
        col_lower: str,
        dtype: str,
        is_pk_column: bool,
        linked_entity: Optional[str],
        cls_type: str,
        table_name: str = "",
        known_table_stems: Optional[frozenset] = None,
    ) -> Tuple[str, str, float]:
        """Heuristic fallback classification. Returns (role, discovery_method, confidence)."""
        _bundle_geo = getattr(self.discoverer, "_bundle_geo_patterns", frozenset())
        _GEO_PATTERNS = _bundle_geo or _GEO_PATTERNS_CANONICAL
        _HIERARCHY_PATTERNS = frozenset({
            "year", "quarter", "month", "week", "day", "fiscal_year", "fiscal_quarter",
            "product_category", "product_subcategory", "category", "subcategory",
            "department", "division",
        })
        _TEXT_PATTERNS = _LABEL_PATTERNS_CANONICAL
        _SYSTEM_PATTERNS = _AUDIT_PATTERNS_CANONICAL

        tbl_raw = table_name.rsplit(".", 1)[-1].lower() if table_name else ""

        _TABLE_PREFIXES = ("dim_", "fct_", "fact_", "stg_", "raw_", "ref_")

        def _is_table_pk(col: str, tbl: str) -> bool:
            if col == "id":
                return True
            m = re.match(r'^(.+?)_(id|key)$', col)
            if not m or not tbl:
                return False
            stem = m.group(1)
            stripped = tbl
            for pfx in _TABLE_PREFIXES:
                if tbl.startswith(pfx):
                    stripped = tbl[len(pfx):]
                    break
            return (tbl.startswith(stem) or stem.startswith(tbl.rstrip("s"))
                    or stripped.startswith(stem) or stem.startswith(stripped.rstrip("s")))

        is_self_pk = _is_table_pk(col_lower, tbl_raw)

        if linked_entity and not is_self_pk:
            if col_lower.endswith(("_id", "_key", "_ref")) or col_lower == "id":
                return "object_property", "heuristic_strong", 0.80
        if is_pk_column or is_self_pk:
            return "primary_key", "heuristic_strong", 0.85
        if re.search(r'_(id|key)$', col_lower):
            if _is_table_pk(col_lower, tbl_raw):
                return "primary_key", "heuristic_strong", 0.80
            stem = re.sub(r'_(id|key)$', '', col_lower)
            if known_table_stems and not any(
                ts.startswith(stem) or stem.startswith(ts) for ts in known_table_stems
            ):
                return "business_key", "heuristic_weak", 0.55
            return "object_property", "heuristic_weak", 0.55
        if col_lower in _BUSINESS_KEY_PATTERNS_CANONICAL:
            return "business_key", "heuristic_strong", 0.80
        if dtype == "BOOLEAN" or col_lower.startswith(("is_", "has_", "flag_")):
            return "dimension", "heuristic_weak", 0.60
        _is_geo = col_lower in _GEO_PATTERNS or col_lower.startswith("geo_")
        _is_code = re.search(r'_(code|icd|cpt|loinc|ndc|drg)$', col_lower) or col_lower.endswith("_code")
        if _bundle_geo:
            if _is_geo:
                return "geographic", "heuristic_strong", 0.75
            if _is_code:
                return "dimension", "heuristic_strong", 0.75
        else:
            if _is_code:
                return "dimension", "heuristic_strong", 0.75
            if _is_geo:
                return "geographic", "heuristic_strong", 0.75
        if col_lower in _SYSTEM_PATTERNS or col_lower.startswith("etl_"):
            return "audit", "heuristic_strong", 0.80
        if dtype in ("DATE", "TIMESTAMP", "TIMESTAMP_NTZ"):
            return "temporal", "heuristic_strong", 0.80
        if col_lower in _HIERARCHY_PATTERNS:
            return "dimension", "heuristic_weak", 0.60
        _LABEL_SUFFIXES = ("_name", "_text", "_notes", "_description", "_summary")
        if dtype == "STRING" and (col_lower in _TEXT_PATTERNS
                or any(col_lower.endswith(s) for s in _LABEL_SUFFIXES)):
            return "label", "heuristic_weak", 0.55
        if dtype in ("INT", "INTEGER", "BIGINT", "LONG", "DOUBLE", "FLOAT", "DECIMAL"):
            if re.search(r'_(day|days|hour|hours|minute|minutes|month|months|year|years|weeks?)$', col_lower):
                return "temporal", "heuristic_weak", 0.60
            if re.search(r'_(score|grade|rating|rank|level|tier|version|revision)$', col_lower):
                return "dimension", "heuristic_weak", 0.60
            if (re.search(r'_(count|number|num|qty)$', col_lower)
                    and not re.search(r'(amount|total|sum|revenue|cost|price|fee|charge)', col_lower)):
                return "dimension", "heuristic_weak", 0.55
            return "measure", "heuristic_weak", 0.60
        return "dimension", "fallback", 0.40

    def classify_column_properties(self) -> int:
        """Populate ontology_column_properties for every column in tables with a primary entity.

        Uses a two-tier classification strategy:
        1. **Bundle match**: check column name against entity's formal property
           definitions (typical_attributes). High confidence (0.95).
        2. **Heuristic fallback**: regex/type-based cascade for unmatched columns.
           Variable confidence (0.40-0.85).
        """
        ent_table = self.config.fully_qualified_entities
        col_kb = self.config.fully_qualified_column_kb
        cp_table = self.config.fully_qualified_column_properties

        self.create_column_properties_table()

        tn_clause = table_filter_sql(self.config.table_names or [], column="get(source_tables, 0)")
        try:
            primary_ents = self.spark.sql(f"""
                SELECT entity_id, entity_type, source_tables, source_columns
                FROM {ent_table}
                WHERE entity_role = 'primary'
                {tn_clause}
            """).collect()
        except Exception as e:
            logger.warning("classify_column_properties: cannot read primary entities: %s", e)
            return 0

        table_primary: Dict[str, Dict] = {}
        for r in primary_ents:
            for t in r.source_tables or []:
                table_primary[t] = {
                    "entity_id": r.entity_id,
                    "entity_type": r.entity_type,
                    "source_columns": set(r.source_columns or []),
                }

        try:
            ref_ents = self.spark.sql(f"""
                SELECT entity_type, source_tables, source_columns, confidence
                FROM {ent_table}
                WHERE entity_role = 'referenced' AND source_columns IS NOT NULL AND SIZE(source_columns) > 0
                {tn_clause}
            """).collect()
        except Exception:
            ref_ents = []

        col_entity_map: Dict[tuple, tuple] = {}
        for r in ref_ents:
            conf = r.confidence or 0.0
            for t in r.source_tables or []:
                for c in r.source_columns or []:
                    existing = col_entity_map.get((t, c))
                    if not existing or conf > existing[1]:
                        col_entity_map[(t, c)] = (r.entity_type, conf)

        if not table_primary:
            logger.info("classify_column_properties: no primary entities found")
            return 0

        # Pre-build bundle property indices per entity type
        bundle_indices: Dict[str, Dict] = {}
        for pe_info in table_primary.values():
            etype = pe_info["entity_type"]
            if etype not in bundle_indices:
                bundle_indices[etype] = self._build_bundle_property_index(etype)

        # Build known table stems for orphan-id heuristic
        _known_table_stems = frozenset(
            t.rsplit(".", 1)[-1].lower().rstrip("s") for t in table_primary
        )

        # Group tables by entity type so we can chunk the collect() and avoid OOM
        etype_to_tables: Dict[str, List[str]] = {}
        for t, info in table_primary.items():
            etype_to_tables.setdefault(info["entity_type"], []).append(t)

        now = datetime.utcnow()
        props = []
        bundle_match_count = 0

        for etype, etype_tables in etype_to_tables.items():
            tbl_list = ",".join(f"'{t}'" for t in etype_tables)
            try:
                columns_df = self.spark.sql(f"""
                    SELECT table_name, column_name, data_type,
                           classification_type
                    FROM {col_kb}
                    WHERE table_name IN ({tbl_list})
                """)
                columns = list(columns_df.toLocalIterator())
            except Exception as e:
                raise RuntimeError(
                    f"classify_column_properties: cannot read column KB for entity type "
                    f"'{etype}' ({len(etype_tables)} tables). This would silently omit "
                    f"those tables from ontology_column_properties."
                ) from e
            logger.info(
                "classify_column_properties: processing %d columns for entity type %s (%d tables)",
                len(columns), etype, len(etype_tables),
            )
            for c in columns:
                tbl = c.table_name
                col = c.column_name
                dtype = (c.data_type or "").upper()
                pe = table_primary.get(tbl)
                if not pe:
                    continue

                _linked_entry = col_entity_map.get((tbl, col))
                linked = _linked_entry[0] if _linked_entry else None
                linked_conf = _linked_entry[1] if _linked_entry else 0.0
                col_lower = col.lower()
                cls_type = (getattr(c, "classification_type", None) or "").upper()
                is_sensitive = cls_type in ("PII", "PHI", "PCI")
                is_surrogate_key = bool(
                    re.search(r'_(sk|surrogate)$', col_lower)
                    or (col_lower.endswith("_hash") and re.search(r'_(id|key)$', col_lower))
                )
                is_semi_structured = dtype in ("MAP", "STRUCT", "ARRAY", "VARIANT")

                bindex = bundle_indices.get(pe["entity_type"], {})
                bundle_hit = bindex.get(col_lower)

                if bundle_hit:
                    role, prop_name, edge, target_entity = bundle_hit
                    linked_from_bundle = target_entity
                    if isinstance(linked_from_bundle, list):
                        linked_from_bundle = linked_from_bundle[0] if linked_from_bundle else None
                    confidence = 0.95
                    discovery_method = "bundle_match"
                    if role == "object_property" and linked_from_bundle:
                        linked = str(linked_from_bundle)
                    bundle_match_count += 1
                else:
                    tbl_short = tbl.rsplit(".", 1)[-1].lower()
                    pk_match = re.match(r'^(.+?)_(id|key)$', col_lower)
                    is_pk = col_lower == "id" or (
                        bool(pk_match) and tbl_short and (
                            tbl_short.startswith(pk_match.group(1))
                            or pk_match.group(1).startswith(tbl_short.rstrip("s"))
                        )
                    )
                    gated_linked = linked if linked_conf >= 0.6 else None
                    role, discovery_method, confidence = self._heuristic_classify(
                        col_lower, dtype, is_pk, gated_linked, cls_type,
                        table_name=tbl, known_table_stems=_known_table_stems,
                    )
                    prop_name = col

                # Stable property_id (md5 of table::column) so reruns do not churn row ids keyed on property_id.
                props.append({
                    "property_id": hashlib.md5(f"{tbl}::{col}".encode()).hexdigest(),
                    "table_name": tbl,
                    "column_name": col,
                    "property_name": prop_name,
                    "property_role": role,
                    "owning_entity_id": pe["entity_id"],
                    "owning_entity_type": pe["entity_type"],
                    "linked_entity_type": linked,
                    "confidence": confidence,
                    "auto_discovered": True,
                    "discovery_method": discovery_method,
                    "is_sensitive": is_sensitive,
                    "is_surrogate_key": is_surrogate_key,
                    "is_semi_structured": is_semi_structured,
                    "bundle_version": self._get_bundle_version(),
                    "discovery_timestamp": now,
                    "created_at": now,
                    "updated_at": now,
                })

        if not props:
            return 0

        df = self.spark.createDataFrame(props)
        df.createOrReplaceTempView("_staged_col_props")
        # Scoped MERGE (replaces overwrite): upsert in-scope columns; preserve manual/non-auto rows via WHEN MATCHED predicate.
        self.spark.sql(f"""
            MERGE INTO {cp_table} AS target
            USING _staged_col_props AS source
            ON target.table_name = source.table_name
               AND target.column_name = source.column_name
            WHEN MATCHED AND target.auto_discovered = TRUE THEN UPDATE SET
                target.property_id = source.property_id,
                target.property_name = source.property_name,
                target.property_role = source.property_role,
                target.owning_entity_id = source.owning_entity_id,
                target.owning_entity_type = source.owning_entity_type,
                target.linked_entity_type = source.linked_entity_type,
                target.confidence = source.confidence,
                target.discovery_method = source.discovery_method,
                target.is_sensitive = source.is_sensitive,
                target.is_surrogate_key = source.is_surrogate_key,
                target.is_semi_structured = source.is_semi_structured,
                target.bundle_version = source.bundle_version,
                target.discovery_timestamp = source.discovery_timestamp,
                target.updated_at = source.updated_at
            WHEN NOT MATCHED THEN INSERT *
        """)
        logger.info(
            "classify_column_properties: wrote %d properties (%d bundle_match, %d heuristic/fallback)",
            len(props), bundle_match_count, len(props) - bundle_match_count,
        )
        return len(props)

    def merge_owl_declared_fks(self, sweep_stale_entities: bool = False) -> int:
        """Resolve OWL bundle declared_constraints to extended_table_metadata FK/PK maps."""
        from datetime import datetime

        from pyspark.sql.types import ArrayType, MapType, StringType, StructField, StructType, TimestampType

        from dbxmetagen.extended_metadata import ExtendedMetadataBuilder, ExtendedMetadataConfig
        from dbxmetagen.owl_constraints import (
            dedupe_string_map,
            merge_owl_foreign_keys,
            resolve_declared_constraints_to_tables,
        )
        from dbxmetagen.table_filter import table_filter_sql

        constraints = self.ontology_config.get("declared_constraints") or {}
        sweep_owl_fks = bool(sweep_stale_entities and not self.config.incremental)

        ent_table = self.config.fully_qualified_entities
        col_kb = self.config.fully_qualified_column_kb
        ext_table = f"{self.config.catalog_name}.{self.config.schema_name}.extended_table_metadata"
        tn_clause = table_filter_sql(self.config.table_names or [], column="get(source_tables, 0)")

        try:
            ent_rows = self.spark.sql(f"""
                SELECT entity_type, source_tables
                FROM {ent_table}
                WHERE entity_role = 'primary'
                  AND source_tables IS NOT NULL
                  AND SIZE(source_tables) > 0
                {tn_clause}
            """).collect()
        except Exception as e:
            logger.warning("merge_owl_declared_fks: cannot read entities: %s", e)
            return 0

        entity_tables: Dict[str, List[str]] = {}
        all_tables: set = set()
        for r in ent_rows:
            tables = list(r.source_tables or [])
            if tables:
                merged = list(dict.fromkeys((entity_tables.get(r.entity_type) or []) + tables))
                entity_tables[r.entity_type] = merged
                all_tables.update(tables)

        if not constraints:
            if entity_tables:
                logger.warning(
                    "merge_owl_declared_fks: bundle has no declared_constraints but %d "
                    "primary entity type(s) map to tables — verify ontology_bundle matches "
                    "the imported OWL bundle (e.g. Volume YAML name)",
                    len(entity_tables),
                )
            return 0

        if not all_tables:
            logger.info("merge_owl_declared_fks: no primary entity tables to resolve")
            return 0

        tbl_in = ",".join(f"'{t}'" for t in sorted(all_tables))
        try:
            col_rows = self.spark.sql(f"""
                SELECT table_name, column_name
                FROM {col_kb}
                WHERE table_name IN ({tbl_in})
            """).collect()
        except Exception as e:
            logger.warning("merge_owl_declared_fks: cannot read column KB: %s", e)
            return 0

        table_columns: Dict[str, Set[str]] = {}
        for r in col_rows:
            table_columns.setdefault(r.table_name, set()).add(r.column_name)

        resolved = resolve_declared_constraints_to_tables(
            constraints, entity_tables, table_columns,
        )
        if not resolved:
            logger.info("merge_owl_declared_fks: no constraints resolved to tables")
            return 0

        em_cfg = ExtendedMetadataConfig(
            catalog_name=self.config.catalog_name,
            schema_name=self.config.schema_name,
        )
        ExtendedMetadataBuilder(self.spark, em_cfg).create_target_table()

        now = datetime.utcnow()
        staged_rows = []
        fk_count = 0
        for tbl, (pks, fks) in resolved.items():
            if not pks and not fks:
                continue
            exist_pks: List[str] = []
            exist_fks: Dict[str, str] = {}
            try:
                exist = self.spark.sql(f"""
                    SELECT primary_key_columns, foreign_keys
                    FROM {ext_table}
                    WHERE table_name = '{tbl.replace("'", "''")}'
                """).collect()
                if exist:
                    exist_pks = list(exist[0].primary_key_columns or [])
                    exist_fks = dedupe_string_map(
                        dict(exist[0].foreign_keys or {}),
                        context=f"existing extended_table_metadata {tbl}",
                    )
            except Exception:
                pass

            merged_pks = exist_pks if exist_pks else pks
            merged_fks, added = merge_owl_foreign_keys(
                exist_fks,
                fks,
                constraints=constraints,
                entity_tables=entity_tables,
                table_columns=table_columns,
                table_fqn=tbl,
                table_pk_cols=merged_pks or pks,
                sweep_owl_fks=sweep_owl_fks,
            )
            fk_count += added

            merged_fks = dedupe_string_map(
                merged_fks, context=f"staged extended_table_metadata {tbl}",
            )
            staged_rows.append((tbl, merged_pks, merged_fks, now))

        if not staged_rows:
            return 0

        schema = StructType([
            StructField("table_name", StringType(), False),
            StructField("primary_key_columns", ArrayType(StringType()), True),
            StructField("foreign_keys", MapType(StringType(), StringType()), True),
            StructField("updated_at", TimestampType(), True),
        ])
        staged_df = self.spark.createDataFrame(staged_rows, schema)
        staged_df.createOrReplaceTempView("_owl_declared_fk_staged")

        self.spark.sql(f"""
            MERGE INTO {ext_table} AS target
            USING _owl_declared_fk_staged AS source
            ON target.table_name = source.table_name
            WHEN MATCHED THEN UPDATE SET
                target.primary_key_columns = CASE
                    WHEN SIZE(COALESCE(target.primary_key_columns, ARRAY())) > 0
                    THEN target.primary_key_columns
                    ELSE source.primary_key_columns
                END,
                target.foreign_keys = source.foreign_keys,
                target.updated_at = source.updated_at
            WHEN NOT MATCHED THEN INSERT (
                table_name, primary_key_columns, foreign_keys, updated_at
            ) VALUES (
                source.table_name, source.primary_key_columns, source.foreign_keys, source.updated_at
            )
        """)
        logger.info(
            "merge_owl_declared_fks: merged %d OWL FK entries across %d tables",
            fk_count, len(staged_rows),
        )
        return fk_count

    def _resolve_edge_name(self, src_type: str, dst_type: str, column_name: Optional[str] = None) -> str:
        """Resolve the best edge name for a (src, dst) entity pair using edge catalog.

        Priority:
        1. Bundle property definition (if column_name matches a typed object_property)
        2. Entity relationship config (legacy relationships block)
        3. Edge catalog domain/range match
        4. Fallback to 'references'
        """
        catalog = self.discoverer._edge_catalog
        edef = self.discoverer._entity_def_map.get(src_type)

        # Check bundle property definitions for column-level edge name
        if edef and column_name:
            col_lower = (column_name or "").lower()
            for prop in edef.properties:
                if prop.kind == "object_property" and prop.edge:
                    if col_lower in [a.lower() for a in prop.typical_attributes]:
                        entry = catalog.get(prop.edge)
                        if entry and entry.validate_edge(src_type, dst_type):
                            return prop.edge

        # Check legacy relationships block
        if edef:
            for rn, ri in edef.relationships.items():
                if ri.get("target") == dst_type:
                    if rn not in OntologyLoader._INFER_BLOCKLIST:
                        return rn

        # Search edge catalog by domain/range match (prefer same-bundle entries)
        _bundle = getattr(getattr(self, "config", None), "ontology_bundle", None)
        match = catalog.find_edge(src_type, dst_type, bundle_name=_bundle)
        if match and match.name not in OntologyLoader._INFER_BLOCKLIST:
            return match.name

        return "references"

    @staticmethod
    def _resolve_reference_target(
        edge_name: str, discovered_types_lower: Dict[str, str],
    ) -> Optional[str]:
        """Resolve a Reference-range edge to a concrete entity type via property name suffix.

        FHIR properties are named after their target (e.g. ``managingOrganization``
        -> ``Organization``).  Returns the original-case entity type if exactly one
        discovered type matches as a case-insensitive suffix, else ``None``.
        """
        local = edge_name.rsplit(".", 1)[-1].lower()
        matches = [
            orig for low, orig in discovered_types_lower.items()
            if local.endswith(low)
        ]
        return matches[0] if len(matches) == 1 else None

    def emit_bundle_edges(self) -> int:
        """Emit edges directly from the ontology bundle's tier-1 edge definitions.

        Intentionally discovery-gated: only emits edges where both domain and
        range entity types were discovered in actual data.  This prevents
        dangling references in the knowledge graph.

        For each tier-1 edge where both domain and range entity types have been
        discovered in ontology_entities, writes a relationship to
        ontology_relationships with source='bundle'.

        Handles three resolution strategies for the range:
        1. Direct match -- range is a discovered entity type
        2. Multi-range -- any value in the tier-2 ``ranges`` list is discovered
        3. Reference resolution -- for ``range=="Reference"``, resolve the target
           from the property name suffix (FHIR convention)
        """
        disc = self.discoverer
        loader = disc._get_index_loader() if hasattr(disc, "_get_index_loader") else None
        has_tiers = loader and loader.has_tier_indexes

        ent_table = self.config.fully_qualified_entities
        rels_table = self.config.fully_qualified_relationships
        self.create_relationships_table()

        try:
            discovered_rows = self.spark.sql(f"""
                SELECT DISTINCT entity_type FROM {ent_table}
                WHERE confidence >= 0.4 AND entity_type IS NOT NULL
                  AND entity_role = 'primary'
            """).collect()
        except Exception as e:
            logger.warning("emit_bundle_edges: cannot read entities: %s", e)
            return 0

        discovered_types = {r.entity_type for r in discovered_rows}
        if not discovered_types:
            return 0

        discovered_lower = {t.lower(): t for t in discovered_types}

        now = datetime.utcnow()
        rels: List[Dict] = []
        seen: set = set()
        ref_resolved = 0

        if has_tiers:
            # Tier-based path: iterate tier-1 edges with multi-range and
            # Reference resolution from tier-2
            edges_t1 = loader.get_edges_tier1() or []
            edges_t2_raw = loader._load("edges_tier2.yaml") or {}
            edges_t2_ranges: Dict[str, List[str]] = {}
            for ename, edata in edges_t2_raw.items():
                if isinstance(edata, dict) and edata.get("ranges"):
                    edges_t2_ranges[ename] = edata["ranges"]

            for edge in edges_t1:
                domain = edge.get("domain")
                rng = edge.get("range")
                name = edge.get("name")
                if not domain or not name:
                    continue
                if domain not in discovered_types:
                    continue

                resolved_range = None
                if rng and rng in discovered_types:
                    resolved_range = rng
                elif rng and rng not in discovered_types:
                    for alt in edges_t2_ranges.get(name, []):
                        if alt in discovered_types:
                            resolved_range = alt
                            break
                    if not resolved_range and rng == "Reference":
                        resolved_range = self._resolve_reference_target(name, discovered_lower)
                        if resolved_range:
                            ref_resolved += 1

                if not resolved_range:
                    continue

                key = (domain, resolved_range, name)
                if key in seen:
                    continue
                seen.add(key)
                rels.append({
                    "relationship_id": str(uuid.uuid4()),
                    "src_entity_type": domain,
                    "relationship_name": name,
                    "dst_entity_type": resolved_range,
                    "cardinality": edge.get("cardinality", "unknown"),
                    "evidence_column": None,
                    "evidence_table": None,
                    "source": "bundle",
                    "confidence": 0.8,
                    "label": edge.get("label"),
                    "facet": edge.get("facet"),
                    "sub_property_of": edge.get("sub_property_of"),
                    "ranges": edges_t2_ranges.get(name, []),
                    "source_ontology": edge.get("source_ontology"),
                    "edge_uri": edge.get("uri") or edge.get("edge_uri"),
                    "created_at": now,
                    "updated_at": now,
                })
        else:
            # Root-YAML fallback: derive edges from entity relationship
            # declarations when tier indexes are not available.
            logger.info("emit_bundle_edges: using root YAML relationships (no tier indexes)")
            for edef in disc.entity_definitions:
                if edef.name not in discovered_types:
                    continue
                for rel_name, rel_info in edef.relationships.items():
                    target = rel_info.get("target")
                    if not target or target not in discovered_types:
                        continue
                    key = (edef.name, target, rel_name)
                    if key in seen:
                        continue
                    seen.add(key)
                    rels.append({
                        "relationship_id": str(uuid.uuid4()),
                        "src_entity_type": edef.name,
                        "relationship_name": rel_name,
                        "dst_entity_type": target,
                        "cardinality": rel_info.get("cardinality", "unknown"),
                        "evidence_column": None,
                        "evidence_table": None,
                        "source": "bundle",
                        "confidence": 0.8,
                        "label": None,
                        "facet": None,
                        "sub_property_of": None,
                        "ranges": [],
                        "source_ontology": edef.source_ontology,
                        "edge_uri": None,
                        "created_at": now,
                        "updated_at": now,
                    })

            # Also emit edges from concrete edge_catalog entries (both domain and
            # range constrained to specific entity types). Closes the gap where a
            # bundle declares a relationship in edge_catalog but never mirrors it
            # in any entity's per-entity `relationships:` block. Discovery-gated
            # like the per-entity path; structural/unconstrained entries are
            # skipped (subclass_of is handled by discover_named_relationships, and
            # Any->Any entries carry no (src,dst) signal).
            catalog = getattr(disc, "_edge_catalog", None)
            if catalog is not None:
                def _concrete(v):
                    if v is None or v == "Any":
                        return []
                    return v if isinstance(v, list) else [v]
                for entry in catalog.entries.values():
                    if entry.category == "structural" or entry.is_unconstrained():
                        continue
                    domains = [d for d in _concrete(entry.domain) if d in discovered_types]
                    ranges = [r for r in _concrete(entry.range) if r in discovered_types]
                    for d in domains:
                        for r in ranges:
                            key = (d, r, entry.name)
                            if key in seen:
                                continue
                            seen.add(key)
                            rels.append({
                                "relationship_id": str(uuid.uuid4()),
                                "src_entity_type": d,
                                "relationship_name": entry.name,
                                "dst_entity_type": r,
                                "cardinality": "unknown",
                                "evidence_column": None,
                                "evidence_table": None,
                                "source": "bundle",
                                "confidence": 0.8,
                                "label": None,
                                "facet": None,
                                "sub_property_of": None,
                                "ranges": [],
                                "source_ontology": None,
                                "edge_uri": entry.uri,
                                "created_at": now,
                                "updated_at": now,
                            })

        if not rels:
            logger.info("emit_bundle_edges: no matching entity pairs found in tier-1 edges")
            return 0

        if ref_resolved:
            logger.info("emit_bundle_edges: resolved %d Reference-range edges via name heuristic", ref_resolved)

        _bundle_schema = StructType([
            StructField("relationship_id", StringType()),
            StructField("src_entity_type", StringType()),
            StructField("relationship_name", StringType()),
            StructField("dst_entity_type", StringType()),
            StructField("cardinality", StringType()),
            StructField("evidence_column", StringType(), nullable=True),
            StructField("evidence_table", StringType(), nullable=True),
            StructField("source", StringType()),
            StructField("confidence", DoubleType()),
            StructField("label", StringType(), nullable=True),
            StructField("facet", StringType(), nullable=True),
            StructField("sub_property_of", StringType(), nullable=True),
            StructField("ranges", ArrayType(StringType()), nullable=True),
            StructField("source_ontology", StringType(), nullable=True),
            StructField("edge_uri", StringType(), nullable=True),
            StructField("created_at", TimestampType()),
            StructField("updated_at", TimestampType()),
        ])
        df = self.spark.createDataFrame(rels, schema=_bundle_schema)
        df = df.dropDuplicates(["src_entity_type", "dst_entity_type", "relationship_name"])
        df.createOrReplaceTempView("_bundle_edges_staging")
        # MERGE: Insert bundle-declared relationships into ontology_relationships.
        # Keyed on (src_entity_type, dst_entity_type, relationship_name). Only
        # inserts when NOT MATCHED -- existing rows from prior runs or from
        # discover_named_relationships are never overwritten.
        # WHY: Bundle YAML files declare the canonical relationships for an ontology
        # (e.g., Patient -> has_encounter -> Encounter). These need to exist in the
        # relationships table so the edge builder can emit graph edges. INSERT-only
        # ensures that evidence/confidence from runtime discovery isn't clobbered.
        # TRADEOFFS: INSERT-only means bundle changes (e.g., renaming a relationship)
        # won't update existing rows. A full rebuild (incremental=false) would be
        # needed to pick up bundle edits. The dropDuplicates above prevents the
        # DELTA_MULTIPLE_SOURCE_ROW_MATCHING_TARGET_ROW_IN_MERGE error if the
        # bundle YAML contains duplicate relationship declarations.
        self.spark.sql(f"""
            MERGE INTO {rels_table} AS target
            USING _bundle_edges_staging AS source
            ON target.src_entity_type = source.src_entity_type
               AND target.dst_entity_type = source.dst_entity_type
               AND target.relationship_name = source.relationship_name
            WHEN NOT MATCHED THEN INSERT *
        """)
        self.spark.catalog.dropTempView("_bundle_edges_staging")
        logger.info("emit_bundle_edges: inserted %d bundle-defined edges", len(rels))
        return len(rels)

    def discover_named_relationships(self) -> int:
        """Populate ontology_relationships from FK predictions and column link patterns.

        Uses the edge catalog for named relationship resolution and domain/range validation.
        """
        ent_table = self.config.fully_qualified_entities
        fk_table = f"{self.config.catalog_name}.{self.config.schema_name}.fk_predictions"
        rels_table = self.config.fully_qualified_relationships

        self.create_relationships_table()

        try:
            primary_rows = self.spark.sql(f"""
                SELECT entity_type, EXPLODE(source_tables) AS table_name
                FROM {ent_table}
                WHERE entity_role = 'primary'
            """).collect()
        except Exception as e:
            logger.warning("discover_named_relationships: cannot read entities: %s", e)
            return 0

        table_to_primary: Dict[str, str] = {}
        for r in primary_rows:
            table_to_primary[r.table_name] = r.entity_type
        primary_entity_types = set(table_to_primary.values())

        rels: List[Dict] = []
        seen: set = set()
        now = datetime.utcnow()
        catalog = self.discoverer._edge_catalog
        validation_warnings: List[str] = []

        # From FK predictions
        try:
            fk_rows = self.spark.sql(f"""
                SELECT src_table, dst_table, src_column, dst_column, final_confidence
                FROM {fk_table}
                WHERE final_confidence >= 0.5
                  AND (is_fk IS NULL OR is_fk = TRUE)
            """).collect()
        except Exception:
            fk_rows = []

        for fk in fk_rows:
            src_type = table_to_primary.get(fk.src_table)
            dst_type = table_to_primary.get(fk.dst_table)
            if not src_type or not dst_type or src_type == dst_type:
                continue
            rel_name = self._resolve_edge_name(src_type, dst_type, fk.src_column)
            key = (src_type, dst_type, rel_name)
            if key in seen:
                continue
            seen.add(key)
            valid, msg = catalog.validate(rel_name, src_type, dst_type)
            if not valid and rel_name != "references":
                validation_warnings.append(msg)

            rels.append({
                "relationship_id": str(uuid.uuid4()),
                "src_entity_type": src_type,
                "relationship_name": rel_name,
                "dst_entity_type": dst_type,
                "cardinality": "1:N",
                "evidence_column": fk.src_column,
                "evidence_table": fk.src_table,
                "source": "fk_inferred",
                "confidence": float(fk.final_confidence or 0.5),
                "source_ontology": None,
                "edge_uri": None,
                "created_at": now,
                "updated_at": now,
            })

        # From column_properties with object_property role
        cp_table = self.config.fully_qualified_column_properties
        try:
            link_rows = self.spark.sql(f"""
                SELECT DISTINCT owning_entity_type, linked_entity_type, column_name, table_name
                FROM {cp_table}
                WHERE property_role = 'object_property' AND linked_entity_type IS NOT NULL
            """).collect()
        except Exception:
            link_rows = []

        for lr in link_rows:
            src_type = lr.owning_entity_type
            dst_type = lr.linked_entity_type
            if not src_type or not dst_type or src_type == dst_type:
                continue
            if dst_type not in primary_entity_types:
                continue
            rel_name = self._resolve_edge_name(src_type, dst_type, lr.column_name)
            key = (src_type, dst_type, rel_name)
            if key in seen:
                continue
            seen.add(key)
            valid, msg = catalog.validate(rel_name, src_type, dst_type)
            if not valid and rel_name != "references":
                validation_warnings.append(msg)

            rels.append({
                "relationship_id": str(uuid.uuid4()),
                "src_entity_type": src_type,
                "relationship_name": rel_name,
                "dst_entity_type": dst_type,
                "cardinality": "1:N",
                "evidence_column": lr.column_name,
                "evidence_table": lr.table_name,
                "source": "discovered",
                "confidence": 0.7,
                "source_ontology": None,
                "edge_uri": None,
                "created_at": now,
                "updated_at": now,
            })

        # From config hierarchy (subclass_of)
        for edef in self.discoverer.entity_definitions:
            parent = edef.parent
            if parent:
                key = (edef.name, parent, "subclass_of")
                if key not in seen:
                    seen.add(key)
                    rels.append({
                        "relationship_id": str(uuid.uuid4()),
                        "src_entity_type": edef.name,
                        "relationship_name": "subclass_of",
                        "dst_entity_type": parent,
                        "cardinality": "1:1",
                        "evidence_column": None,
                        "evidence_table": None,
                        "source": "configured",
                        "confidence": 1.0,
                        "source_ontology": None,
                        "edge_uri": None,
                        "created_at": now,
                        "updated_at": now,
                    })

        # Auto-generate inverse edges from EdgeCatalog metadata
        inverse_rels: List[Dict] = []
        for rel in rels:
            rel_name = rel["relationship_name"]
            if rel_name == "subclass_of":
                continue
            inv_name = catalog.get_inverse(rel_name)
            if not inv_name:
                continue
            inv_key = (rel["dst_entity_type"], rel["src_entity_type"], inv_name)
            if inv_key in seen:
                continue
            seen.add(inv_key)
            fwd_card = rel.get("cardinality", "1:N")
            inv_card = "N:1" if fwd_card == "1:N" else ("1:N" if fwd_card == "N:1" else fwd_card)
            inverse_rels.append({
                "relationship_id": str(uuid.uuid4()),
                "src_entity_type": rel["dst_entity_type"],
                "relationship_name": inv_name,
                "dst_entity_type": rel["src_entity_type"],
                "cardinality": inv_card,
                "evidence_column": rel["evidence_column"],
                "evidence_table": rel["evidence_table"],
                "source": "auto_inverse",
                "confidence": rel["confidence"],
                "source_ontology": rel.get("source_ontology"),
                "edge_uri": rel.get("edge_uri"),
                "created_at": now,
                "updated_at": now,
            })
        if inverse_rels:
            rels.extend(inverse_rels)
            logger.info("Auto-generated %d inverse edges", len(inverse_rels))

        if validation_warnings:
            for w in validation_warnings[:10]:
                logger.warning("edge_catalog validation: %s", w)

        if not rels:
            logger.info("discover_named_relationships: no relationships found")
            return 0

        _rels_schema = StructType([
            StructField("relationship_id", StringType()),
            StructField("src_entity_type", StringType()),
            StructField("relationship_name", StringType()),
            StructField("dst_entity_type", StringType()),
            StructField("cardinality", StringType()),
            StructField("evidence_column", StringType(), nullable=True),
            StructField("evidence_table", StringType(), nullable=True),
            StructField("source", StringType()),
            StructField("confidence", DoubleType()),
            StructField("label", StringType(), nullable=True),
            StructField("facet", StringType(), nullable=True),
            StructField("sub_property_of", StringType(), nullable=True),
            StructField("ranges", ArrayType(StringType()), nullable=True),
            StructField("source_ontology", StringType(), nullable=True),
            StructField("edge_uri", StringType(), nullable=True),
            StructField("created_at", TimestampType()),
            StructField("updated_at", TimestampType()),
        ])
        df = self.spark.createDataFrame(rels, schema=_rels_schema)
        df = df.dropDuplicates(["src_entity_type", "dst_entity_type", "relationship_name"])
        df.createOrReplaceTempView("_new_rels")
        # MERGE: Upsert runtime-discovered relationships (from FK predictions, column
        # name patterns, subclass_of hierarchies, and inverse edges) into
        # ontology_relationships. Keyed on (src_entity_type, dst_entity_type,
        # relationship_name). Matched rows get confidence/evidence/source updated;
        # unmatched rows are inserted.
        # WHY: Runtime discovery finds relationships that aren't declared in the
        # bundle YAML -- e.g., FK-based joins or naming conventions like
        # patient_id -> Patient. These supplement the bundle edges.
        # TRADEOFFS: The MERGE key is a natural key (not surrogate), so renaming
        # a relationship creates a new row rather than updating the old one. The
        # dropDuplicates above is critical -- without it, duplicate (src, dst, rel)
        # triples from different evidence sources would cause the
        # DELTA_MULTIPLE_SOURCE_ROW_MATCHING_TARGET_ROW_IN_MERGE error. The
        # dedup picks an arbitrary winner among duplicates, which is acceptable
        # because confidence scores are similar for same-name relationships.
        self.spark.sql(f"""
            MERGE INTO {rels_table} AS tgt
            USING _new_rels AS src
            ON tgt.src_entity_type = src.src_entity_type
               AND tgt.dst_entity_type = src.dst_entity_type
               AND tgt.relationship_name = src.relationship_name
            WHEN MATCHED AND (
                tgt.confidence != src.confidence
                OR COALESCE(tgt.evidence_column, '') != COALESCE(src.evidence_column, '')
                OR COALESCE(tgt.source, '') != COALESCE(src.source, '')
            ) THEN UPDATE SET
                tgt.confidence = src.confidence,
                tgt.evidence_column = src.evidence_column,
                tgt.evidence_table = src.evidence_table,
                tgt.source = src.source,
                tgt.cardinality = src.cardinality,
                tgt.source_ontology = src.source_ontology,
                tgt.edge_uri = src.edge_uri,
                tgt.updated_at = src.updated_at
            WHEN NOT MATCHED THEN INSERT *
        """)
        self.spark.catalog.dropTempView("_new_rels")
        logger.info("discover_named_relationships: merged %d relationships", len(rels))
        return len(rels)

    def validate_entity_conformance(self) -> Dict[str, Any]:
        """Check how well discovered column properties cover each entity's declared schema.

        Compares bundle-defined properties against actual columns in ontology_column_properties.
        Returns a dict of conformance scores per entity-table pair and logs warnings for
        low coverage. Does not write back to any table -- purely informational.
        """
        results: Dict[str, Any] = {}
        ent_table = self.config.fully_qualified_entities
        cp_table = self.config.fully_qualified_column_properties

        try:
            primary_ents = self.spark.sql(f"""
                SELECT entity_type, EXPLODE(source_tables) AS table_name
                FROM {ent_table}
                WHERE entity_role = 'primary'
            """).collect()
        except Exception as e:
            logger.debug("validate_entity_conformance: cannot read entities: %s", e)
            return results

        try:
            cp_rows = self.spark.sql(f"""
                SELECT table_name, column_name, property_role
                FROM {cp_table}
            """).collect()
        except Exception as e:
            logger.debug("validate_entity_conformance: cannot read column_properties: %s", e)
            return results

        # Build lookup: table_name -> set of column names
        table_columns: Dict[str, set] = {}
        for r in cp_rows:
            table_columns.setdefault(r.table_name, set()).add(r.column_name.lower())

        for row in primary_ents:
            et = row.entity_type
            tbl = row.table_name
            edef = self.discoverer._entity_def_map.get(et)
            if not edef or not edef.properties:
                continue

            expected_attrs = set()
            for prop in edef.properties:
                for attr in prop.typical_attributes:
                    expected_attrs.add(attr.lower())

            actual_cols = table_columns.get(tbl, set())
            matched = expected_attrs & actual_cols
            total = len(expected_attrs)
            score = len(matched) / total if total > 0 else 1.0
            missing = sorted(expected_attrs - actual_cols)

            results[f"{et}:{tbl}"] = {
                "conformance_score": round(score, 3),
                "matched": len(matched),
                "total_declared": total,
                "missing_properties": missing[:10],
            }
            if score < 0.5 and total > 2:
                logger.warning(
                    "Low conformance for %s on %s: %.0f%% (%d/%d), missing: %s",
                    et, tbl, score * 100, len(matched), total, ", ".join(missing[:5]),
                )

        if results:
            logger.info(
                "Entity conformance: %d entity-table pairs checked, avg score %.0f%%",
                len(results),
                sum(r["conformance_score"] for r in results.values()) / len(results) * 100,
            )
        return results

    def _snapshot_ontology_state(self) -> Dict[str, Any]:
        """Read current ontology tables into Python dicts for diff comparison."""
        snapshot: Dict[str, Any] = {"entities": {}, "columns": {}, "relationships": set()}
        ent_tbl = self.config.fully_qualified_entities
        cp_tbl = self.config.fully_qualified_column_properties
        rel_tbl = self.config.fully_qualified_relationships
        try:
            for r in self.spark.sql(f"SELECT entity_name, entity_type, source_tables, confidence, "
                                    f"COALESCE(attributes['granularity'], 'table') AS granularity "
                                    f"FROM {ent_tbl}").collect():
                key = (r.entity_name, ",".join(sorted(r.source_tables or [])), r.granularity)
                snapshot["entities"][key] = {"name": r.entity_name, "type": r.entity_type, "confidence": float(r.confidence or 0)}
        except Exception as e:
            logger.debug("Snapshot entities failed: %s", e)
        try:
            for r in self.spark.sql(f"SELECT table_name, column_name, property_role, confidence "
                                    f"FROM {cp_tbl}").collect():
                key = (r.table_name, r.column_name)
                snapshot["columns"][key] = {"role": r.property_role, "confidence": float(r.confidence or 0)}
        except Exception as e:
            logger.debug("Snapshot columns failed: %s", e)
        try:
            for r in self.spark.sql(f"SELECT src_entity_type, relationship_name, dst_entity_type "
                                    f"FROM {rel_tbl}").collect():
                snapshot["relationships"].add((r.src_entity_type, r.relationship_name, r.dst_entity_type))
        except Exception as e:
            logger.debug("Snapshot relationships failed: %s", e)
        return snapshot

    def generate_discovery_diff(
        self,
        before: Dict[str, Any],
        after: Dict[str, Any],
        bundle_version: str,
        previous_version: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Compare before/after ontology snapshots and return a diff report."""
        ts = datetime.now().isoformat()
        entity_changes: Dict[str, List] = {"added": [], "removed": [], "changed": []}
        col_changes: Dict[str, List] = {"role_changed": [], "new_columns": [], "removed_columns": []}
        rel_changes: Dict[str, List] = {"added": [], "removed": []}

        before_ents = before.get("entities", {})
        after_ents = after.get("entities", {})
        for key in set(after_ents) - set(before_ents):
            entity_changes["added"].append(after_ents[key]["name"])
        for key in set(before_ents) - set(after_ents):
            entity_changes["removed"].append(before_ents[key]["name"])
        entity_changes["added"] = sorted(set(entity_changes["added"]))
        entity_changes["removed"] = sorted(set(entity_changes["removed"]))
        for key in set(before_ents) & set(after_ents):
            b, a = before_ents[key], after_ents[key]
            if abs((b.get("confidence") or 0) - (a.get("confidence") or 0)) > 0.001:
                entity_changes["changed"].append({
                    "name": a["name"], "field": "confidence",
                    "old": b.get("confidence"), "new": a.get("confidence"),
                })

        before_cols = before.get("columns", {})
        after_cols = after.get("columns", {})
        for key in set(after_cols) - set(before_cols):
            col = after_cols[key]
            col_changes["new_columns"].append({"table": key[0], "column": key[1], "role": col.get("role")})
        for key in set(before_cols) - set(after_cols):
            col = before_cols[key]
            col_changes["removed_columns"].append({"table": key[0], "column": key[1], "role": col.get("role")})
        for key in set(before_cols) & set(after_cols):
            if (before_cols[key].get("role") or "") != (after_cols[key].get("role") or ""):
                col_changes["role_changed"].append({
                    "table": key[0], "column": key[1],
                    "old_role": before_cols[key].get("role"), "new_role": after_cols[key].get("role"),
                })

        before_rels = before.get("relationships", set())
        after_rels = after.get("relationships", set())
        rel_changes["added"] = [{"src": r[0], "rel": r[1], "dst": r[2]} for r in after_rels - before_rels]
        rel_changes["removed"] = [{"src": r[0], "rel": r[1], "dst": r[2]} for r in before_rels - after_rels]

        return {
            "bundle_version": bundle_version,
            "previous_version": previous_version,
            "timestamp": ts,
            "entity_changes": entity_changes,
            "column_changes": col_changes,
            "relationship_changes": rel_changes,
        }

    def _store_discovery_diff(self, diff: Dict[str, Any]) -> None:
        """Store discovery diff report in discovery_diff_report table."""
        self.create_discovery_diff_table()
        report_id = str(uuid.uuid4())
        diff_json = json.dumps(diff).replace("'", "''")
        esc_bv = (diff.get("bundle_version") or "").replace("'", "''")
        esc_pv = (str(diff.get("previous_version") or "")).replace("'", "''")
        # INSERT: Append a single discovery diff report row capturing what changed
        # between the previous and current ontology discovery run. The diff_json
        # field contains a serialized dict of entity/relationship/column changes.
        # WHY: Discovery diffs enable the dashboard to show "what changed since
        # last run" and help stewards audit whether entity additions/removals
        # were expected. Append-only preserves the full history.
        # TRADEOFFS: The diff_json is stored as a SQL string literal, so it's
        # limited by SQL string length and requires quote escaping. A DataFrame
        # append would be cleaner but the overhead of creating a single-row DF
        # is not worth it for one row per pipeline run.
        self.spark.sql(f"""
            INSERT INTO {self.config.fully_qualified_discovery_diff}
            (report_id, catalog, schema, bundle_version, previous_version, timestamp, diff_json, created_at)
            VALUES ('{report_id}', '{self.config.catalog_name}', '{self.config.schema_name}',
                    '{esc_bv}', '{esc_pv}', current_timestamp(), '{diff_json}', current_timestamp())
        """)
        logger.info("Stored discovery diff report %s", report_id)

    def _serialize_turtle(self) -> Optional[str]:
        """Serialize ontology entities and relationships to OWL Turtle.
        
        Returns the output path, or None if rdflib is unavailable.
        """
        try:
            from dbxmetagen.ontology_turtle import write_turtle
        except ImportError:
            logger.warning(
                "ontology_turtle unavailable (rdflib not installed) -- "
                "SPARQL-based ontology queries will be disabled for the deep analysis agent"
            )
            return None

        ents = self.spark.sql(
            f"SELECT entity_type, entity_uri, source_ontology, "
            f"EXPLODE(source_tables) AS table_name "
            f"FROM {self.config.fully_qualified_entities} "
            f"WHERE confidence >= 0.5 AND source_tables IS NOT NULL "
            f"AND SIZE(source_tables) > 0 "
            f"AND COALESCE(attributes['granularity'], 'table') = 'table'"
        ).collect()
        if not ents:
            return None

        table_preds = {}
        for e in ents:
            tbl = e["table_name"].split(".")[-1]
            if tbl not in table_preds:
                table_preds[tbl] = {
                    "predicted_entity": e["entity_type"],
                    "equivalent_class_uri": e["entity_uri"],
                    "source_ontology": e["source_ontology"],
                }

        edge_preds = []
        try:
            rels = self.spark.sql(
                f"SELECT src_entity_type, relationship_name, dst_entity_type "
                f"FROM {self.config.fully_qualified_relationships} "
                f"WHERE relationship_name IS NOT NULL"
            ).collect()
            for r in rels:
                edge_preds.append({
                    "from_table": r["src_entity_type"],
                    "to_table": r["dst_entity_type"],
                    "predicted_edge": r["relationship_name"],
                })
        except Exception as e:
            logger.warning("Could not read relationships for Turtle export: %s", e)

        ttl_path = write_turtle(
            catalog=self.config.catalog_name,
            schema=self.config.schema_name,
            table_predictions=table_preds,
            edge_predictions=edge_preds,
        )

        if ttl_path:
            try:
                vol_path = (
                    f"/Volumes/{self.config.catalog_name}/{self.config.schema_name}"
                    f"/generated_metadata/ontology_output.ttl"
                )
                self.spark.sql(f"CREATE VOLUME IF NOT EXISTS "
                               f"{self.config.catalog_name}.{self.config.schema_name}.generated_metadata")
                import shutil
                dbutils_copy = False
                try:
                    from pyspark.dbutils import DBUtils
                    dbutils = DBUtils(self.spark)
                    dbutils.fs.cp(f"file:{ttl_path}", vol_path)
                    dbutils_copy = True
                except Exception:
                    pass
                if not dbutils_copy:
                    shutil.copy2(ttl_path, vol_path)
                logger.info("Turtle written to %s", vol_path)
            except Exception as e:
                logger.warning("Could not copy Turtle to Volume: %s", e)

        return ttl_path

    def run(self, apply_tags=False, sweep_stale_entities: bool = False):
        """Execute the ontology building pipeline.

        Args:
            apply_tags: If True, write entity_type tags to UC tables/columns via ALTER TABLE SET TAGS.
            sweep_stale_entities: On a non-incremental run, purge the current bundle's auto-discovered
                entities (and orphan nodes) before re-discovery so stale rows that are no longer
                produced are cleared. Steward locks (auto_discovered=FALSE) are preserved. Ignored in
                incremental mode (a clean rebuild requires a full re-discovery pass).

        With incremental enabled, skips role/column-property/edge work when discovery finds zero new entities
        (classification only runs when table or column entities changed).
        """
        import time as _time

        def _step(name, fn, *args, **kwargs):
            t0 = _time.time()
            result = fn(*args, **kwargs)
            elapsed = _time.time() - t0
            logger.info(f"[timing] {name}: {elapsed:.1f}s")
            return result

        logger.info("Starting ontology build")
        pipeline_start = _time.time()

        before_snapshot = self._snapshot_ontology_state()
        previous_version = None
        try:
            row = self.spark.sql(
                f"SELECT MAX(bundle_version) AS v FROM {self.config.fully_qualified_entities} "
                "WHERE bundle_version IS NOT NULL"
            ).collect()
            if row and row[0].v:
                previous_version = str(row[0].v)
        except Exception:
            pass

        current_bundle = self.config.ontology_bundle or ""
        if current_bundle:
            try:
                stored = self.spark.sql(
                    f"SELECT DISTINCT ontology_bundle FROM {self.config.fully_qualified_entities} "
                    "WHERE ontology_bundle IS NOT NULL"
                ).collect()
                old_bundles = {r.ontology_bundle for r in stored} - {current_bundle}
                if old_bundles:
                    msg = (
                        f"ontology_entities contains entities from bundle(s) {old_bundles} but current "
                        f"bundle is '{current_bundle}'. These coexist and are NOT deleted by a normal run. "
                        "To clear a previous bundle's classification on specific tables, run "
                        "non-incrementally with sweep_stale_entities=true (a table-scoped refresh)."
                    )
                    logger.warning(msg)
            except Exception:
                pass

        _step("create_entities_table", self.create_entities_table)
        _step("create_metrics_table", self.create_metrics_table)

        # Explicit sweep refresh: on a non-incremental sweep, evict the in-scope tables'
        # auto-discovered entities (and orphan nodes) before re-discovery, which then repopulates
        # them from the current bundle. Scoped to table_names so tables NOT in the run are never
        # touched (other bundles keep coexisting); empty table_names = full-schema replacement.
        if sweep_stale_entities and not self.config.incremental:
            _step("sweep_refresh_purge", self._purge_entities_for_rebuild, self.config.table_names)

        table_discovered = _step("discover_table_entities", self.discover_and_store_entities)
        logger.info(f"Discovered {table_discovered} table-level entities")

        column_discovered = _step("discover_column_entities", self.discover_and_store_column_entities)
        logger.info(f"Discovered {column_discovered} column-level entities")

        if self.config.incremental and table_discovered == 0 and column_discovered == 0:
            logger.info("Incremental mode: no new entities discovered, skipping discovery and edge rebuild")
            # Still reconcile roles: confidence on existing in-scope entities may
            # have shifted (e.g. via a prior validate run), which can flip primary/
            # referenced even when no new entities were discovered. Scoped to
            # table_names so out-of-scope entities (other bundles) are untouched.
            roles_classified = _step(
                "reconcile_entity_roles",
                reconcile_entity_roles,
                self.spark, self.config.fully_qualified_entities,
                self.config.table_names or None, self._PRIMARY_CONFIDENCE_FLOOR,
            )
            total_elapsed = _time.time() - pipeline_start
            logger.info(f"[timing] ontology_build_total: {total_elapsed:.1f}s (early exit)")
            try:
                summary = self.get_entity_summary()
                entity_types = summary.count()
            except Exception:
                entity_types = 0
            return {
                "entities_discovered": 0,
                "column_entities_discovered": 0,
                "entity_types": entity_types,
                "edges_added": 0,
                "tags_applied": 0,
                "roles_classified": roles_classified,
                "column_properties": 0,
                "named_relationships": 0,
                "bundle_edges": 0,
                "discovery_diff": {},
                "turtle_path": None,
            }

        if column_discovered > 0:
            _step("backfill_source_columns", self.backfill_source_columns)

        roles_classified = _step("classify_entity_roles", self.classify_entity_roles)
        logger.info(f"Classified {roles_classified} entity roles (primary/referenced)")

        _step("deduplicate_primary_entities", self._deduplicate_primary_entities)
        _step("flag_low_confidence_primaries", self._flag_low_confidence_primaries)

        col_props = _step("classify_column_properties", self.classify_column_properties)
        logger.info(f"Classified {col_props} column properties")

        owl_fks = _step(
            "merge_owl_declared_fks",
            self.merge_owl_declared_fks,
            sweep_stale_entities,
        )
        logger.info(f"Merged {owl_fks} OWL-declared FK entries into extended metadata")

        _step("validate_entity_conformance", self.validate_entity_conformance)

        # Relationships sweep (sweep only): ontology_relationships has no other delete path,
        # so on a clean rebuild we purge all auto-generated rows before regenerating them via
        # discover_named_relationships + emit_bundle_edges below. Clears stale fk_inferred,
        # renamed/removed edges, and the categorized_as/category_of residue.
        if sweep_stale_entities and not self.config.incremental:
            _step("purge_stale_relationships", self._purge_stale_relationships)

        named_rels = _step("discover_named_relationships", self.discover_named_relationships)
        logger.info(f"Discovered {named_rels} named relationships")

        bundle_rels = _step("emit_bundle_edges", self.emit_bundle_edges)
        logger.info(f"Emitted {bundle_rels} bundle-defined edges")

        _step("seed_concept_parent_entities", self._seed_concept_parent_entities)
        # Post-discovery orphan-seed cleanup (sweep only): now that the current bundle has its
        # freshly discovered+seeded entities, drop table-less seeds of bundles that no longer
        # have any table-attributed entities (e.g. after a bundle switch on the same tables).
        # Must run here, not in _purge_entities_for_rebuild, whose pre-discovery snapshot can't
        # see a foreign bundle as orphaned.
        if sweep_stale_entities and not self.config.incremental:
            _step("purge_orphaned_bundle_seeds", self._purge_orphaned_bundle_seeds)
        _step("sync_entity_nodes_to_graph", self._sync_entity_nodes_to_graph)
        _step("enrich_table_nodes_with_ontology", self._enrich_table_nodes_with_ontology)

        # UPDATE: Backfill source_system='ontology' on legacy graph_edges rows that
        # were created before source_system was introduced. Only targets edges with
        # ontology-specific relationship types. Idempotent -- rows already tagged
        # are excluded by the WHERE NULL check.
        # WHY: The merge_edges() contract requires every edge to have a source_system
        # so the sweep-stale logic can scope deletions. Legacy rows without it would
        # be invisible to sweeping and could accumulate as orphans.
        # TRADEOFFS: A one-time migration script would be cleaner, but running this
        # idempotently on every pipeline execution is simpler to deploy and handles
        # any edge case where new NULL rows appear from other code paths.
        edges_table = f"{self.config.catalog_name}.{self.config.schema_name}.graph_edges"
        try:
            self.spark.sql(
                f"UPDATE {edges_table} SET source_system = 'ontology' "
                f"WHERE source_system IS NULL "
                f"AND relationship IN ('instance_of','has_property','has_attribute','is_a','same_entity_type')"
            )
        except Exception:
            pass

        # Build all ontology edge DataFrames, then MERGE once
        from dbxmetagen.knowledge_graph import merge_edges, align_edge_schema
        from functools import reduce

        edge_dfs = []

        structural_df = _step("build_structural_edges", self._build_structural_edges)
        if structural_df is not None:
            edge_dfs.append(align_edge_schema(structural_df))

        hierarchy_df = _step("build_hierarchy_edges", self._build_hierarchy_edges)
        if hierarchy_df is not None:
            edge_dfs.append(align_edge_schema(hierarchy_df))

        category_df = _step("build_category_edges", self._build_category_edges)
        if category_df is not None:
            edge_dfs.append(align_edge_schema(category_df))

        rel_result = _step("discover_inter_entity_relationships", self.discover_inter_entity_relationships)
        if rel_result.get("edges_df") is not None:
            edge_dfs.append(align_edge_schema(rel_result["edges_df"]))

        same_df = _step("build_same_entity_type_edges", self._build_same_entity_type_edges)
        if same_df is not None:
            edge_dfs.append(align_edge_schema(same_df))

        if edge_dfs:
            combined = reduce(lambda a, b: a.unionByName(b), edge_dfs).dropDuplicates(["edge_id"])
            # On a sweep run, also sweep stale ontology edges. Safe for coexistence: the edge
            # builders read all surviving entities, so out-of-scope bundles' edges are regenerated
            # into `combined` and preserved by the MERGE.
            edges_added = merge_edges(self.spark, edges_table, combined,
                                      source_system="ontology", sweep_stale=sweep_stale_entities)
        else:
            edges_added = 0

        _step("validate_ontology_completeness", self.validate_ontology_completeness)
        _step("compute_ontology_metrics", self.compute_ontology_metrics)

        tags_applied = 0
        if apply_tags:
            tags_applied = _step("apply_entity_tags", self.apply_entity_tags)

        try:
            summary = self.get_entity_summary()
            entity_types = summary.count()
            logger.info(f"Ontology summary: {entity_types} entity types")
            for row in summary.collect():
                logger.info(
                    f"  {row['entity_type']}: {row['entity_count']} entities (avg confidence: {row['avg_confidence']})"
                )
        except Exception:
            entity_types = 0

        # Optional: serialize to Turtle if rdflib is available
        turtle_path = None
        try:
            turtle_path = _step("serialize_turtle", self._serialize_turtle)
        except Exception as e:
            logger.debug("Turtle serialization skipped: %s", e)

        total_elapsed = _time.time() - pipeline_start
        logger.info(f"[timing] ontology_build_total: {total_elapsed:.1f}s")

        after_snapshot = self._snapshot_ontology_state()
        bundle_version = self._get_bundle_version()
        diff = self.generate_discovery_diff(
            before_snapshot, after_snapshot, bundle_version, previous_version
        )
        try:
            self._store_discovery_diff(diff)
        except Exception as e:
            logger.warning("Could not store discovery diff: %s", e)

        return {
            "entities_discovered": table_discovered,
            "column_entities_discovered": column_discovered,
            "entity_types": entity_types,
            "edges_added": edges_added,
            "tags_applied": tags_applied,
            "roles_classified": roles_classified,
            "column_properties": col_props,
            "named_relationships": named_rels,
            "bundle_edges": bundle_rels,
            "discovery_diff": diff,
            "turtle_path": turtle_path,
        }

    def refresh_relationships(self, sweep_stale: bool = False, sweep_stale_entities: bool = False, incremental: bool = True) -> Dict[str, Any]:
        """Re-run only edge-building steps after FK predictions are available.

        Intended to be called as a post-FK-prediction task so that FK-evidence-
        backed relationships land in the ontology within a single pipeline run,
        without repeating entity discovery or column property classification.

        When incremental=True, returns early unless fk_predictions.updated_at exceeds
        the latest ontology_relationships.updated_at for source='fk_inferred'. Sweeping
        (sweep_stale or sweep_stale_entities) suppresses the early exit so cleanup runs.

        This task is edge-only: it never deletes entities (it does not re-discover them, so it
        could not repopulate them). Entity refresh belongs to the full ontology run(). Here
        sweep_stale_entities is treated as an alias for the edge sweep.
        """
        import time as _time
        from dbxmetagen.knowledge_graph import merge_edges, align_edge_schema
        from functools import reduce

        start = _time.time()

        if incremental and not sweep_stale and not sweep_stale_entities:
            fk_table = f"{self.config.catalog_name}.{self.config.schema_name}.fk_predictions"
            rels_table = self.config.fully_qualified_relationships
            ent_table = self.config.fully_qualified_entities
            try:
                max_fk = self.spark.sql(
                    f"SELECT COALESCE(MAX(updated_at), TIMESTAMP '1970-01-01') AS mu FROM {fk_table}"
                ).collect()[0].mu
                max_rel = self.spark.sql(
                    f"SELECT COALESCE(MAX(updated_at), TIMESTAMP '1970-01-01') AS mu "
                    f"FROM {rels_table} WHERE source = 'fk_inferred'"
                ).collect()[0].mu
                # Bundle edges are role-gated (emit_bundle_edges filters entity_role='primary').
                # If entity roles were recomputed (e.g. by validate) after the last bundle-edge
                # build, those edges are stale even when no new FK predictions exist. Re-run
                # unless BOTH FK predictions and entity roles are no newer than the last build.
                max_ent = self.spark.sql(
                    f"SELECT COALESCE(MAX(updated_at), TIMESTAMP '1970-01-01') AS mu FROM {ent_table}"
                ).collect()[0].mu
                max_bundle = self.spark.sql(
                    f"SELECT COALESCE(MAX(updated_at), TIMESTAMP '1970-01-01') AS mu "
                    f"FROM {rels_table} WHERE source = 'bundle'"
                ).collect()[0].mu
                if max_fk <= max_rel and max_ent <= max_bundle:
                    logger.info(
                        "Incremental: no new FK predictions (%s >= %s) and no entity-role "
                        "changes (%s >= %s) since last relationship refresh, skipping",
                        max_rel, max_fk, max_bundle, max_ent,
                    )
                    return {"named_relationships": 0, "bundle_edges": 0, "graph_edges": 0}
            except Exception as e:
                logger.debug("Incremental watermark check failed (%s), running full", e)

        # Relationships sweep (non-incremental sweep only): purge all auto-generated rows so
        # discover_named_relationships + emit_bundle_edges below regenerate them cleanly. This is
        # the refresh-side counterpart to run()'s sweep, and the one that actually clears stale
        # fk_inferred rows using fresh FK predictions (refresh runs after predict_foreign_keys).
        if (sweep_stale or sweep_stale_entities) and not incremental:
            self._purge_stale_relationships()

        named = self.discover_named_relationships()
        bundle = self.emit_bundle_edges()
        self._seed_concept_parent_entities()
        self._sync_entity_nodes_to_graph()

        # UPDATE: Same legacy source_system backfill as in run() -- see comment there.
        # Duplicated here because refresh_relationships() is an alternative entry
        # point that skips the full run() pipeline.
        edges_table = f"{self.config.catalog_name}.{self.config.schema_name}.graph_edges"
        try:
            self.spark.sql(
                f"UPDATE {edges_table} SET source_system = 'ontology' "
                f"WHERE source_system IS NULL "
                f"AND relationship IN ('instance_of','has_property','has_attribute','is_a','same_entity_type')"
            )
        except Exception:
            pass
        edge_dfs = []

        structural_df = self._build_structural_edges()
        if structural_df is not None:
            edge_dfs.append(align_edge_schema(structural_df))

        hierarchy_df = self._build_hierarchy_edges()
        if hierarchy_df is not None:
            edge_dfs.append(align_edge_schema(hierarchy_df))

        category_df = self._build_category_edges()
        if category_df is not None:
            edge_dfs.append(align_edge_schema(category_df))

        inter = self.discover_inter_entity_relationships()
        if inter.get("edges_df") is not None:
            edge_dfs.append(align_edge_schema(inter["edges_df"]))

        same_df = self._build_same_entity_type_edges()
        if same_df is not None:
            edge_dfs.append(align_edge_schema(same_df))

        if edge_dfs:
            combined = reduce(lambda a, b: a.unionByName(b), edge_dfs).dropDuplicates(["edge_id"])
            total_edges = merge_edges(self.spark, edges_table, combined, source_system="ontology", sweep_stale=(sweep_stale or sweep_stale_entities))
        else:
            total_edges = 0

        elapsed = _time.time() - start
        logger.info("[timing] refresh_relationships: %.1fs", elapsed)

        return {
            "named_relationships": named,
            "bundle_edges": bundle,
            "graph_edges": total_edges,
        }


def refresh_ontology_relationships(
    spark: SparkSession,
    catalog_name: str,
    schema_name: str,
    config_path: str = _DEFAULT_ONTOLOGY_CONFIG_PATH,
    ontology_bundle: str = "",
    model_endpoint: Optional[str] = None,
    table_names: Optional[List[str]] = None,
    sweep_stale: bool = False,
    sweep_stale_entities: bool = False,
    incremental: bool = True,
) -> Dict[str, Any]:
    """Convenience function to refresh ontology edges after FK prediction."""
    config = OntologyConfig(
        catalog_name=catalog_name,
        schema_name=schema_name,
        config_path=config_path,
        ontology_bundle=ontology_bundle,
        incremental=incremental,
        table_names=table_names,
    )
    builder = OntologyBuilder(spark, config, model_endpoint=model_endpoint)
    return builder.refresh_relationships(
        sweep_stale=sweep_stale, sweep_stale_entities=sweep_stale_entities, incremental=incremental
    )


def build_ontology(
    spark: SparkSession,
    catalog_name: str,
    schema_name: str,
    config_path: str = _DEFAULT_ONTOLOGY_CONFIG_PATH,
    apply_tags: bool = False,
    ontology_bundle: str = "",
    incremental: bool = True,
    entity_tag_key: str = "ontology_entity_type",
    model_endpoint: Optional[str] = None,
    table_names: Optional[List[str]] = None,
    ontology_vs_index: str = "",
    vs_endpoint_name: str = "dbxmetagen-vs",
    federation_mode: bool = False,
    sweep_stale_entities: bool = False,
) -> Dict[str, Any]:
    """Convenience function to build the ontology.

    Args:
        spark: SparkSession instance
        catalog_name: Catalog name for tables
        schema_name: Schema name for tables
        config_path: Path to ontology configuration YAML.  When left at the
            default, the path is automatically derived from *ontology_bundle*
            (e.g. ``ontology_bundles/general.yaml``).
        apply_tags: If True, write entity tags to UC tables/columns
        ontology_bundle: Optional bundle name (stored alongside entities)
        incremental: Only classify tables/columns changed since last run
        entity_tag_key: UC tag key used when apply_tags is True
        model_endpoint: LLM endpoint for classification (overrides bundle/default)
        ontology_vs_index: Fully-qualified VS index name for ontology retrieval.
            When set, entity/edge classification uses HYBRID vector search.
        vs_endpoint_name: Vector Search endpoint name for ontology queries.
        federation_mode: Use SET TAG ON syntax for federated (FOREIGN) tables.
        sweep_stale_entities: On a non-incremental run, clean-rebuild the current bundle's
            auto-discovered entities before re-discovery (steward locks preserved).
    """
    config = OntologyConfig(
        catalog_name=catalog_name,
        schema_name=schema_name,
        config_path=config_path,
        ontology_bundle=ontology_bundle,
        incremental=incremental,
        entity_tag_key=entity_tag_key,
        table_names=table_names,
        ontology_vs_index=ontology_vs_index,
        vs_endpoint_name=vs_endpoint_name,
        federation_mode=federation_mode,
    )
    builder = OntologyBuilder(spark, config, model_endpoint=model_endpoint)
    return builder.run(apply_tags=apply_tags, sweep_stale_entities=sweep_stale_entities)
